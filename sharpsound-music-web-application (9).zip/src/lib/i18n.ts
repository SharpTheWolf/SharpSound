import { useMemo } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Lang = "ru" | "en";
export type Localized = { ru: string; en: string };

export const useLocale = create<{ lang: Lang; setLang: (lang: Lang) => void }>()(
  persist(
    (set) => ({
      lang: "ru",
      setLang: (lang) => set({ lang }),
    }),
    { name: "ss-language", partialize: (s) => ({ lang: s.lang }) }
  )
);

const EN: Record<string, string> = {
  "{size} МБ": "{size} MB", "Музыка": "music",
  "Плейлисты": "Playlists", "из любимых треков": "from your favorites", "Название плейлиста…": "Playlist name…", "Создать": "Create",
  "Пока нет плейлистов. Создай первый и добавь в него треки из избранного.": "No playlists yet. Create one and add tracks from your favorites.",
  "треков": "tracks", "Слушать всё": "Play all", "Открыть плейлист": "Open playlist", "Удалить плейлист": "Delete playlist",
  "Убрать из плейлиста": "Remove from playlist", "Плейлист пока пуст": "This playlist is empty",
  "Добавить из «Мне нравится»": "Add from Favorites",
  "У каждого трека есть альбом — открой, чтобы послушать его целиком": "Every track has an album — open it to play the whole thing",
  "Слушать весь альбом": "Play the whole album",
  "Поиск": "Search", "Главная": "Home", "Распознать": "Recognize", "Коллекция": "Collection",
  "Вклад в сообщество": "Contribute", "Сообщество": "Community", "сообщество": "community",
  "Мини-студия": "Mini studio", "Геймер": "Gamer", "Тёмный": "Deep", "Лайм": "Lime", "Свечение": "Glow",
  "Студия": "Studio", "studio": "studio", "Демо": "demo", "Моя музыка": "My music", "Открыть мини-студию": "Open mini studio",
  "Новый наряд. Старый вкус.": "New outfit. Same taste.", "Скины компаньона": "Companion skins", "Выбрать скин помощника": "Choose companion skin",
  "Наряды": "Outfits", "Сменить образ": "Change the look", "RGB подсветка активна": "RGB lighting active",
  "SharpSound": "SharpSound", "Панель трека": "Track desk", "Инструментальный генератор SharpSound": "SharpSound instrumental generator",
  "Твоё имя": "Your artist name", "Новый трек": "Untitled track", "Новый вариант": "New take",
  "Моя студия": "My Studio", "Собери инструментальный трек: выбери жанр, настрой темп и послушай, что получится. Здесь можно создать и сохранить свои демо.": "Build an instrumental track: choose a genre, set the tempo and hear what you create. Save your demos here.",
  "Например: Неоновый дождь": "Example: Neon rain", "Твой псевдоним": "Your artist name", "Темп": "Tempo", "Медленно": "Slow", "Быстро": "Fast",
  "Добавь название и имя исполнителя. Мат цензура не пропустит.": "Add a title and an artist name. The word filter blocks profanity.",
  "Нужно название и имя исполнителя. Мат цензура не пропустит.": "A title and artist are required. Profanity is filtered.",
  "{title} пошёл в прослушку. Твой мини-студийный дебют!": "{title} is ready for a listen. Your mini-studio debut!",
  "Сохранили «{title}»! Я уже качаю головой.": "Saved '{title}'! I'm already nodding along.",
  "Сохранено в «Коллекция → Мои загрузки». Трек готов к прослушиванию.": "Saved to 'Collection → My uploads'. Your track is ready to play.",
  "Трек удалён из студии.": "Track removed from the studio.", "Геймпад": "Gamepad",
  "Сохранённые демо": "Saved demos", "Локальные треки из мини-студии": "Local tracks from your mini studio",
  "Здесь будут твои треки после нажатия «Сохранить трек».": "Your tracks will appear here after you press 'Save track'.",
  "Сохранить трек": "Save track", "Послушать": "Preview", "Демо играет": "Demo playing", "Волна трека": "Track waveform",
  "Цензура: поправь название или имя исполнителя.": "Word filter: adjust the title or artist name.",
  "Все демо создаются процедурным синтезатором в браузере, сохраняются локально и доступны в поиске, коллекции и Резонансе.": "Demos are procedurally generated in your browser, saved locally, and available in Search, Collection and Resonance.",
  "Трек больше не доступен": "Track is no longer available",
  "Дорога музыки": "Music road", "Каждая строка — инструмент. Каждый блок — часть трека. Нажми на блок, чтобы изменить его.": "Each row is an instrument, each block is a section. Tap a block to edit it.",
  "Дорожка": "Lane", "Часть +8": "Part +8", "Авто-структура": "Auto arrange", "Добавить музыку": "Add music",
  "Все инструменты уже в миксе": "Every instrument is already in the mix", "дорожек": "lanes",
 "Убрать дорожку": "Remove lane", "Правки применяются ко всем дорожкам": "Edits apply to every lane",
  "Раньше": "Earlier", "Позже": "Later", "Тембры и тоны": "Timbres and tones",
  "Меняй инструмент каждой дорожки, громкость и октаву — звук пересобирается сразу.": "Swap each lane's instrument, level and octave — the sound rebuilds instantly.",
  "выключено": "muted", "Октава": "Octave", "громкость": "level", "Из чего состоит трек": "What the track is made of",
  "Стартовые тембры": "Starting timbres", "нет в жанре": "not in this genre",
  "Остальные тембры, октавы и громкости — в редакторе после сохранения.": "More timbres, octaves and levels are in the editor after you save.",
  "Собери трек: жанр, темп и тембры. После сохранения откроется дорога музыки — с частями, дорожками и добавлением новых инструментов.": "Build a track: genre, tempo and timbres. After saving, the music road opens with sections, lanes and new instruments to add.",
  "Трек создаётся синтезатором в браузере и сохраняется локально. Дорожки и части редактируются после сохранения.": "Tracks are synthesized in your browser and saved locally. Lanes and sections are editable after saving.",
 "Карандаш открывает редактор: части, дорожки, тембры": "The pencil opens the editor: sections, lanes, timbres",
 "Здесь появятся твои треки.": "Your tracks will appear here.", "Редактировать": "Edit",
 "Волна": "Waveform", "Частей": "Sections",
  "Четыре на пол": "Four on the floor", "Бум-бэп": "Boom bap", "Хафтайм": "Halftime", "Жирный синт": "Fat synth",
 "Мягкий синус": "Soft sine", "Пик (щипок)": "Pick", "Гармония": "Harmony",
  "Гитара": "Guitar", "Электропиано": "E-piano", "Пэд": "Pad", "Стаб": "Stab", "Суперсоу": "Supersaw",
  "Мелодия": "Lead", "Синт-лид": "Synth lead", "Щипок": "Pluck", "Колокол": "Bell", "Ковбелл": "Cowbell",
  "Собери инструментальный трек: выбери жанр, темп и послушай, что получится. После сохранения откроется черновик с редактором структуры и дорожек.": "Build an instrumental track: pick a genre and tempo, hear the result, then save it and open a draft with the structure and tracks editor.",
  "Детали композиции, которую ты можешь редактировать": "The composition details you can edit",
  "Вклад в": "Contribute to", "Позвать помощника": "Call companion", "Помощник рядом": "Companion nearby",
  "ушёл гулять": "out for a walk", "слушает с тобой": "listening with you", "Помощник": "Companion",
  "Я тут! Гуляю по плееру.": "Right here! Taking a walk around the player.",
  "Иконка SharpSound": "SharpSound icon", "иконка приложения": "app icon", "Иконка": "App icon",
  "для ярлыка, exe и рабочего стола": "for shortcuts, exe and your desktop", "Файл уже лежит в проекте:": "Already in the project:",
  "Закрыть": "Close", "Сменить тему": "Switch theme", "Тьма": "Dark", "Свет": "Light", "звук в клетку": "sound on a grid",
  "Назад": "Back", "Вперёд": "Forward", "Дальше": "Next", "Играть": "Play", "Пауза": "Pause",
  "Слушать": "Listen", "Играет": "Playing", "Звук": "Sound", "Громкость": "Volume", "Не нравится": "Not for me",
  "Не то": "Not this one", "Резонанс": "Resonance", "Тишина": "Silence", "Нажми play — помощник подберёт музыку": "Hit play, your companion will find the music",
  "В любимые": "Add to favorites", "Убрать из любимых": "Remove from favorites", "Похожесть по звучанию": "Sound similarity",
  "Звук,": "Sound,", "заточенный": "sharpened", "под": "for", "тебя.": "you.", "Найти по звуку": "Find by sound",
  "SHARPSOUND • 2.5D • ЗВУК В КЛЕТКУ • ♯ • ": "SHARPSOUND / 2.5D / SOUND ON A GRID / # / ",
  "Настроение": "Mood", "нажми, и волна перестроится": "tap to change the flow", "звучит сейчас": "playing now",
  "по твоему вкусу": "made for your taste", "подбирает помощник": "picked by your companion", "Бесконечный поток под твой вкус": "An endless flow shaped by your taste",
  "Запустить": "Start", "Альбомы": "Albums", "Каждый звук здесь собирается прямо на твоём устройстве": "Every sound is made right here on your device",
  "Треки, которые цепляют": "Tracks that stay with you", "Фигура под обложкой оживает, когда трек играет": "The shape beneath the cover comes alive with the music",
  "Из сообщества": "From the community", "Треки, прошедшие модерацию": "Tracks that passed moderation", "Здесь появятся треки слушателей": "This is where listener tracks will appear",
  "Залить свой": "Upload yours", "Твой трек тут": "Your track goes here", "с телефона или ПК": "from your phone or computer",
  "Чарт недели": "Weekly chart", "Растёт от твоих прослушиваний": "Shaped by your listening",
  "Синтвейв": "Synthwave", "Лоу-фай": "Lo-fi", "Фонк": "Phonk", "Техно": "Techno", "Эмбиент": "Ambient", "Рок": "Rock", "Трэп": "Trap", "Гиперпоп": "Hyperpop",
  "Неоновая ночь": "Neon night", "Педаль в пол": "Full throttle", "Тише воды": "Still waters", "Дождь по стеклу": "Rain on glass", "Сахарный шторм": "Sugar storm", "Голова в порядке": "Clear head",
  "по-соседски": "and its neighbors", "Вводишь название — находим трек и всё, что звучит рядом с ним. Можно искать по настроению: «дождь», «ночь», «для учёбы».": "Type a title to find it and its sonic neighbors. Moods work too: rain, night, or study.",
  "Название, артист или настроение…": "Track, artist or mood...", "Очистить": "Clear", "ксенон": "xenon", "дождь": "rain", "фонк": "phonk", "для учёбы": "study", "гитара": "guitar", "космос": "space", "перегрузка": "overload", "техно": "techno",
  "НАЧНИ ПЕЧАТАТЬ • НАЙДЁМ ПОХОЖЕЕ • ": "START TYPING / FIND SOMETHING SIMILAR / ",
  "Лучшее совпадение": "Best match", "Ещё по запросу": "More results", "Звучит похоже на": "Sounds like",
  "Точного названия нет — но по настроению подходит это": "No exact title, but these fit the mood", "Подобрали по тегам, жанру и звучанию": "Matched by tags, genre and sound",
  "Ничего не нашлось": "No matches yet", "Попробуй другое название или настроение — например «ночь» или «гитара».": "Try another title or mood, such as night or guitar.",
  "на слух": "by ear", "Включи музыку рядом. SharpSound разберёт её по частотам и найдёт в библиотеке этот трек — или тот, что звучит ближе всего.": "Play some music nearby. SharpSound analyzes its frequencies and finds the same track, or the closest sound, in your library.",
  "Слишком тихо — ничего не расслышал. Сделай погромче или поднеси источник ближе.": "Too quiet to hear. Turn it up or bring the source closer.",
  "Нет доступа к микрофону. Разреши его в браузере — или распознай файл.": "Microphone unavailable. Allow access in your browser or recognize a file instead.",
  "Не получилось прочитать файл. Подойдут MP3, WAV, OGG, M4A, FLAC.": "Could not read this file. Try MP3, WAV, OGG, M4A or FLAC.",
  "СЛУШАЮ • СЛУШАЮ • СЛУШАЮ • СЛУШАЮ • ": "LISTENING / LISTENING / LISTENING / LISTENING / ",
  "СРАВНИВАЮ • ИЩУ ПОХОЖЕЕ • СРАВНИВАЮ • ": "COMPARING / FINDING A MATCH / COMPARING / ",
  "НАЖМИ • ВКЛЮЧИ ЗВУК РЯДОМ • НАЖМИ • ": "TAP / PLAY SOME MUSIC NEARBY / TAP / ",
  "Нажми и дай послушать": "Tap and let me listen", "Слушаю… держи источник поближе": "Listening... keep the source close", "Сравниваю с библиотекой…": "Comparing with your library...",
  "Готово": "Ready", "Распознать файл": "Recognize a file", "Ещё раз": "Try again", "Библиотека готова": "Library ready", "треков в памяти": "tracks indexed", "Готовлю библиотеку к сравнению": "Preparing the library",
  "Нашли!": "Found it!", "Самое близкое по звучанию": "Closest sound", "совпадение по звучанию": "sound match", "Ещё похоже звучат": "More similar sounds",
  "Сравнение терпит небольшую погрешность: чуть другой темп, тембр или тональность — и трек всё равно найдётся среди похожих.": "Matching allows a little variation in tempo, timbre and key, so a slightly different version can still be found.",
  "Мне нравится": "Favorites", "Долго слушал": "Long listens", "На повторе": "On repeat", "Недавнее": "Recent", "Мои загрузки": "My uploads",
  "фиолетовый неон": "violet neon", "сахарная фуксия": "sugar fuchsia", "раскалённый коралл": "hot coral", "тёплый янтарь": "warm amber", "кислотный лайм": "acid lime", "мятный холод": "cool mint", "морская глубина": "ocean depth", "ночной индиго": "night indigo",
  "Ночной слушатель: главное звучит после полуночи.": "Night owl: the good stuff starts after midnight.", "Утренний: музыка вместо будильника.": "Early bird: music instead of an alarm.", "Дневной: саундтрек к делам.": "Daytime listener: a soundtrack for getting things done.", "Вечерний: музыка, чтобы выдохнуть.": "Evening listener: music to unwind.",
  "Персонаж твоей музыки": "Your music character", "Пока загадка": "Still a mystery", "Послушай несколько треков или поставь пару лайков — и персонаж проявится.": "Listen to a few tracks or leave some likes, and your character will emerge.", "твоего вкуса": "of your taste",
  "Ретро-пилот": "Retro pilot", "Летит в 1986-й, обратный билет не брал. Любит неон, длинные трассы и тёплый аналоговый звук.": "Flying straight to 1986, no return ticket. Loves neon, long highways and warm analog sound.",
  "Мечтатель с пледом": "Blanket dreamer", "Чай остыл, конспект открыт на той же странице. Ему хорошо, и это главное.": "The tea went cold and the notebook is still on the same page. They're happy, and that's what matters.",
  "Ночной гонщик": "Night racer", "Ксенон, туман, педаль в пол. Разговаривает только басом.": "Xenon headlights, fog, full throttle. Speaks fluent bass.",
  "Рейвер": "Raver", "Живёт в размере 4/4 и засыпает после восхода. Знает все склады города.": "Lives in 4/4 and sleeps after sunrise. Knows every warehouse in town.",
  "Звездочёт": "Stargazer", "Слушает тишину между нотами и считает спутники вместо овец.": "Listens to the silence between notes and counts satellites instead of sheep.",
  "Рокер из гаража": "Garage rocker", "Три аккорда, честный звук и соседи, которые уже всё поняли.": "Three chords, honest sound, and neighbors who have heard it all.",
  "Районный поэт": "Street poet", "Басы глубже, чем разговоры на кухне. Пишет строки в заметках телефона.": "Bass deeper than late-night conversations. Writes verses in their phone notes.",
  "Глитч-кид": "Glitch kid", "Сахар, баги и 160 ударов в минуту. Паузу не ставит никогда.": "Sugar, glitches and 160 beats per minute. Never presses pause.",
  "Твой вкус": "Your taste", "видно только тебе, хранится на устройстве": "private to you, stored on your device", "Показать": "Show", "Скрыть": "Hide", "Вкус скрыт": "Taste hidden",
  "Вкус ещё не сформирован": "Your taste is still taking shape", "Включи Резонанс или любой альбом — профиль начнёт собираться сам.": "Start Resonance or play an album and your profile will build itself.",
  "Оттенок твоего звука": "The color of your sound", "Энергия": "Energy", "Темнота": "Darkness", "Яркость": "Brightness", "Плотность": "Density", "минут музыки": "minutes of music", "средний темп": "average tempo", "пик прослушки": "listening peak", "Когда ты слушаешь": "When you listen",
  "Пока пусто": "Nothing here yet", "Жми на сердечко у трека — он появится здесь (а помощник обрадуется).": "Tap a track's heart to keep it here (and make your companion happy).", "Загрузи свой трек во вкладке «Вклад в сообщество».": "Upload your track in the Contribute tab.", "Послушай что-нибудь — эта полка заполнится сама.": "Play some music and this shelf will fill itself.", "Любимые исполнители": "Favorite artists",
  "Залей трек с телефона или компьютера. Модерация проверит звук, цензура — название, и трек появится в поиске, Резонансе и распознавании.": "Upload a track from your phone or computer. Audio moderation and the word filter check it before it joins Search, Resonance and recognition.",
  "Файл": "File", "Модерация": "Moderation", "Оформление": "Details", "Формат файла": "File format", "Размер до 25 МБ": "Size under 25 MB", "Звук читается": "Audio can be decoded", "Длительность от 20 с до 12 мин": "Duration between 20 s and 12 min", "Это музыка, а не тишина или шум": "Music, not silence or noise", "Нет сильного перегруза": "No excessive clipping", "Не копия трека из библиотеки": "Not a copy of a library track",
  "Это не аудиофайл": "This is not an audio file", "Не удалось декодировать звук": "Could not decode the audio", "Слишком тихо или почти тишина": "Too quiet or mostly silence", "Похоже на шум, а не на музыку": "Sounds like noise rather than music", "есть перегруз, но терпимо": "some clipping, still acceptable", "чисто": "clean", "трек": "track", "трека": "track",
  "Отпускай!": "Drop it!", "Перетащи трек сюда": "Drop your track here", "или нажми, чтобы выбрать — с телефона тоже работает": "or tap to choose, works on your phone too", "до 25 МБ": "up to 25 MB", "МБ": "MB", "длительность": "duration", "темп": "tempo", "тональность": "key", "Автомодерация": "Audio moderation", "Одобрено модерацией": "Approved", "Не прошёл модерацию": "Did not pass moderation", "Другой файл": "Choose another file",
  "Обложка": "Cover art", "Заменить": "Replace", "Своё фото": "Upload image", "Убрать": "Remove", "Без фото соберём обложку сами — в стиле жанра.": "No image? We'll generate a cover to match the genre.",
  "Название": "Title", "Исполнитель": "Artist", "Альбом": "Album", "Как называется трек": "Your track title", "Твой ник или имя": "Your name or alias", "Необязательно — иначе «Сингл»": "Optional, defaults to Single", "Сингл": "Single", "Жанр": "Genre", "угадали": "detected", "Теги настроения": "Mood tags", "Пара слов о треке": "A few words about the track", "Необязательно": "Optional",
  "ночь": "night", "дорога": "road", "спорт": "workout", "учёба": "study", "грусть": "sadness", "радость": "joy", "любовь": "love", "танцы": "dance", "фокус": "focus",
  "Это мой трек, или у меня есть права его публиковать.": "This is my track, or I have permission to publish it.", "Отменить": "Cancel", "Публикую…": "Publishing...", "Опубликовать": "Publish", "Опубликовано!": "Published!", "Трек уже в поиске, в Резонансе и в базе распознавания.": "Your track is now in Search, Resonance and the recognition library.", "Загрузить ещё": "Upload another", "Мои публикации": "My uploads", "хранятся на этом устройстве": "stored on this device", "Удалить": "Delete", "Пока ничего. Первый трек — самый важный.": "Nothing yet. The first track is the most important one.",
  "Не удалось сохранить — не хватает места в хранилище": "Could not save: device storage is full", "Трек удалён": "Track deleted", "Не удалось открыть картинку": "Could not open this image", "Файл трека не найден на устройстве": "Track file not found on this device", "Твой трек": "Your track",
  "Цензура не пропустит: «{text}». Перефразируй без мата.": "The word filter won't allow: '{text}'. Please rephrase without profanity.",
  "Файл {size} МБ — больше лимита": "File is {size} MB, above the limit", "Длительность {time} — вне диапазона": "Duration {time} is outside the allowed range", "Перегруз: {pct}% сэмплов": "Clipping in {pct}% of samples", "Почти копия «{title}»": "Almost identical to '{title}'", "ближе всего «{title}» · {pct}%": "closest to '{title}' / {pct}%", "Похоже на {genre}. Осталось оформить.": "Sounds like {genre}. Add the details next.",
  "Нашёл! Это «{title}».": "Found it! It's '{title}'.", "Точно не уверен, но ближе всего «{title}».": "Not quite sure, but '{title}' is the closest.", "«{title}» теперь в библиотеке! Горжусь.": "'{title}' is in the library now! Proud of you.",
  "Хромовый закат": "Chrome sunset", "Полоса 404": "Lane 404", "Ветер с трассы": "Highway wind", "Чай остыл": "Cold tea", "Окно на пятом": "Fifth-floor window", "Пыль на кассете": "Tape dust", "Обочина": "Roadside", "Ксенон": "Xenon", "Дрифт под фонарями": "Streetlight drift", "Цех №7": "Workshop 7", "Бетон и пар": "Concrete and steam", "Сигнал на рассвете": "Dawn signal", "Тихая орбита": "Quiet orbit", "Глубина 3000": "Depth 3000", "Снег на антенне": "Snow on the antenna", "Шум в подъезде": "Hallway noise", "Ржавый мост": "Rusty bridge", "Последний трамвай": "Last tram", "Кислота": "Acid", "Лёд в стакане": "Ice in a glass", "Ночной район": "Night district", "Перегрузка": "Overload", "Сахарный баг": "Sugar bug", "Пиксельное сердце": "Pixel heart",
};

export function translate(source: string | undefined, lang: Lang = useLocale.getState().lang, vars?: Record<string, string | number>) {
  let text = source ? (lang === "en" ? EN[source] ?? source : source) : "";
  if (vars) text = text.replace(/\{(\w+)\}/g, (match, key: string) => String(vars[key] ?? match));
  return text;
}

export function localText(value: Localized | string, lang: Lang = useLocale.getState().lang) {
  return typeof value === "string" ? value : value[lang];
}

export function useI18n() {
  const lang = useLocale((s) => s.lang);
  return useMemo(() => ({
    lang,
    t: (source: string | undefined, vars?: Record<string, string | number>) => translate(source, lang, vars),
    tr: (ru: string, en: string) => lang === "en" ? en : ru,
    text: (value: Localized | string) => localText(value, lang),
  }), [lang]);
}