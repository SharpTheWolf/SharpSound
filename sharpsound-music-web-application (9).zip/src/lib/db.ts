import { del, get, set } from "idb-keyval";
import type { Track } from "../data/catalog";

const INDEX = "ss-uploads-v1";
const urls = new Map<string, string>();

export async function loadUploads(): Promise<Track[]> {
  try {
    return ((await get(INDEX)) as Track[] | undefined) ?? [];
  } catch {
    return [];
  }
}

export async function saveUploads(list: Track[]) {
  await set(INDEX, list);
}

export async function putAudio(id: string, blob: Blob) {
  await set(`ss-audio-${id}`, blob);
}

export async function removeAudio(id: string) {
  await del(`ss-audio-${id}`);
  const u = urls.get(id);
  if (u) URL.revokeObjectURL(u);
  urls.delete(id);
}

export async function audioUrl(id: string): Promise<string | null> {
  const c = urls.get(id);
  if (c) return c;
  const blob = (await get(`ss-audio-${id}`)) as Blob | undefined;
  if (!blob) return null;
  const u = URL.createObjectURL(blob);
  urls.set(id, u);
  return u;
}
