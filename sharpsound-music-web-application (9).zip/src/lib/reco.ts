import { GENRES, GENRE_LIST, type Features, type Genre, type Mood, type Track } from "../data/catalog";
import { translate } from "./i18n";

const W: Record<keyof Features, number> = { energy: 1.3, bright: 0.8, dark: 1, tempo: 0.9, dense: 0.8, acoustic: 0.7 };
const KEYS = Object.keys(W) as (keyof Features)[];

export function featSim(a: Features, b: Features) {
  let d = 0;
  let w = 0;
  for (const k of KEYS) {
    d += W[k] * (a[k] - b[k]) ** 2;
    w += W[k];
  }
  return 1 - Math.sqrt(d / w);
}

export function trackSim(a: Track, b: Track) {
  return featSim(a.f, b.f) * 0.82 + (a.genre === b.genre ? 0.18 : 0);
}

export interface Stat {
  plays: number;
  secs: number;
  last: number;
}

export interface Taste {
  weights: Record<Genre, number>;
  f: Features;
  total: number;
  top: Genre | null;
  bpm: number;
}

export function computeTaste(all: Track[], stats: Record<string, Stat>, liked: Record<string, number>): Taste {
  const weights = Object.fromEntries(GENRE_LIST.map((g) => [g, 0])) as Record<Genre, number>;
  const f: Features = { energy: 0, bright: 0, dark: 0, tempo: 0, dense: 0, acoustic: 0 };
  let total = 0;
  let bpm = 0;
  for (const t of all) {
    const s = stats[t.id];
    const w = (s ? s.secs / 60 + s.plays * 0.4 : 0) + (liked[t.id] ? 4 : 0);
    if (w <= 0) continue;
    weights[t.genre] += w;
    total += w;
    bpm += t.bpm * w;
    for (const k of KEYS) f[k] += t.f[k] * w;
  }
  if (total > 0) {
    for (const k of KEYS) f[k] /= total;
    for (const g of GENRE_LIST) weights[g] /= total;
    bpm /= total;
  }
  let top: Genre | null = null;
  if (total > 0) top = [...GENRE_LIST].sort((a, b) => weights[b] - weights[a])[0];
  return { weights, f, total, top, bpm };
}

export function moodScore(t: Track, m: Mood) {
  let s = 0;
  let n = 0;
  for (const k of Object.keys(m.target) as (keyof Features)[]) {
    s += 1 - Math.abs(t.f[k] - (m.target[k] ?? 0));
    n++;
  }
  return (n ? s / n : 0) * 0.7 + (m.genres.includes(t.genre) ? 0.3 : 0);
}

export function rankForResonance(
  all: Track[],
  o: { seed?: Track | null; mood?: Mood | null; taste: Taste; disliked: Record<string, number>; liked: Record<string, number>; exclude: Set<string> }
): Track[] {
  const dislikedTracks = all.filter((t) => o.disliked[t.id]);
  return all
    .filter((t) => !o.disliked[t.id] && !o.exclude.has(t.id))
    .map((t) => {
      let s = 0;
      if (o.seed) s += featSim(t.f, o.seed.f) * 2 + (t.genre === o.seed.genre ? 0.35 : 0);
      if (o.mood) s += moodScore(t, o.mood) * 2.2;
      if (o.taste.total > 0) s += o.taste.weights[t.genre] * 1.5 + featSim(t.f, o.taste.f) * 0.6;
      if (o.liked[t.id]) s += 0.25;
      for (const d of dislikedTracks) s -= Math.max(0, featSim(t.f, d.f) - 0.85) * 2;
      s += Math.random() * 0.45;
      return { t, s };
    })
    .sort((a, b) => b.s - a.s)
    .map((x) => x.t);
}

/* ---------------- search ---------------- */

export function norm(s: string) {
  return s
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}\s#<]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function lev(a: string, b: string) {
  if (Math.abs(a.length - b.length) > 2) return 9;
  const dp = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return dp[b.length];
}

export interface SearchResult {
  exact: Track[];
  similar: { t: Track; s: number }[];
  vibe: boolean;
}

export function searchTracks(all: Track[], q: string): SearchResult {
  const nq = norm(q);
  if (!nq) return { exact: [], similar: [], vibe: false };
  const words = nq.split(" ").filter((w) => w.length >= 2);
  const scored = all.map((t) => {
    const hay = norm(`${t.title} ${t.artist} ${t.album} ${translate(t.title, "en")} ${translate(t.album, "en")}`);
    const toks = hay.split(" ");
    const aliases: Record<Genre, string[]> = {
      synthwave: ["retro", "neon", "night", "road", "sunset", "drive"], lofi: ["study", "rain", "cozy", "tea", "calm", "sad", "lo-fi"],
      phonk: ["bass", "drift", "car", "cowbell", "dark", "night"], techno: ["dance", "club", "rave", "acid", "electronic"],
      ambient: ["space", "sleep", "calm", "relax", "focus", "quiet"], rock: ["guitar", "punk", "garage", "loud", "energy"],
      trap: ["rap", "hip hop", "bass", "808", "dark"], hyperpop: ["glitch", "sugar", "happy", "energy", "fast", "pop"],
    };
    const rawTags = [...t.tags, ...GENRES[t.genre].tags, GENRES[t.genre].label];
    const tags = [...rawTags, ...rawTags.map((s) => translate(s, "en")), ...aliases[t.genre]].map(norm);
    let text = 0;
    let tag = 0;
    if (hay.includes(nq)) text += 3;
    for (const w of words) {
      if (hay.includes(w)) text += 1.2;
      else if (w.length >= 4 && toks.some((tk) => tk.length >= 3 && lev(w, tk) <= (w.length > 6 ? 2 : 1))) text += 0.9;
      if (tags.some((tg) => tg.startsWith(w) || (w.length >= 4 && w.startsWith(tg)))) tag += 1;
    }
    return { t, text, tag };
  });
  const exact = scored
    .filter((x) => x.text >= 0.9)
    .sort((a, b) => b.text - a.text)
    .map((x) => x.t);
  if (exact.length) {
    const top = exact[0];
    const ex = new Set(exact.map((t) => t.id));
    const similar = all
      .filter((t) => !ex.has(t.id))
      .map((t) => ({ t, s: trackSim(t, top) }))
      .sort((a, b) => b.s - a.s)
      .slice(0, 8);
    return { exact: exact.slice(0, 8), similar, vibe: false };
  }
  const tagged = scored.filter((x) => x.tag > 0).sort((a, b) => b.tag - a.tag);
  if (tagged.length) {
    const ref = tagged[0].t;
    return {
      exact: [],
      similar: tagged.slice(0, 10).map((x) => ({ t: x.t, s: Math.min(0.99, 0.55 + x.tag * 0.15 + trackSim(x.t, ref) * 0.2) })),
      vibe: true,
    };
  }
  return { exact: [], similar: [], vibe: false };
}
