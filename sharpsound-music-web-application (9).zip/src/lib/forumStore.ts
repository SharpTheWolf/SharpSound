import { create } from "zustand";
import { persist } from "zustand/middleware";
import { EMPTY_DRAFT, seedTopics, type ForumAuthor, type Topic, type TopicDraft } from "../data/forum";
import { censor } from "./censor";
import { plainBBCode } from "./bbcode";
import { localText } from "./i18n";

export type ForumResult = { ok: true; id: string } | { ok: false; error: "short" | "censor" | "name" | "missing" };
interface ForumState {
  topics: Topic[];
  profile: { name: string; hue: number; shape: number };
  votes: Record<string, boolean>;
  followed: string[];
  readAt: Record<string, number>;
  draft: TopicDraft;
  replyDrafts: Record<string, string>;
  setProfile: (name: string, hue: number, shape: number) => boolean;
  setDraft: (patch: Partial<TopicDraft>) => void;
  clearDraft: () => void;
  setReplyDraft: (id: string, body: string) => void;
  createTopic: (draft: TopicDraft) => ForumResult;
  updateTopic: (id: string, draft: TopicDraft) => ForumResult;
  deleteTopic: (id: string) => void;
  addReply: (topicId: string, body: string) => ForumResult;
  editReply: (topicId: string, replyId: string, body: string) => ForumResult;
  deleteReply: (topicId: string, replyId: string) => void;
  toggleVote: (id: string) => void;
  toggleFollow: (id: string) => void;
  markRead: (id: string) => void;
}

const uid = () => typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const cleanText = plainBBCode;
const validBody = (s: string) => cleanText(s).length >= 6 && s.length <= 10000;
const validDraft = (d: TopicDraft) => d.title.trim().length >= 4 && d.title.length <= 120 && (validBody(d.body) || !!d.image);
const safeText = (s: string) => censor(cleanText(s)).ok;
const safeDraft = (d: TopicDraft) => safeText(d.title) && safeText(d.body) && (!d.image || censor(localText(d.image.caption)).ok);

export const useForum = create<ForumState>()(persist((set, get) => {
  const me = (): ForumAuthor => ({ id: "me", name: get().profile.name || "Listener", hue: get().profile.hue, shape: get().profile.shape });
  return {
    topics: seedTopics(), profile: { name: "", hue: 270, shape: 0 }, votes: {}, followed: [], readAt: {},
    draft: { ...EMPTY_DRAFT }, replyDrafts: {},
    setProfile: (name, hue, shape) => {
      const n = name.trim();
      if (!n || n.length > 28 || !censor(n).ok || /[\[\]<>]/.test(n)) return false;
      set({ profile: { name: n, hue, shape }, topics: get().topics.map((t) => ({
        ...t, author: t.author.id === "me" ? { ...t.author, name: n, hue, shape } : t.author,
        replies: t.replies.map((r) => r.author.id === "me" ? { ...r, author: { ...r.author, name: n, hue, shape } } : r),
      })) });
      return true;
    },
    setDraft: (patch) => set({ draft: { ...get().draft, ...patch } }),
    clearDraft: () => set({ draft: { ...EMPTY_DRAFT } }),
    setReplyDraft: (id, body) => set({ replyDrafts: { ...get().replyDrafts, [id]: body } }),
    createTopic: (draft) => {
      if (!validDraft(draft)) return { ok: false, error: "short" };
      if (!safeDraft(draft)) return { ok: false, error: "censor" };
      const id = uid();
      const now = Date.now();
      const topic: Topic = { ...draft, id, title: draft.title.trim(), body: draft.body.trim(), author: me(), createdAt: now, lastAt: now, votes: 0, replies: [] };
      set({ topics: [topic, ...get().topics], draft: { ...EMPTY_DRAFT }, followed: [...get().followed, id] });
      return { ok: true, id };
    },
    updateTopic: (id, draft) => {
      const topic = get().topics.find((t) => t.id === id && t.author.id === "me");
      if (!topic) return { ok: false, error: "missing" };
      if (!validDraft(draft)) return { ok: false, error: "short" };
      if (!safeDraft(draft)) return { ok: false, error: "censor" };
      set({ topics: get().topics.map((t) => t.id === id ? { ...t, ...draft, title: draft.title.trim(), body: draft.body.trim(), editedAt: Date.now() } : t) });
      return { ok: true, id };
    },
    deleteTopic: (id) => set({ topics: get().topics.filter((t) => t.id !== id || t.author.id !== "me"), followed: get().followed.filter((x) => x !== id) }),
    addReply: (topicId, body) => {
      if (!get().topics.some((t) => t.id === topicId)) return { ok: false, error: "missing" };
      if (!validBody(body)) return { ok: false, error: "short" };
      if (!safeText(body)) return { ok: false, error: "censor" };
      const id = uid();
      const now = Date.now();
      set({ topics: get().topics.map((t) => t.id === topicId ? { ...t, lastAt: now, replies: [...t.replies, { id, author: me(), body: body.trim(), createdAt: now, votes: 0 }] } : t),
        replyDrafts: { ...get().replyDrafts, [topicId]: "" }, followed: get().followed.includes(topicId) ? get().followed : [...get().followed, topicId] });
      return { ok: true, id };
    },
    editReply: (topicId, replyId, body) => {
      const reply = get().topics.find((t) => t.id === topicId)?.replies.find((r) => r.id === replyId && r.author.id === "me");
      if (!reply) return { ok: false, error: "missing" };
      if (!validBody(body)) return { ok: false, error: "short" };
      if (!safeText(body)) return { ok: false, error: "censor" };
      set({ topics: get().topics.map((t) => t.id === topicId ? { ...t, replies: t.replies.map((r) => r.id === replyId ? { ...r, body: body.trim(), editedAt: Date.now() } : r) } : t) });
      return { ok: true, id: replyId };
    },
    deleteReply: (topicId, replyId) => set({ topics: get().topics.map((t) => t.id === topicId ? { ...t, replies: t.replies.filter((r) => r.id !== replyId || r.author.id !== "me") } : t) }),
    toggleVote: (id) => set({ votes: { ...get().votes, [id]: !get().votes[id] } }),
    toggleFollow: (id) => set({ followed: get().followed.includes(id) ? get().followed.filter((x) => x !== id) : [...get().followed, id] }),
    markRead: (id) => set({ readAt: { ...get().readAt, [id]: Date.now() } }),
  };
}, { name: "ss-forum-v1" }));