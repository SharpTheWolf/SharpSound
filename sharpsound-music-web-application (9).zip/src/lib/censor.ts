/* Lightweight profanity filter: RU (incl. latin look-alikes), translit and EN. */

const CYR_LOOK: Record<string, string> = {
  a: "а", b: "в", c: "с", e: "е", h: "н", k: "к", m: "м", o: "о", p: "р", t: "т", x: "х", y: "у",
  u: "и", n: "п", r: "г", "3": "з", "0": "о", "4": "ч", "6": "б", "@": "а", "ё": "е",
};
const LAT_LEET: Record<string, string> = { "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", $: "s", "!": "i" };

const RU: RegExp[] = [
  /^(?:[а-я]{0,4})?ху[йеёяию]/,
  /пизд/,
  /^(?:за|на|при|раз|вы|от|у|по|до|об|с|в|из|недо|пере|под|про)?ъ?[её]б(?:а|у|л|ы|н|и|ё|о|ть|ск|ш)/,
  /^бля(?:д|т|$)/,
  /^(?:вы|за|на|раз|у)?бляд/,
  /^сук(?:а|и|у|ой|е|ам|ами|ах)?$/,
  /муда[кч]|мудил/,
  /^пид[оае]р|^пидр/,
  /залуп/,
  /г[ао]ндон/,
  /шлюх/,
  /дроч/,
  /^манд[аеуы]$/,
];
const SAFE_RU = [/^себ/, /^себ/, /^вебинар/, /^небо/, /^вебк/];

const LAT: RegExp[] = [
  /fuck|fuk|fck|phuck/,
  /shit/,
  /bitch/,
  /cunt/,
  /whore/,
  /nigg/,
  /^fag(got)?s?$/,
  /motherf/,
  /^dick(head)?s?$/,
  /asshole/,
  /^slut/,
  /hu[iy]$|^xu[iy]|nahu[iy]|pohu[iy]/,
  /pizd/,
  /^bly(a|at|ad)/,
  /^suka$/,
  /^eba(t|l|n)|^ebl/,
  /mudak|pidor|pidar|zalup/,
];

function tokens(text: string): string[] {
  const raw = text.toLowerCase().split(/\s+/).filter(Boolean);
  const out: string[] = [];
  let run = "";
  for (const w of raw) {
    const clean = w.replace(/[^\p{L}\p{N}@$!]/gu, "");
    if (clean.length === 1) {
      run += clean;
      continue;
    }
    if (run.length > 1) out.push(run);
    run = "";
    if (clean) out.push(clean);
  }
  if (run.length > 1) out.push(run);
  return out;
}

function isBad(word: string): boolean {
  const w = word.toLowerCase().replace(/[^\p{L}\p{N}@$!]/gu, "");
  if (!w) return false;
  const cyr = Array.from(w, (ch) => CYR_LOOK[ch] ?? ch).join("");
  if (!SAFE_RU.some((r) => r.test(cyr)) && RU.some((r) => r.test(cyr))) return true;
  const lat = Array.from(w, (ch) => LAT_LEET[ch] ?? ch).join("");
  return LAT.some((r) => r.test(lat));
}

export function censor(text: string): { ok: boolean; bad: string[]; masked: string } {
  const bad = tokens(text).filter(isBad);
  const masked = text.replace(/\S+/g, (tok) => (isBad(tok) ? tok[0] + "*".repeat(Math.max(1, tok.length - 1)) : tok));
  return { ok: bad.length === 0, bad, masked };
}
