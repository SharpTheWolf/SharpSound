export interface BBNode {
  tag: string;
  attr: string;
  value?: string;
  children: BBNode[];
}

const TAGS = "h1|h2|h3|b|u|i|strike|spoiler|noparse|hr|url|list|olist|quote|code|table|tr|th|td|img|track";

/** Parse a limited BBCode tree. User HTML never enters the DOM as HTML. */
export function parseBBCode(input: string): BBNode[] {
  const source = input.slice(0, 10000);
  const lower = source.toLowerCase();
  const root: BBNode = { tag: "root", attr: "", children: [] };
  const stack = [root];
  const token = new RegExp(`\\[(\\/?)(?:(${TAGS})(?=\\s|=|\\])([^\\]]*)|(\\*))\\]`, "gi");
  let cursor = 0;
  const appendText = (value: string) => {
    if (value) stack[stack.length - 1].children.push({ tag: "text", attr: "", value, children: [] });
  };
  let m: RegExpExecArray | null;
  while ((m = token.exec(source)) !== null) {
    appendText(source.slice(cursor, m.index));
    cursor = token.lastIndex;
    const tag = (m[2] ?? "li").toLowerCase();
    const attr = (m[3] ?? "").trim();
    if (tag === "li") {
      let list = stack.length - 1;
      while (list > 0 && stack[list].tag !== "list" && stack[list].tag !== "olist") list--;
      if (!list) { appendText("[*]"); continue; }
      stack.length = list + 1;
      const li: BBNode = { tag: "li", attr: "", children: [] };
      stack[list].children.push(li);
      stack.push(li);
      continue;
    }
    if (m[1]) {
      if (tag === "hr" || tag === "track") continue;
      let i = stack.length - 1;
      while (i > 0 && stack[i].tag !== tag) i--;
      if (i) stack.length = i;
      else appendText(m[0]);
      continue;
    }
    if (stack.length > 24) { appendText(m[0]); continue; }
    const node: BBNode = { tag, attr, children: [] };
    stack[stack.length - 1].children.push(node);
    if (tag === "code" || tag === "noparse") {
      const closing = `[/${tag}]`;
      const end = lower.indexOf(closing, cursor);
      node.value = source.slice(cursor, end === -1 ? source.length : end);
      cursor = end === -1 ? source.length : end + closing.length;
      token.lastIndex = cursor;
    } else if (tag !== "hr" && tag !== "track") stack.push(node);
  }
  appendText(source.slice(cursor));
  return root.children;
}

export function nodeText(node: BBNode): string {
  return node.value ?? node.children.map(nodeText).join("");
}

export function plainBBCode(source: string): string {
  return parseBBCode(source).map((n) => nodeText(n)).join(" ").replace(/\s+/g, " ").trim();
}

export function safeUrl(input: string): string | null {
  const value = input.trim().replace(/^=["']?|["']$/g, "");
  if (!value || /[\s<>"']/.test(value)) return null;
  try {
    const url = new URL(/^www\./i.test(value) ? `https://${value}` : value);
    return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url.href : null;
  } catch { return null; }
}

export function youtubeId(url: string): string | null {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "").replace(/^m\./, "");
    let id: string | null = null;
    if (host === "youtu.be") id = u.pathname.split("/")[1];
    if (["youtube.com", "youtube-nocookie.com"].includes(host)) {
      id = u.searchParams.get("v");
      if (!id && /^\/(embed|shorts)\//.test(u.pathname)) id = u.pathname.split("/")[2];
    }
    return id && /^[\w-]{11}$/.test(id) ? id : null;
  } catch { return null; }
}

export function safeImage(url: string): string | null {
  if (/^data:image\/(?:jpeg|png|webp);base64,[a-z\d+/=]+$/i.test(url) && url.length < 1500000) return url;
  const safe = safeUrl(url);
  return safe?.startsWith("https://") ? safe : null;
}