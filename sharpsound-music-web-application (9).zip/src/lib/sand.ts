export interface Region {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

interface Grain {
  x: number;
  y: number;
  vx: number;
  vy: number;
  s: number;
  c: string;
}

interface TexPoint {
  x: number;
  y: number;
  s: number;
  c: string;
  a: number;
}

const GRAINS = ["#e9d5ff", "#c4b5fd", "#a78bfa", "#8b5cf6", "#7c3aed", "#d9f99d", "#bef264", "#a3e635", "#84cc16", "#ffffff"];
const TEX = ["#e9d5ff", "#c4b5fd", "#a78bfa", "#8b5cf6", "#d9f99d", "#bef264", "#a3e635", "#84cc16"];

const rand = (a: number, b: number) => a + Math.random() * (b - a);

/** Pouring-sand scene: grains fall from a source, pile up and flood the region. */
export class SandScene {
  private grains: Grain[] = [];
  private tex: TexPoint[] = [];
  private t = 0;
  private acc = 0;
  private tumbleAcc = 0;

  constructor(
    private region: Region,
    private source: { x: number; y: number }
  ) {
    const area = Math.max(0, (region.x1 - region.x0) * (region.y1 - region.y0));
    const n = Math.min(2400, Math.floor(area / 560));
    for (let i = 0; i < n; i++) {
      this.tex.push({
        x: rand(region.x0, region.x1),
        y: rand(region.y0, region.y1),
        s: Math.random() < 0.84 ? 1 : 2,
        c: TEX[Math.floor(Math.random() * TEX.length)],
        a: rand(0.12, 0.48),
      });
    }
  }

  /** Sand surface height at x: a pile that is higher where the sand pours in. */
  surfaceY(x: number, level: number) {
    const { x0, x1, y0, y1 } = this.region;
    const W = Math.max(1, x1 - x0);
    const H = Math.max(1, y1 - y0);
    const k = Math.max(0, Math.min(1, (x - x0) / W));
    const base = y1 - level * (H + 80);
    const pile = 58 * level * Math.pow(1 - k, 1.5);
    const wave = (Math.sin(x * 0.012 + this.t * 1.7) * 5 + Math.sin(x * 0.029 - this.t * 2.3) * 2.5) * level;
    return base - pile - wave;
  }

  update(dt: number, level: number, pouring: boolean, falling: boolean) {
    this.t += dt;
    const g = falling ? 3400 : 1550;
    if (pouring) {
      this.acc += 480 * dt;
      while (this.acc >= 1) {
        this.acc--;
        if (this.grains.length < 1400)
          this.grains.push({
            x: this.source.x + rand(-14, 22),
            y: this.source.y + rand(-8, 12),
            vx: rand(90, 340),
            vy: rand(-40, 90),
            s: Math.random() < 0.78 ? 1 : 2,
            c: GRAINS[Math.floor(Math.random() * GRAINS.length)],
          });
      }
      this.tumbleAcc += 160 * dt;
      while (this.tumbleAcc >= 1) {
        this.tumbleAcc--;
        if (this.grains.length < 1400 && level > 0.05) {
          const x = rand(this.region.x0, this.region.x1);
          this.grains.push({
            x,
            y: this.surfaceY(x, level) - rand(0, 16),
            vx: rand(40, 220),
            vy: rand(-55, 25),
            s: Math.random() < 0.85 ? 1 : 2,
            c: GRAINS[Math.floor(Math.random() * GRAINS.length)],
          });
        }
      }
    }
    const alive: Grain[] = [];
    for (const gr of this.grains) {
      gr.vy += g * dt;
      gr.x += gr.vx * dt;
      gr.y += gr.vy * dt;
      const sy = this.surfaceY(gr.x, level);
      if (gr.y >= sy && gr.vy > 0) {
        if (Math.random() < 0.22 && gr.s === 1) {
          gr.y = sy - 1;
          gr.vy = -rand(50, 190);
          gr.vx = rand(70, 210);
          alive.push(gr);
        }
        continue;
      }
      if (gr.y > this.region.y1 + 80 || gr.x > this.region.x1 + 80 || gr.x < this.region.x0 - 80) continue;
      alive.push(gr);
    }
    this.grains = alive;
  }

  draw(ctx: CanvasRenderingContext2D, level: number, fallY: number) {
    const { x0, y0, x1, y1 } = this.region;
    if (level <= 0.001) return;
    ctx.save();
    ctx.translate(0, fallY);

    const top = y1 - level * (y1 - y0 + 80);
    const grad = ctx.createLinearGradient(0, top, 0, y1);
    grad.addColorStop(0, "#ecffb5");
    grad.addColorStop(0.28, "#b9f25e");
    grad.addColorStop(0.55, "#a3e635");
    grad.addColorStop(0.75, "#a78bfa");
    grad.addColorStop(1, "#6d28d9");

    ctx.beginPath();
    ctx.moveTo(x0 - 3, y1 + 3);
    for (let x = x0 - 3; x <= x1 + 3; x += 5) ctx.lineTo(x, this.surfaceY(x, level));
    ctx.lineTo(x1 + 3, y1 + 3);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    for (const p of this.tex) {
      if (p.y < this.surfaceY(p.x, level) - 1) continue;
      ctx.globalAlpha = p.a;
      ctx.fillStyle = p.c;
      ctx.fillRect(p.x, p.y, p.s, p.s);
    }
    ctx.globalAlpha = 1;

    ctx.beginPath();
    for (let x = x0 - 3; x <= x1 + 3; x += 5) {
      const y = this.surfaceY(x, level);
      if (x <= x0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.lineWidth = 2;
    ctx.strokeStyle = "rgba(240,255,200,0.6)";
    ctx.stroke();
    ctx.save();
    ctx.translate(0, 4);
    ctx.beginPath();
    for (let x = x0 - 3; x <= x1 + 3; x += 5) {
      const y = this.surfaceY(x, level);
      if (x <= x0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.lineWidth = 5;
    ctx.strokeStyle = "rgba(109,40,217,0.3)";
    ctx.stroke();
    ctx.restore();

    for (const gr of this.grains) {
      ctx.fillStyle = gr.c;
      ctx.fillRect(gr.x, gr.y, gr.s, gr.s);
    }
    ctx.restore();
  }
}

export function roundRectPath(ctx: CanvasRenderingContext2D, r: Region, radius: number) {
  const w = r.x1 - r.x0;
  const h = r.y1 - r.y0;
  const rad = Math.max(0, Math.min(radius, Math.min(w, h) / 2));
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") {
    ctx.roundRect(r.x0, r.y0, w, h, rad);
    return;
  }
  ctx.moveTo(r.x0 + rad, r.y0);
  ctx.arcTo(r.x1, r.y0, r.x1, r.y1, rad);
  ctx.arcTo(r.x1, r.y1, r.x0, r.y1, rad);
  ctx.arcTo(r.x0, r.y1, r.x0, r.y0, rad);
  ctx.arcTo(r.x0, r.y0, r.x1, r.y0, rad);
  ctx.closePath();
}
