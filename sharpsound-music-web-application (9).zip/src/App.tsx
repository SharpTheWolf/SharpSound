import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { useEffect } from "react";
import { engine } from "./audio/engine";
import Chibi from "./components/Chibi";
import NavTransition from "./components/NavTransition";
import PlayerBar from "./components/PlayerBar";
import { Backdrop, MobileNav, MobileTop, Sidebar, Toast } from "./components/Shell";
import { loadUploads } from "./lib/db";
import Collection from "./pages/Collection";
import Contribute from "./pages/Contribute";
import Forum from "./pages/Forum";
import Home from "./pages/Home";
import Recognize from "./pages/Recognize";
import SearchPage from "./pages/Search";
import Studio from "./pages/Studio";
import { useStore, type Tab } from "./store";
import { useLocale } from "./lib/i18n";

const PAGES: Record<Tab, () => React.JSX.Element> = {
  home: Home,
  search: SearchPage,
  recognize: Recognize,
  collection: Collection,
  contribute: Contribute,
  community: Forum,
  studio: Studio,
};

export default function App() {
  const tab = useStore((s) => s.tab);
  const lang = useLocale((s) => s.lang);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.title = lang === "en" ? "SharpSound | Sound, sharpened for you" : "SharpSound | Звук, заточенный под тебя";
  }, [lang]);

  useEffect(() => {
    const st = useStore.getState();
    document.documentElement.setAttribute("data-theme", st.theme);
    engine.setVolume(st.volume);
    loadUploads().then((u) => useStore.getState().setUploads(u));
    const iv = window.setInterval(() => useStore.getState().tick(1), 1000);
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      if (el && (el.closest("input, textarea, select, button, a, [role=dialog]") || el.isContentEditable)) return;
      const s = useStore.getState();
      if (e.code === "Space") {
        e.preventDefault();
        s.togglePlay();
      } else if (e.code === "ArrowRight" && e.shiftKey) s.next();
      else if (e.code === "ArrowLeft" && e.shiftKey) s.prev();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      clearInterval(iv);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [tab]);

  const Page = PAGES[tab];

  return (
    <MotionConfig reducedMotion="user">
      <style>{`:root{--chibi-floor:146px}@media (min-width:768px){:root{--chibi-floor:95px}}`}</style>
      <Backdrop />
      <Sidebar />
      <MobileTop />
      <main className="relative z-10 px-3 pb-[210px] pt-[86px] sm:px-5 md:pb-[150px] md:pl-[124px] md:pr-5 md:pt-6 lg:pl-[290px] lg:pr-8">
        <div className="mx-auto max-w-[1280px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 26, filter: "blur(12px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -18, filter: "blur(10px)" }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <Page />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      <PlayerBar />
      <Chibi />
      <MobileNav />
      <Toast />
      <NavTransition />
    </MotionConfig>
  );
}
