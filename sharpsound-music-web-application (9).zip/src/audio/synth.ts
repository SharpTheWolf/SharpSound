/* SharpSound procedural music engine.
   Every catalog track is generated from (seed, genre) and rendered in real time with Web Audio.
   The same scheduler works for realtime AudioContext and OfflineAudioContext (fingerprinting). */

export type Genre = "synthwave" | "lofi" | "phonk" | "techno" | "ambient" | "rock" | "trap" | "hyperpop";

export const rng = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

export const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

const SCALES: Record<string, number[]> = {
  minor: [0, 2, 3, 5, 7, 8, 10],
  major: [0, 2, 4, 5, 7, 9, 11],
  dorian: [0, 2, 3, 5, 7, 9, 10],
  phrygian: [0, 1, 3, 5, 7, 8, 10],
  harm: [0, 2, 3, 5, 7, 8, 11],
};

export type BassI = "saw" | "sine" | "808" | "acid" | "drone" | "pick";
export type ChordI = "pad" | "rhodes" | "stab" | "guitar" | "supersaw" | "none";
export type LeadI = "saw" | "pluck" | "cowbell" | "acid" | "bell" | "gtr" | "chip";
export type ArpI = "square" | "bell" | "chip" | "none";
export type SecType = "intro" | "verse" | "chorus" | "break" | "outro";

interface Preset {
  bpm: [number, number];
  scales: string[];
  progs: number[][];
  kick: string[];
  snare: string[];
  hat: string[];
  bass: string[];
  chord: string[];
  arp: string[];
  bassI: BassI;
  bassOct: number;
  bassMax: number;
  chordI: ChordI;
  seventh: boolean;
  leadI: LeadI;
  leadOct: number;
  density: number;
  sixteenth: boolean;
  arpI: ArpI;
  swing: number;
  clap: boolean;
  crash: boolean;
  riser: boolean;
  fills: boolean;
  crackle: boolean;
  busCut: number;
  kickTone: number;
  kickDecay: number;
  hatV: number;
  sections: number;
  layers?: Partial<Record<SecType, string>>;
}

const PRESETS: Record<Genre, Preset> = {
  synthwave: {
    bpm: [98, 116], scales: ["minor", "dorian"], progs: [[0, 5, 2, 6], [0, 6, 5, 6], [0, 3, 5, 4]],
    kick: ["x...x...x...x..."], snare: ["....x.......x..."], hat: ["..x...x...x...x.", "x.x.x.x.x.x.x.x."],
    bass: ["x.o.x.o.x.o.x.o.", "xxoxxxoxxxoxxxox"], chord: ["x..............."], arp: ["xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx"],
    bassI: "saw", bassOct: 1, bassMax: 2, chordI: "pad", seventh: false,
    leadI: "saw", leadOct: 3, density: 0.32, sixteenth: false, arpI: "square",
    swing: 0, clap: false, crash: true, riser: true, fills: true, crackle: false,
    busCut: 16000, kickTone: 1, kickDecay: 0.42, hatV: 0.09, sections: 8,
    layers: { verse: "k s h b c a" },
  },
  lofi: {
    bpm: [72, 86], scales: ["dorian", "major", "minor"], progs: [[1, 4, 0, 5], [0, 5, 1, 4], [3, 2, 1, 0]],
    kick: ["x.....x.x.......", "x......xx.....x."], snare: ["....x.......x..."], hat: ["x.x.x.x.x.x.x.x.", "x.xxx.x.x.xxx.x."],
    bass: ["x.....x.x.......", "x.......x...x..."], chord: ["x.....x.........", "x.........x....."], arp: ["................"],
    bassI: "sine", bassOct: 1, bassMax: 6, chordI: "rhodes", seventh: true,
    leadI: "pluck", leadOct: 3, density: 0.2, sixteenth: false, arpI: "none",
    swing: 0.2, clap: false, crash: false, riser: false, fills: false, crackle: true,
    busCut: 4200, kickTone: 0.8, kickDecay: 0.35, hatV: 0.06, sections: 7,
  },
  phonk: {
    bpm: [128, 146], scales: ["phrygian", "minor"], progs: [[0, 1, 0, 6], [0, 0, 1, 1], [0, 5, 6, 0]],
    kick: ["x.....x...x.....", "x......x..x....."], snare: ["....x.......x..."], hat: ["xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xr"],
    bass: ["x.....x...x.....", "x......x..x....."], chord: ["x..............."], arp: ["................"],
    bassI: "808", bassOct: 0, bassMax: 6, chordI: "pad", seventh: false,
    leadI: "cowbell", leadOct: 3, density: 0.5, sixteenth: true, arpI: "none",
    swing: 0.04, clap: true, crash: false, riser: true, fills: false, crackle: false,
    busCut: 14000, kickTone: 0.9, kickDecay: 0.55, hatV: 0.07, sections: 8,
    layers: { intro: "l h", verse: "k s h b l", chorus: "k s h b l c", break: "l c" },
  },
  techno: {
    bpm: [124, 132], scales: ["minor", "phrygian"], progs: [[0, 0, 0, 0], [0, 0, 5, 5], [0, 6, 0, 5]],
    kick: ["x...x...x...x..."], snare: ["....x.......x..."], hat: ["xxoxxxoxxxoxxxox", "..o...o...o...o."],
    bass: [".xxx.xxx.xxx.xxx", "..x...x...x...x."], chord: ["......x.......x.", "...x.....x....x."], arp: ["................"],
    bassI: "acid", bassOct: 1, bassMax: 1, chordI: "stab", seventh: false,
    leadI: "acid", leadOct: 2, density: 0.55, sixteenth: true, arpI: "none",
    swing: 0, clap: true, crash: false, riser: true, fills: false, crackle: false,
    busCut: 18000, kickTone: 1.05, kickDecay: 0.38, hatV: 0.08, sections: 10,
    layers: { intro: "k h", verse: "k s h b", chorus: "k s h b c l", break: "c l h", outro: "k h b" },
  },
  ambient: {
    bpm: [60, 72], scales: ["major", "dorian"], progs: [[0, 3, 5, 4], [0, 5, 3, 4], [0, 4, 5, 3]],
    kick: ["................"], snare: ["................"], hat: ["........x.......", "................"],
    bass: ["x..............."], chord: ["x..............."], arp: ["x.....x.....x...", "x.......x......."],
    bassI: "drone", bassOct: 1, bassMax: 16, chordI: "pad", seventh: true,
    leadI: "bell", leadOct: 3, density: 0.1, sixteenth: false, arpI: "bell",
    swing: 0, clap: false, crash: false, riser: false, fills: false, crackle: false,
    busCut: 9000, kickTone: 1, kickDecay: 0.4, hatV: 0.03, sections: 6,
    layers: { intro: "c", verse: "c b a", chorus: "c b l a h", break: "c l", outro: "c" },
  },
  rock: {
    bpm: [118, 146], scales: ["minor", "dorian"], progs: [[0, 5, 6, 0], [0, 3, 4, 3], [0, 6, 3, 4]],
    kick: ["x.....x.x.......", "x.......x.x....."], snare: ["....x.......x..."], hat: ["x.x.x.x.x.x.x.x."],
    bass: ["x.x.x.x.x.x.x.x."], chord: ["x.x.x.x.x.x.x.x."], arp: ["................"],
    bassI: "pick", bassOct: 1, bassMax: 2, chordI: "guitar", seventh: false,
    leadI: "gtr", leadOct: 3, density: 0.34, sixteenth: false, arpI: "none",
    swing: 0, clap: false, crash: true, riser: false, fills: true, crackle: false,
    busCut: 15000, kickTone: 1, kickDecay: 0.32, hatV: 0.08, sections: 8,
    layers: { intro: "c h", break: "c h l" },
  },
  trap: {
    bpm: [136, 150], scales: ["minor", "harm"], progs: [[0, 5, 0, 6], [0, 3, 5, 4], [0, 0, 5, 6]],
    kick: ["x......x..x.....", "x.........x..x.."], snare: ["........x......."],
    hat: ["xxxxxxxxxxxrxxxx", "x.x.x.xrx.x.x.xx", "xxx.xxx.xrxxx.xx"],
    bass: ["x......x..x.....", "x.........x..x.."], chord: ["x..............."], arp: ["................"],
    bassI: "808", bassOct: 0, bassMax: 8, chordI: "pad", seventh: false,
    leadI: "bell", leadOct: 3, density: 0.28, sixteenth: false, arpI: "none",
    swing: 0, clap: true, crash: false, riser: false, fills: false, crackle: false,
    busCut: 15000, kickTone: 0.9, kickDecay: 0.5, hatV: 0.065, sections: 8,
  },
  hyperpop: {
    bpm: [150, 164], scales: ["major"], progs: [[0, 4, 5, 3], [3, 4, 0, 5], [0, 5, 3, 4]],
    kick: ["x...x...x...x...", "x..x..x...x..x.."], snare: ["....x.......x..."], hat: ["xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xr"],
    bass: ["x.x.x.x.x.x.x.x.", "x.xxx.xxx.xxx.xx"], chord: ["..x...x...x...x."], arp: ["x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx"],
    bassI: "saw", bassOct: 1, bassMax: 2, chordI: "supersaw", seventh: false,
    leadI: "chip", leadOct: 4, density: 0.5, sixteenth: true, arpI: "chip",
    swing: 0, clap: true, crash: true, riser: true, fills: true, crackle: false,
    busCut: 18000, kickTone: 1.1, kickDecay: 0.36, hatV: 0.07, sections: 10,
  },
};

const DEF_LAYERS: Record<SecType, string> = {
  intro: "c h",
  verse: "k s h b c",
  chorus: "k s h b c l a",
  break: "c l",
  outro: "c b h",
};
const SEQ: SecType[] = ["intro", "verse", "chorus", "break", "verse", "chorus", "chorus", "break", "chorus", "verse", "chorus"];

export interface Comp {
  genre: Genre;
  bpm: number;
  sd: number;
  root: number;
  scale: number[];
  prog: number[];
  motif: (number | null)[];
  motif2: (number | null)[];
  arpSeq: number[];
  P: Preset;
  kickP: string;
  snareP: string;
  hatP: string;
  bassP: string;
  chordP: string;
  arpP: string;
  bars: number;
  layers: string[];
  secStart: Set<number>;
  riser: Set<number>;
  fill: Set<number>;
  chorusBar: number;
  totalSteps: number;
  duration: number;
  types: SecType[];
  /** Optional per-stem loudness used by the Mini Studio mixer. */
  gains?: Record<string, number>;
}

function makeMotif(r: () => number, density: number, sixteenth: boolean) {
  const m: (number | null)[] = [];
  let d = Math.floor(r() * 5);
  for (let i = 0; i < 32; i++) {
    const strong = i % 4 === 0;
    const off = i % 2 === 1;
    const p = density * (strong ? 1.6 : off ? (sixteenth ? 0.85 : 0.35) : 1);
    if (r() < p) {
      d += Math.round((r() - 0.5) * 4.5);
      if (d < -2) d = -2 + Math.floor(r() * 3);
      if (d > 9) d = 9 - Math.floor(r() * 3);
      m.push(d);
    } else m.push(null);
  }
  if (m[0] == null) m[0] = 0;
  return m;
}

export function compose(seed: number, genre: Genre): Comp {
  const P = PRESETS[genre];
  const r = rng(seed);
  const pick = <T,>(a: T[]): T => a[Math.floor(r() * a.length)];
  const bpm = Math.round(P.bpm[0] + r() * (P.bpm[1] - P.bpm[0]));
  const sd = 60 / bpm / 4;
  const root = 33 + Math.floor(r() * 10);
  const scale = SCALES[pick(P.scales)];
  const prog = pick(P.progs);
  const motif = makeMotif(r, P.density, P.sixteenth);
  const motif2 = motif.map((v, i) => (i >= 24 ? (r() < P.density + 0.2 ? Math.round(r() * 4) : null) : v));
  motif2[28] = 0;
  const arpSeq = pick([[0, 1, 2, 3], [0, 1, 2, 3, 2, 1], [0, 2, 1, 3], [3, 2, 1, 0]]);
  const types: SecType[] = [...SEQ.slice(0, P.sections - 1), "outro"];
  const layers: string[] = [];
  const secStart = new Set<number>();
  const riser = new Set<number>();
  const fill = new Set<number>();
  let chorusBar = -1;
  types.forEach((ty, si) => {
    const L = P.layers?.[ty] ?? DEF_LAYERS[ty];
    for (let b = 0; b < 8; b++) layers.push(L);
    secStart.add(si * 8);
    if (types[si + 1] === "chorus") riser.add(si * 8 + 7);
    if (ty !== "break" && ty !== "intro") fill.add(si * 8 + 7);
    if (ty === "chorus" && chorusBar < 0) chorusBar = si * 8;
  });
  if (chorusBar < 0) chorusBar = 8;
  const bars = types.length * 8;
  const totalSteps = bars * 16;
  return {
    genre, bpm, sd, root, scale, prog, motif, motif2, arpSeq, P,
    kickP: pick(P.kick), snareP: pick(P.snare), hatP: pick(P.hat), bassP: pick(P.bass),
    chordP: pick(P.chord), arpP: pick(P.arp),
    bars, layers, secStart, riser, fill, chorusBar, totalSteps, types,
    duration: totalSteps * sd + 1.2,
  };
}

/* ------------------------------------------------------------------ */
/* Instruments                                                         */
/* ------------------------------------------------------------------ */

export interface Bus {
  dry: GainNode;
  wet: GainNode;
  echo: GainNode;
  fader: GainNode;
  nodes: AudioNode[];
}

type Ctx = BaseAudioContext;

const NOISE = new WeakMap<Ctx, AudioBuffer>();
function noiseBuf(ctx: Ctx) {
  let b = NOISE.get(ctx);
  if (!b) {
    b = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    NOISE.set(ctx, b);
  }
  return b;
}
const CURVES = new Map<number, Float32Array<ArrayBuffer>>();
function curve(k: number) {
  let c = CURVES.get(k);
  if (!c) {
    const n = 1024;
    c = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      c[i] = ((1 + k) * x) / (1 + k * Math.abs(x));
    }
    CURVES.set(k, c);
  }
  return c;
}
const IRS = new WeakMap<Ctx, AudioBuffer>();
function impulse(ctx: Ctx) {
  let b = IRS.get(ctx);
  if (!b) {
    const len = Math.floor(ctx.sampleRate * 2.6);
    b = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = b.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    }
    IRS.set(ctx, b);
  }
  return b;
}

function noiseSrc(ctx: Ctx) {
  const n = ctx.createBufferSource();
  n.buffer = noiseBuf(ctx);
  return n;
}

function kick(ctx: Ctx, b: Bus, t: number, v: number, tone: number, decay: number) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = "sine";
  o.frequency.setValueAtTime(170 * tone, t);
  o.frequency.exponentialRampToValueAtTime(50 * tone, t + 0.09);
  o.frequency.exponentialRampToValueAtTime(38, t + decay);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(v, t + 0.004);
  g.gain.exponentialRampToValueAtTime(0.0001, t + decay);
  o.connect(g);
  g.connect(b.dry);
  o.start(t);
  o.stop(t + decay + 0.03);
}

function snare(ctx: Ctx, b: Bus, t: number, v: number) {
  const n = noiseSrc(ctx);
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 1400;
  const g = ctx.createGain();
  g.gain.setValueAtTime(v, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
  n.connect(hp);
  hp.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
  n.start(t, Math.random() * 1.5);
  n.stop(t + 0.22);
  const o = ctx.createOscillator();
  o.type = "triangle";
  o.frequency.setValueAtTime(220, t);
  o.frequency.exponentialRampToValueAtTime(140, t + 0.08);
  const og = ctx.createGain();
  og.gain.setValueAtTime(v * 0.7, t);
  og.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
  o.connect(og);
  og.connect(b.dry);
  o.start(t);
  o.stop(t + 0.13);
}

function clap(ctx: Ctx, b: Bus, t: number, v: number) {
  const n = noiseSrc(ctx);
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 1600;
  bp.Q.value = 0.9;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  [0, 0.011, 0.022].forEach((d) => {
    g.gain.setValueAtTime(v, t + d);
    g.gain.exponentialRampToValueAtTime(v * 0.25, t + d + 0.009);
  });
  g.gain.setValueAtTime(v * 0.8, t + 0.031);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
  n.connect(bp);
  bp.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
  n.start(t, Math.random() * 1.5);
  n.stop(t + 0.25);
}

function hat(ctx: Ctx, b: Bus, t: number, v: number, open: boolean) {
  const n = noiseSrc(ctx);
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = Math.min(7500, ctx.sampleRate / 2 - 1500);
  const g = ctx.createGain();
  const d = open ? 0.28 : 0.045;
  g.gain.setValueAtTime(v, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  n.connect(hp);
  hp.connect(g);
  g.connect(b.dry);
  n.start(t, Math.random() * 1.5);
  n.stop(t + d + 0.02);
}

function crash(ctx: Ctx, b: Bus, t: number, v: number) {
  const n = noiseSrc(ctx);
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 4000;
  const g = ctx.createGain();
  g.gain.setValueAtTime(v, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
  n.connect(hp);
  hp.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
  n.start(t, 0);
  n.stop(t + 1.65);
}

function riser(ctx: Ctx, b: Bus, t: number, dur: number) {
  const n = noiseSrc(ctx);
  n.loop = true;
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.Q.value = 3;
  bp.frequency.setValueAtTime(300, t);
  bp.frequency.exponentialRampToValueAtTime(Math.min(7000, ctx.sampleRate / 2 - 500), t + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.09, t + dur * 0.95);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  n.connect(bp);
  bp.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
  n.start(t);
  n.stop(t + dur + 0.02);
}

function crackle(ctx: Ctx, b: Bus, t: number, dur: number) {
  const n = noiseSrc(ctx);
  n.loop = true;
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 3200;
  bp.Q.value = 0.6;
  const g = ctx.createGain();
  g.gain.value = 0.012;
  n.connect(bp);
  bp.connect(g);
  g.connect(b.dry);
  n.start(t, Math.random());
  n.stop(t + dur);
  for (let i = 0; i < 3; i++) {
    const c = noiseSrc(ctx);
    const cg = ctx.createGain();
    const ct = t + Math.random() * dur;
    cg.gain.setValueAtTime(0.03 + Math.random() * 0.05, ct);
    cg.gain.exponentialRampToValueAtTime(0.0001, ct + 0.004);
    c.connect(cg);
    cg.connect(b.dry);
    c.start(ct, Math.random());
    c.stop(ct + 0.006);
  }
}

interface VO {
  type: OscillatorType;
  v: number;
  a?: number;
  r?: number;
  cut?: number;
  env?: number;
  q?: number;
  det?: number;
  n?: number;
  wet?: boolean;
  echo?: boolean;
  drive?: number;
  vib?: number;
  hold?: number;
}

function voice(ctx: Ctx, b: Bus, t: number, f: number, dur: number, o: VO) {
  const a = o.a ?? 0.005;
  const r = o.r ?? 0.1;
  const n = o.n ?? 1;
  const det = o.det ?? 0;
  const ny = ctx.sampleRate / 2 - 200;
  const fl = ctx.createBiquadFilter();
  fl.type = "lowpass";
  fl.Q.value = o.q ?? 0.7;
  const cut = Math.min(o.cut ?? 8000, ny);
  if (o.env) {
    fl.frequency.setValueAtTime(Math.min(cut + o.env, ny), t);
    fl.frequency.exponentialRampToValueAtTime(Math.max(60, cut), t + Math.max(0.05, Math.min(dur, 0.35)));
  } else fl.frequency.setValueAtTime(cut, t);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(o.v, t + a);
  if (o.hold !== undefined) g.gain.setTargetAtTime(o.v * o.hold, t + a, Math.max(0.05, dur * 0.3));
  g.gain.setTargetAtTime(0.0001, t + Math.max(dur, a), r / 4);
  let input: AudioNode = fl;
  if (o.drive) {
    const ws = ctx.createWaveShaper();
    ws.curve = curve(o.drive);
    ws.connect(fl);
    input = ws;
  }
  fl.connect(g);
  g.connect(b.dry);
  if (o.wet) g.connect(b.wet);
  if (o.echo) g.connect(b.echo);
  const end = t + Math.max(dur, a) + r + 0.05;
  let lfoGain: GainNode | null = null;
  if (o.vib) {
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 5.6;
    lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(0, t);
    lfoGain.gain.linearRampToValueAtTime(o.vib, t + Math.min(0.25, dur));
    lfo.connect(lfoGain);
    lfo.start(t);
    lfo.stop(end);
  }
  for (let i = 0; i < n; i++) {
    const osc = ctx.createOscillator();
    osc.type = o.type;
    osc.frequency.setValueAtTime(f, t);
    osc.detune.value = n > 1 ? (i / (n - 1) - 0.5) * 2 * det : 0;
    if (lfoGain) lfoGain.connect(osc.detune);
    osc.connect(input);
    osc.start(t);
    osc.stop(end);
  }
}

function sub808(ctx: Ctx, b: Bus, t: number, f: number, dur: number, from?: number) {
  const o = ctx.createOscillator();
  o.type = "sine";
  if (from) {
    o.frequency.setValueAtTime(from, t);
    o.frequency.exponentialRampToValueAtTime(f, t + 0.1);
  } else {
    o.frequency.setValueAtTime(f * 2.5, t);
    o.frequency.exponentialRampToValueAtTime(f, t + 0.03);
  }
  const ws = ctx.createWaveShaper();
  ws.curve = curve(3);
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 900;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(0.42, t + 0.005);
  g.gain.setTargetAtTime(0.28, t + 0.05, 0.4);
  g.gain.setTargetAtTime(0.0001, t + dur, 0.06);
  o.connect(ws);
  ws.connect(lp);
  lp.connect(g);
  g.connect(b.dry);
  o.start(t);
  o.stop(t + dur + 0.4);
}

function cowbell(ctx: Ctx, b: Bus, t: number, f: number, dur: number, v: number) {
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = f * 1.3;
  bp.Q.value = 1.4;
  const g = ctx.createGain();
  const d = Math.min(Math.max(dur, 0.12), 0.5);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(v, t + 0.002);
  g.gain.exponentialRampToValueAtTime(v * 0.35, t + 0.04);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.1);
  [1, 1.48].forEach((k) => {
    const o = ctx.createOscillator();
    o.type = "square";
    o.frequency.value = f * k;
    o.connect(bp);
    o.start(t);
    o.stop(t + d + 0.12);
  });
  bp.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
}

function bell(ctx: Ctx, b: Bus, t: number, f: number, dur: number, v: number) {
  const car = ctx.createOscillator();
  car.type = "sine";
  car.frequency.value = f;
  const mod = ctx.createOscillator();
  mod.type = "sine";
  mod.frequency.value = f * 3.51;
  const mg = ctx.createGain();
  mg.gain.setValueAtTime(f * 2.2, t);
  mg.gain.exponentialRampToValueAtTime(f * 0.05, t + dur);
  mod.connect(mg);
  mg.connect(car.frequency);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(v, t + 0.003);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  car.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
  g.connect(b.echo);
  car.start(t);
  mod.start(t);
  car.stop(t + dur + 0.05);
  mod.stop(t + dur + 0.05);
}

function rhodes(ctx: Ctx, b: Bus, t: number, f: number, dur: number, v: number) {
  const car = ctx.createOscillator();
  car.type = "sine";
  car.frequency.value = f;
  const mod = ctx.createOscillator();
  mod.type = "sine";
  mod.frequency.value = f;
  const mg = ctx.createGain();
  mg.gain.setValueAtTime(f * 1.4, t);
  mg.gain.exponentialRampToValueAtTime(f * 0.08, t + 0.7);
  mod.connect(mg);
  mg.connect(car.frequency);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(v, t + 0.006);
  g.gain.setTargetAtTime(v * 0.4, t + 0.01, 0.5);
  g.gain.setTargetAtTime(0.0001, t + dur, 0.12);
  car.connect(g);
  g.connect(b.dry);
  g.connect(b.wet);
  const end = t + dur + 0.7;
  car.start(t);
  mod.start(t);
  car.stop(end);
  mod.stop(end);
}

function guitar(ctx: Ctx, b: Bus, t: number, f: number, dur: number, v: number, mute: boolean) {
  const ws = ctx.createWaveShaper();
  ws.curve = curve(60);
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = mute ? 1300 : 3200;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(v, t + 0.004);
  g.gain.setTargetAtTime(v * (mute ? 0.25 : 0.7), t + 0.01, mute ? 0.04 : 0.5);
  g.gain.setTargetAtTime(0.0001, t + dur, 0.05);
  ws.connect(lp);
  lp.connect(g);
  g.connect(b.dry);
  if (!mute) g.connect(b.wet);
  const end = t + dur + 0.3;
  [1, 1.4983, 2].forEach((k) => {
    [-7, 7].forEach((dt) => {
      const o = ctx.createOscillator();
      o.type = "sawtooth";
      o.frequency.value = f * k;
      o.detune.value = dt;
      o.connect(ws);
      o.start(t);
      o.stop(end);
    });
  });
}

/* ------------------------------------------------------------------ */
/* Bus                                                                 */
/* ------------------------------------------------------------------ */

export function buildBus(ctx: Ctx, out: AudioNode, C: Comp): Bus {
  const fader = ctx.createGain();
  fader.connect(out);
  const tone = ctx.createBiquadFilter();
  tone.type = "lowpass";
  tone.frequency.value = Math.min(C.P.busCut, ctx.sampleRate / 2 - 200);
  tone.Q.value = 0.3;
  tone.connect(fader);
  const dry = ctx.createGain();
  dry.connect(tone);
  const wet = ctx.createGain();
  wet.gain.value = C.genre === "ambient" ? 0.6 : 0.3;
  const conv = ctx.createConvolver();
  conv.buffer = impulse(ctx);
  wet.connect(conv);
  conv.connect(tone);
  const echo = ctx.createGain();
  echo.gain.value = 0.24;
  const dl = ctx.createDelay(2);
  dl.delayTime.value = Math.min(1.9, C.sd * 3);
  const fb = ctx.createGain();
  fb.gain.value = 0.36;
  const dlp = ctx.createBiquadFilter();
  dlp.type = "lowpass";
  dlp.frequency.value = 2600;
  echo.connect(dl);
  dl.connect(dlp);
  dlp.connect(fb);
  fb.connect(dl);
  dlp.connect(tone);
  return { dry, wet, echo, fader, nodes: [tone, dry, wet, conv, echo, dl, fb, dlp] };
}

export function disposeBus(ctx: Ctx, b: Bus) {
  const now = ctx.currentTime;
  try {
    b.fader.gain.cancelScheduledValues(now);
    b.fader.gain.setValueAtTime(b.fader.gain.value, now);
    b.fader.gain.linearRampToValueAtTime(0, now + 0.12);
  } catch {
    /* ignore */
  }
  setTimeout(() => {
    try {
      b.fader.disconnect();
      b.nodes.forEach((n) => n.disconnect());
    } catch {
      /* ignore */
    }
  }, 450);
}

/* ------------------------------------------------------------------ */
/* Scheduler                                                           */
/* ------------------------------------------------------------------ */

const sn = (scale: number[], d: number) => scale[((d % 7) + 7) % 7] + 12 * Math.floor(d / 7);
const mod7 = (d: number) => ((d % 7) + 7) % 7;

function snap(d: number, chord: number) {
  const tones = [0, 2, 4].map((k) => mod7(chord + k));
  if (tones.includes(mod7(d))) return d;
  for (const off of [1, -1, 2, -2]) if (tones.includes(mod7(d + off))) return d + off;
  return d;
}

function chordNotes(C: Comp, deg: number) {
  const ks = C.P.seventh ? [0, 2, 4, 6] : [0, 2, 4];
  const base = C.root + 24;
  return ks.map((k) => base + sn(C.scale, deg + k)).map((m) => (m > base + 16 ? m - 12 : m));
}

function bassVoice(ctx: Ctx, b: Bus, kind: BassI, t: number, m: number, dur: number, step: number, g = 1) {
  const f = mtof(m);
  switch (kind) {
    case "saw":
      voice(ctx, b, t, f, dur * 0.9, { type: "sawtooth", v: 0.2 * g, a: 0.004, r: 0.05, cut: 380, env: 1200, q: 5 });
      break;
    case "sine":
      voice(ctx, b, t, f, dur * 0.95, { type: "triangle", v: 0.3 * g, a: 0.012, r: 0.12, cut: 700 });
      break;
    case "808":
      if (g > 0.02) sub808(ctx, b, t, f, dur, step % 7 === 3 ? f * 1.5 : undefined);
      break;
    case "acid":
      voice(ctx, b, t, f, dur * 0.8, {
        type: "sawtooth", v: 0.16 * g, a: 0.003, r: 0.04, cut: 240 + 500 * (0.5 + 0.5 * Math.sin(step / 20)), env: 1600, q: 11,
      });
      break;
    case "drone":
      voice(ctx, b, t, f, dur, { type: "triangle", n: 2, det: 7, v: 0.14 * g, a: 1.6, r: 2.5, cut: 520, wet: true });
      break;
    case "pick":
      voice(ctx, b, t, f, dur * 0.85, { type: "square", v: 0.11 * g, a: 0.003, r: 0.05, cut: 650, env: 900, q: 2 });
      break;
  }
}

function chordVoice(ctx: Ctx, b: Bus, kind: ChordI, t: number, ms: number[], dur: number, open: boolean, soft: boolean) {
  switch (kind) {
    case "pad":
      ms.forEach((m) =>
        voice(ctx, b, t, mtof(m), dur, {
          type: "sawtooth", n: 2, det: 11, v: soft ? 0.036 : 0.03, a: soft ? 1.4 : 0.45, r: soft ? 1.8 : 0.9, cut: soft ? 1100 : 1400, wet: true,
        })
      );
      break;
    case "rhodes":
      ms.forEach((m, i) => rhodes(ctx, b, t + i * 0.012, mtof(m), dur, 0.07));
      break;
    case "stab":
      ms.forEach((m) =>
        voice(ctx, b, t, mtof(m), 0.14, { type: "sawtooth", n: 2, det: 9, v: 0.05, a: 0.003, r: 0.12, cut: 700, env: 3500, q: 6, wet: true, echo: true })
      );
      break;
    case "guitar":
      guitar(ctx, b, t, mtof(ms[0] - 12), open ? dur * 0.95 : 0.11, open ? 0.075 : 0.07, !open);
      break;
    case "supersaw":
      ms.forEach((m) =>
        voice(ctx, b, t, mtof(m + 12), Math.min(dur, 0.22), { type: "sawtooth", n: 3, det: 16, v: 0.028, a: 0.004, r: 0.1, cut: 5200, wet: true })
      );
      break;
    case "none":
      break;
  }
}

function leadVoice(ctx: Ctx, b: Bus, kind: LeadI, t: number, m: number, dur: number, step: number, g = 1) {
  const f = mtof(m);
  switch (kind) {
    case "saw":
      voice(ctx, b, t, f, dur, { type: "sawtooth", n: 2, det: 8, v: 0.06 * g, a: 0.01, r: 0.15, cut: 3000, env: 1500, q: 1, wet: true, echo: true });
      break;
    case "pluck":
      voice(ctx, b, t, f, dur, { type: "triangle", v: 0.1 * g, a: 0.004, r: 0.25, hold: 0.3, cut: 2400, env: 1200, wet: true, echo: true });
      break;
    case "cowbell":
      cowbell(ctx, b, t, f, dur, 0.09 * g);
      break;
    case "acid":
      voice(ctx, b, t, f, dur * 0.85, {
        type: "sawtooth", v: 0.055 * g, a: 0.003, r: 0.05, cut: 300 + 2200 * (0.5 + 0.5 * Math.sin(step / 28)), env: 2400, q: 13, echo: true,
      });
      break;
    case "bell":
      bell(ctx, b, t, f, Math.max(dur, 0.6), 0.07 * g);
      break;
    case "gtr":
      voice(ctx, b, t, f, dur, { type: "square", n: 2, det: 10, v: 0.045 * g, a: 0.008, r: 0.15, cut: 2600, drive: 25, vib: 14, wet: true, echo: true });
      break;
    case "chip":
      voice(ctx, b, t, f, dur, { type: "square", v: 0.045 * g, a: 0.002, r: 0.06, cut: 7000, vib: 22, echo: true });
      break;
  }
}

function arpVoice(ctx: Ctx, b: Bus, kind: ArpI, t: number, m: number, sd: number) {
  const f = mtof(m);
  if (kind === "square") voice(ctx, b, t, f, sd * 0.8, { type: "square", v: 0.032, a: 0.002, r: 0.06, cut: 1800, env: 2600, q: 3, echo: true });
  else if (kind === "bell") bell(ctx, b, t, f * 2, 1.2, 0.035);
  else if (kind === "chip") voice(ctx, b, t, f * 2, sd * 0.7, { type: "square", v: 0.028, a: 0.002, r: 0.03, cut: 8000 });
}

export function scheduleStep(ctx: Ctx, b: Bus, C: Comp, step: number, t: number) {
  const bar = Math.floor(step / 16);
  const pos = step % 16;
  if (bar >= C.bars) return;
  const L = C.layers[bar];
  const P = C.P;
  const has = (k: string) => L.includes(k);
  const sd = C.sd;
  const tt = t + (pos % 2 === 1 ? P.swing * sd : 0);
  const deg = C.prog[bar % C.prog.length];

  // Per-track stem gains coming from the Mini Studio mixer.
  const G = C.gains;
  const gv = (k: string) => (G ? G[k] ?? 1 : 1);

  if (pos === 0 && bar > 0 && C.secStart.has(bar) && P.crash && has("k")) crash(ctx, b, tt, 0.16 * Math.max(gv("k"), gv("s")));
  if (pos === 0 && C.riser.has(bar) && P.riser) riser(ctx, b, tt, 16 * sd);
  if (P.crackle && pos % 4 === 0) crackle(ctx, b, tt, 4 * sd);

  const isFill = P.fills && C.fill.has(bar) && pos >= 12;
  if (has("k") && C.kickP[pos] !== ".") kick(ctx, b, tt, 0.95 * gv("k"), P.kickTone, P.kickDecay);
  if (has("s")) {
    if (isFill) snare(ctx, b, tt, (0.18 + (pos - 12) * 0.08) * gv("s"));
    else if (C.snareP[pos] !== ".") (P.clap ? clap : snare)(ctx, b, tt, 0.5 * gv("s"));
  }
  if (has("h")) {
    const ch = C.hatP[pos];
    if (ch === "x") hat(ctx, b, tt, P.hatV * (pos % 4 === 0 ? 1 : 0.72) * gv("h"), false);
    else if (ch === "o") hat(ctx, b, tt, P.hatV * 1.1 * gv("h"), true);
    else if (ch === "r") for (let i = 0; i < 3; i++) hat(ctx, b, tt + (i * sd) / 3, P.hatV * 0.8 * gv("h"), false);
  }
  if (has("b")) {
    const ch = C.bassP[pos];
    if (ch !== ".") {
      let len = 1;
      while (len < P.bassMax && pos + len < 16 && C.bassP[pos + len] === ".") len++;
      const off = ch === "o" ? 12 : ch === "f" ? 7 : 0;
      bassVoice(ctx, b, P.bassI, tt, C.root + 12 * P.bassOct + sn(C.scale, deg) + off, len * sd, step);
    }
  }
  if (has("c") && P.chordI !== "none") {
    if (C.chordP[pos] !== ".") {
      let len = 1;
      while (pos + len < 16 && C.chordP[pos + len] === ".") len++;
      chordVoice(ctx, b, P.chordI, tt, chordNotes(C, deg), len * sd, has("l"), C.genre === "ambient");
    }
  }
  if (has("a") && P.arpI !== "none" && C.arpP[pos] !== ".") {
    const idx = C.arpSeq[step % C.arpSeq.length];
    const d = deg + [0, 2, 4, 7][idx];
    arpVoice(ctx, b, P.arpI, tt, C.root + 12 * P.leadOct + sn(C.scale, d), sd);
  }
  if (has("l")) {
    const mot = Math.floor(bar / 2) % 2 ? C.motif2 : C.motif;
    const i = step % 32;
    const d0 = mot[i];
    if (d0 != null) {
      let len = 1;
      while (len < 4 && mot[(i + len) % 32] == null) len++;
      const d = pos % 4 === 0 ? snap(d0, deg) : d0;
      leadVoice(ctx, b, P.leadI, tt, C.root + 12 * P.leadOct + sn(C.scale, d), len * sd * 0.92, step, gv("l"));
    }
  }
}
