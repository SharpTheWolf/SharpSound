import { buildBus, scheduleStep, type Comp, type Genre } from "./synth";
import { GENRES, GENRE_LIST, getComp, type Features, type Track } from "../data/catalog";

/** Audio fingerprint used by recognition, moderation and similarity. */
export interface FP {
  bands: number[];
  cen: number;
  flat: number;
  bpm: number;
  chroma: number[];
  dyn: number;
  onset: number;
  rms: number;
}

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

function fft(re: Float32Array, im: Float32Array) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      let t = re[i];
      re[i] = re[j];
      re[j] = t;
      t = im[i];
      im[i] = im[j];
      im[j] = t;
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    const wr = Math.cos(ang);
    const wi = Math.sin(ang);
    const h = len >> 1;
    for (let i = 0; i < n; i += len) {
      let cr = 1;
      let ci = 0;
      for (let k = 0; k < h; k++) {
        const a = i + k;
        const b = a + h;
        const xr = re[b] * cr - im[b] * ci;
        const xi = re[b] * ci + im[b] * cr;
        re[b] = re[a] - xr;
        im[b] = im[a] - xi;
        re[a] += xr;
        im[a] += xi;
        const ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = ncr;
      }
    }
  }
}

function tempo(flux: number[], fps: number) {
  const n = flux.length;
  if (n < fps * 3) return 0;
  const w = Math.max(1, Math.round(fps * 0.25));
  const pre = new Float64Array(n + 1);
  for (let i = 0; i < n; i++) pre[i + 1] = pre[i] + flux[i];
  const o = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const a = Math.max(0, i - w);
    const b = Math.min(n, i + w + 1);
    o[i] = Math.max(0, flux[i] - (pre[b] - pre[a]) / (b - a));
  }
  const minLag = Math.floor((fps * 60) / 200);
  const maxLag = Math.ceil((fps * 60) / 55);
  const sc = new Float32Array(maxLag + 2);
  let best = -1;
  let bl = 0;
  for (let lag = minLag; lag <= maxLag && lag < n; lag++) {
    let s = 0;
    for (let i = 0; i + lag < n; i++) s += o[i] * o[i + lag];
    s /= n - lag;
    const bpm = (60 * fps) / lag;
    const wgt = Math.exp(-0.5 * Math.pow(Math.log2(bpm / 115) / 0.85, 2));
    sc[lag] = s * wgt;
    if (sc[lag] > best) {
      best = sc[lag];
      bl = lag;
    }
  }
  if (!bl || best <= 0) return 0;
  const y0 = sc[bl - 1] || 0;
  const y1 = sc[bl];
  const y2 = sc[bl + 1] || 0;
  const den = y0 - 2 * y1 + y2;
  const shift = den ? (0.5 * (y0 - y2)) / den : 0;
  return (60 * fps) / (bl + Math.max(-0.5, Math.min(0.5, shift)));
}

function countPeaks(flux: number[], fps: number) {
  if (!flux.length) return 0;
  const mean = flux.reduce((a, b) => a + b, 0) / flux.length;
  const sd = Math.sqrt(flux.reduce((a, b) => a + (b - mean) ** 2, 0) / flux.length);
  const th = mean + sd * 0.6;
  const gap = Math.round(fps * 0.09);
  let c = 0;
  let last = -gap;
  for (let i = 1; i < flux.length - 1; i++) {
    if (flux[i] > th && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1] && i - last >= gap) {
      c++;
      last = i;
    }
  }
  return c;
}

/** analyse mono samples: every ~11 ms frame we look at the full spectrum */
export function analyze(x: Float32Array, sr: number): FP {
  const N = 2048;
  const hop = 256;
  const half = N / 2;
  const win = new Float32Array(N);
  for (let i = 0; i < N; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (N - 1));
  const re = new Float32Array(N);
  const im = new Float32Array(N);
  let prev = new Float32Array(half);
  let cur = new Float32Array(half);
  const binHz = sr / N;
  const edges = [40, 120, 250, 500, 1000, 2000, 4000, 7000, 10000];
  const bandOf = new Int8Array(half).fill(-1);
  const pcOf = new Int8Array(half).fill(-1);
  const bandBins = new Float64Array(8);
  for (let k = 1; k < half; k++) {
    const f = k * binHz;
    for (let b = 0; b < 8; b++)
      if (f >= edges[b] && f < edges[b + 1]) {
        bandOf[k] = b;
        bandBins[b]++;
        break;
      }
    if (f >= 65 && f <= 4200) pcOf[k] = (((Math.round(12 * Math.log2(f / 440)) + 69) % 12) + 12) % 12;
  }
  const kMax = Math.min(half - 1, Math.floor(10000 / binHz));
  const bandAcc = new Float64Array(8);
  const chroma = new Float64Array(12);
  let cenAcc = 0;
  let flatAcc = 0;
  let frames = 0;
  const flux: number[] = [];
  const rmsArr: number[] = [];
  const norm = N / 4;
  for (let s = 0; s + N <= x.length; s += hop) {
    let e = 0;
    for (let i = 0; i < N; i++) {
      const v = x[s + i];
      re[i] = v * win[i];
      im[i] = 0;
      e += v * v;
    }
    const rms = Math.sqrt(e / N);
    rmsArr.push(rms);
    if (rms < 0.0015) {
      flux.push(0);
      prev.fill(0);
      continue;
    }
    fft(re, im);
    let sum = 0;
    let wsum = 0;
    let logSum = 0;
    let linSum = 0;
    let cnt = 0;
    let fl = 0;
    for (let k = 1; k <= kMax; k++) {
      const m = Math.sqrt(re[k] * re[k] + im[k] * im[k]) / norm;
      const lm = Math.log(1 + 200 * m);
      cur[k] = lm;
      const f = k * binHz;
      sum += m;
      wsum += m * f;
      const bi = bandOf[k];
      if (bi >= 0) bandAcc[bi] += m;
      const pc = pcOf[k];
      if (pc >= 0) chroma[pc] += m;
      if (f >= 60 && f <= 8000) {
        logSum += Math.log(m + 1e-9);
        linSum += m;
        cnt++;
      }
      const d = lm - prev[k];
      if (d > 0) fl += d;
    }
    cenAcc += wsum / (sum + 1e-9);
    flatAcc += cnt ? Math.exp(logSum / cnt) / (linSum / cnt + 1e-9) : 0;
    frames++;
    flux.push(fl);
    const tmp = prev;
    prev = cur;
    cur = tmp;
  }
  const fr = Math.max(1, frames);
  const bl = Array.from(bandAcc, (v, i) => Math.log(1 + (2000 * v) / fr / Math.max(1, bandBins[i])));
  const bsum = bl.reduce((a, b) => a + b, 0) || 1;
  const bands = bl.map((v) => v / bsum);
  const cmax = Math.max(...Array.from(chroma)) || 1;
  const meanR = rmsArr.reduce((a, b) => a + b, 0) / (rmsArr.length || 1);
  const sdR = Math.sqrt(rmsArr.reduce((a, b) => a + (b - meanR) ** 2, 0) / (rmsArr.length || 1));
  const fps = sr / hop;
  return {
    bands,
    cen: frames ? cenAcc / frames : 0,
    flat: frames ? flatAcc / frames : 0,
    bpm: tempo(flux, fps),
    chroma: Array.from(chroma, (v) => v / cmax),
    dyn: meanR ? sdR / meanR : 0,
    onset: countPeaks(flux, fps) / Math.max(1, x.length / sr),
    rms: meanR,
  };
}

function tempoSim(a: number, b: number) {
  if (!a || !b) return 0.4;
  let best = 0;
  for (const [k, w] of [[1, 1], [2, 0.9], [0.5, 0.9], [1.5, 0.6], [2 / 3, 0.6]] as [number, number][]) {
    const d = Math.abs(Math.log2((a * k) / b));
    best = Math.max(best, w * (0.85 * Math.exp(-Math.pow(d / 0.035, 2)) + 0.15 * Math.exp(-Math.pow(d / 0.15, 2))));
  }
  return best;
}

/** 0..1 similarity with tolerance (a few % tempo, small timbre / key drift) */
export function compareFP(a: FP, b: FP): number {
  let l1 = 0;
  for (let i = 0; i < 8; i++) l1 += Math.abs((a.bands[i] ?? 0) - (b.bands[i] ?? 0));
  const sBands = Math.max(0, 1 - l1 * 2.2);
  const sCen = Math.exp(-Math.pow(Math.log2((a.cen + 50) / (b.cen + 50)) / 0.45, 2));
  const sTempo = tempoSim(a.bpm, b.bpm);
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < 12; i++) {
    dot += a.chroma[i] * b.chroma[i];
    na += a.chroma[i] ** 2;
    nb += b.chroma[i] ** 2;
  }
  const cos = na && nb ? dot / Math.sqrt(na * nb) : 0;
  const sChroma = clamp01((cos - 0.6) / 0.4);
  const sFlat = Math.max(0, 1 - Math.abs(a.flat - b.flat) * 4);
  const sOnset = Math.exp(-Math.pow(Math.log2((a.onset + 0.5) / (b.onset + 0.5)) / 0.8, 2));
  return 0.28 * sBands + 0.14 * sCen + 0.22 * sTempo + 0.2 * sChroma + 0.08 * sFlat + 0.08 * sOnset;
}

const MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
const MIN = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
const NOTES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

function corr(a: number[], b: number[]) {
  const ma = a.reduce((s, v) => s + v, 0) / a.length;
  const mb = b.reduce((s, v) => s + v, 0) / b.length;
  let n = 0;
  let da = 0;
  let db = 0;
  for (let i = 0; i < a.length; i++) {
    n += (a[i] - ma) * (b[i] - mb);
    da += (a[i] - ma) ** 2;
    db += (b[i] - mb) ** 2;
  }
  return da && db ? n / Math.sqrt(da * db) : 0;
}

export function keyOf(chroma: number[]) {
  let best = { score: -2, root: 0, minor: false, maj: -2, min: -2 };
  let maxMaj = -2;
  let maxMin = -2;
  for (let r = 0; r < 12; r++) {
    const rot = chroma.map((_, i) => chroma[(i + r) % 12]);
    const cM = corr(rot, MAJ);
    const cm = corr(rot, MIN);
    maxMaj = Math.max(maxMaj, cM);
    maxMin = Math.max(maxMin, cm);
    if (cM > best.score) best = { ...best, score: cM, root: r, minor: false };
    if (cm > best.score) best = { ...best, score: cm, root: r, minor: true };
  }
  return { name: `${NOTES[best.root]} ${best.minor ? "minor" : "major"}`, minorness: 1 / (1 + Math.exp(-(maxMin - maxMaj) * 10)) };
}

export function featuresFromFP(fp: FP): Features {
  const bright = clamp01((fp.cen - 700) / 2600);
  const { minorness } = keyOf(fp.chroma);
  return {
    energy: clamp01(Math.min(1, fp.rms * 3.2) * 0.6 + Math.min(1, fp.onset / 7) * 0.4),
    bright,
    dark: clamp01(minorness * 0.6 + (1 - bright) * 0.4),
    tempo: clamp01((fp.bpm - 60) / 110),
    dense: clamp01(fp.onset / 6),
    acoustic: clamp01(1.2 - fp.flat * 3.5 - ((fp.bands[0] ?? 0) + (fp.bands[1] ?? 0)) * 1.2),
  };
}

export function guessGenre(f: Features): Genre {
  let best: Genre = "lofi";
  let bd = 1e9;
  for (const g of GENRE_LIST) {
    const b = GENRES[g].base;
    const d = (f.energy - b.energy) ** 2 * 1.4 + (f.bright - b.bright) ** 2 + (f.dark - b.dark) ** 2 + (f.tempo - b.tempo) ** 2 * 0.8 + (f.dense - b.dense) ** 2 + (f.acoustic - b.acoustic) ** 2 * 0.7;
    if (d < bd) {
      bd = d;
      best = g;
    }
  }
  return best;
}

type OACtor = typeof OfflineAudioContext;
const getOAC = (): OACtor => window.OfflineAudioContext || (window as unknown as { webkitOfflineAudioContext: OACtor }).webkitOfflineAudioContext;

/** render 10 s of a procedural track offline and fingerprint it */
export async function fingerprintComp(comp: Comp): Promise<FP> {
  const sr = 22050;
  const secs = 10;
  const OAC = getOAC();
  const octx = new OAC(1, sr * secs, sr);
  const c = octx.createDynamicsCompressor();
  c.threshold.value = -14;
  c.ratio.value = 4;
  c.connect(octx.destination);
  const bus = buildBus(octx, c, comp);
  const start = comp.chorusBar * 16;
  const steps = Math.ceil(secs / comp.sd) + 2;
  for (let i = 0; i < steps; i++) scheduleStep(octx, bus, comp, start + i, 0.02 + i * comp.sd);
  const buf = await octx.startRendering();
  return analyze(buf.getChannelData(0), sr);
}

const FP_KEY = "ss-fp-v2";
let libCache: Map<string, FP> | null = null;

export async function ensureLibrary(tracks: Track[], onProgress?: (done: number, total: number) => void): Promise<Map<string, FP>> {
  let cache: Record<string, FP> = {};
  try {
    cache = JSON.parse(localStorage.getItem(FP_KEY) || "{}");
  } catch {
    cache = {};
  }
  const map = libCache ?? new Map<string, FP>();
  const synth = tracks.filter((t) => t.source === "synth");
  let done = 0;
  let dirty = false;
  for (const t of tracks) {
    if (t.fp) {
      map.set(t.id, t.fp);
      continue;
    }
    if (t.source !== "synth") continue;
    let fp = map.get(t.id) ?? cache[t.id];
    if (!fp) {
      fp = await fingerprintComp(getComp(t));
      cache[t.id] = fp;
      dirty = true;
      await new Promise((r) => setTimeout(r, 0));
    }
    map.set(t.id, fp);
    done++;
    onProgress?.(done, synth.length);
  }
  if (dirty) {
    try {
      localStorage.setItem(FP_KEY, JSON.stringify(cache));
    } catch {
      /* quota */
    }
  }
  libCache = map;
  return map;
}

export function matchFP(q: FP, lib: Map<string, FP>) {
  return [...lib.entries()].map(([id, fp]) => ({ id, s: compareFP(q, fp) })).sort((a, b) => b.s - a.s);
}

/* ---------------- decoding & inspection ---------------- */

export async function decodeBlob(blob: Blob, sr = 22050): Promise<AudioBuffer> {
  const ab = await blob.arrayBuffer();
  const OAC = getOAC();
  const ctx = new OAC(1, 1, sr);
  return await ctx.decodeAudioData(ab);
}

export function mono(buf: AudioBuffer): Float32Array {
  const out = new Float32Array(buf.length);
  for (let c = 0; c < buf.numberOfChannels; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < d.length; i++) out[i] += d[i] / buf.numberOfChannels;
  }
  return out;
}

export function segment(x: Float32Array, sr: number, secs: number, at = 0.35): Float32Array {
  const len = Math.min(x.length, Math.floor(secs * sr));
  const start = Math.max(0, Math.floor((x.length - len) * at));
  return x.subarray(start, start + len);
}

export interface Inspection {
  duration: number;
  rms: number;
  peak: number;
  clip: number;
  silent: number;
  wave: number[];
  fp: FP;
}

export function inspect(buf: AudioBuffer): Inspection {
  const x = mono(buf);
  const sr = buf.sampleRate;
  let peak = 0;
  let sum = 0;
  let clip = 0;
  for (let i = 0; i < x.length; i++) {
    const v = Math.abs(x[i]);
    if (v > peak) peak = v;
    sum += x[i] * x[i];
    if (v > 0.985) clip++;
  }
  const win = Math.max(1, Math.floor(sr * 0.05));
  let quiet = 0;
  let wins = 0;
  for (let s = 0; s + win <= x.length; s += win) {
    let e = 0;
    for (let i = 0; i < win; i++) e += x[s + i] * x[s + i];
    if (Math.sqrt(e / win) < 0.003) quiet++;
    wins++;
  }
  const bins = 96;
  const wave: number[] = [];
  const step = Math.max(1, Math.floor(x.length / bins));
  for (let b = 0; b < bins; b++) {
    let m = 0;
    for (let i = b * step; i < Math.min(x.length, (b + 1) * step); i += 8) m = Math.max(m, Math.abs(x[i]));
    wave.push(m);
  }
  const wm = Math.max(...wave) || 1;
  return {
    duration: buf.duration,
    rms: Math.sqrt(sum / Math.max(1, x.length)),
    peak,
    clip: clip / Math.max(1, x.length),
    silent: wins ? quiet / wins : 1,
    wave: wave.map((v) => v / wm),
    fp: analyze(segment(x, sr, 12, 0.35), sr),
  };
}

/* ---------------- microphone ---------------- */

export interface MicSession {
  level: () => number;
  finish: () => { x: Float32Array; sr: number };
  cancel: () => void;
}

export async function startMic(): Promise<MicSession> {
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
  });
  const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  if (ctx.state === "suspended") await ctx.resume();
  const src = ctx.createMediaStreamSource(stream);
  const an = ctx.createAnalyser();
  an.fftSize = 1024;
  src.connect(an);
  const proc = ctx.createScriptProcessor(4096, 1, 1);
  const chunks: Float32Array[] = [];
  proc.onaudioprocess = (e) => {
    chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
  };
  const mute = ctx.createGain();
  mute.gain.value = 0;
  src.connect(proc);
  proc.connect(mute);
  mute.connect(ctx.destination);
  const buf: Uint8Array<ArrayBuffer> = new Uint8Array(an.fftSize);
  let closed = false;
  const cleanup = () => {
    if (closed) return;
    closed = true;
    try {
      proc.disconnect();
      src.disconnect();
      stream.getTracks().forEach((t) => t.stop());
      ctx.close();
    } catch {
      /* ignore */
    }
  };
  return {
    level: () => {
      if (closed) return 0;
      an.getByteTimeDomainData(buf);
      let s = 0;
      for (let i = 0; i < buf.length; i++) {
        const v = (buf[i] - 128) / 128;
        s += v * v;
      }
      return Math.sqrt(s / buf.length);
    },
    finish: () => {
      const sr = ctx.sampleRate;
      cleanup();
      const len = chunks.reduce((a, c) => a + c.length, 0);
      const x = new Float32Array(len);
      let o = 0;
      for (const c of chunks) {
        x.set(c, o);
        o += c.length;
      }
      const f = Math.max(1, Math.round(sr / 22050));
      if (f === 1) return { x, sr };
      const y = new Float32Array(Math.floor(len / f));
      for (let i = 0; i < y.length; i++) {
        let s = 0;
        for (let j = 0; j < f; j++) s += x[i * f + j];
        y[i] = s / f;
      }
      return { x: y, sr: sr / f };
    },
    cancel: cleanup,
  };
}
