import { buildBus, disposeBus, scheduleStep, type Bus, type Comp } from "./synth";

type Cur =
  | { kind: "synth"; comp: Comp; bus: Bus; t0: number; off: number; next: number; nextT: number }
  | { kind: "file"; bpm: number };

export interface Bands {
  bass: number;
  mid: number;
  high: number;
  level: number;
}

type ACtor = typeof AudioContext;

class Engine {
  ctx: AudioContext | null = null;
  analyser: AnalyserNode | null = null;
  freq: Uint8Array<ArrayBuffer> = new Uint8Array(1024);
  playing = false;
  onEnded: (() => void) | null = null;

  private out: DynamicsCompressorNode | null = null;
  private master: GainNode | null = null;
  private cur: Cur | null = null;
  private vol = 0.85;
  private el: HTMLAudioElement | null = null;
  private ended = false;
  private bandsCache: Bands = { bass: 0, mid: 0, high: 0, level: 0 };
  private bandsAt = 0;

  private init(): AudioContext {
    if (this.ctx) return this.ctx;
    const AC: ACtor = window.AudioContext || (window as unknown as { webkitAudioContext: ACtor }).webkitAudioContext;
    const ctx = new AC({ latencyHint: "playback" });
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.knee.value = 10;
    comp.ratio.value = 4;
    comp.attack.value = 0.004;
    comp.release.value = 0.22;
    const master = ctx.createGain();
    master.gain.value = this.vol;
    const an = ctx.createAnalyser();
    an.fftSize = 2048;
    an.smoothingTimeConstant = 0.78;
    comp.connect(master);
    master.connect(an);
    an.connect(ctx.destination);
    this.ctx = ctx;
    this.out = comp;
    this.master = master;
    this.analyser = an;
    this.freq = new Uint8Array(an.frequencyBinCount);
    this.startTicker();
    return ctx;
  }

  /** Must be called inside a user gesture. */
  unlock() {
    const ctx = this.init();
    if (ctx.state === "suspended" && this.playing) ctx.resume();
    return ctx;
  }

  private startTicker() {
    const tick = () => this.tick();
    try {
      const src = "setInterval(function(){postMessage(0)},25);";
      const w = new Worker(URL.createObjectURL(new Blob([src], { type: "text/javascript" })));
      w.onmessage = tick;
    } catch {
      setInterval(tick, 25);
    }
  }

  private tick() {
    const ctx = this.ctx;
    const c = this.cur;
    if (!ctx || !c || !this.playing) return;
    if (c.kind === "synth") {
      const ahead = ctx.currentTime + 0.2;
      while (c.nextT < ahead && c.next < c.comp.totalSteps) {
        scheduleStep(ctx, c.bus, c.comp, c.next, c.nextT);
        c.next++;
        c.nextT += c.comp.sd;
      }
      if (!this.ended && this.time() >= c.comp.duration) {
        this.ended = true;
        setTimeout(() => this.onEnded?.(), 0);
      }
    }
  }

  private stopCurrent() {
    const c = this.cur;
    if (!c || !this.ctx) return;
    if (c.kind === "synth") disposeBus(this.ctx, c.bus);
    else if (this.el) this.el.pause();
    this.cur = null;
  }

  playSynth(comp: Comp, offset = 0) {
    const ctx = this.init();
    this.stopCurrent();
    const bus = buildBus(ctx, this.out!, comp);
    const step = Math.max(0, Math.floor(offset / comp.sd));
    const t0 = ctx.currentTime + 0.08;
    this.cur = { kind: "synth", comp, bus, t0, off: step * comp.sd, next: step, nextT: t0 };
    this.ended = false;
    this.playing = true;
    if (ctx.state !== "running") ctx.resume();
  }

  playFile(url: string, bpm: number) {
    const ctx = this.init();
    this.stopCurrent();
    if (!this.el) {
      const el = new Audio();
      el.preload = "auto";
      const src = ctx.createMediaElementSource(el);
      src.connect(this.master!);
      el.onended = () => {
        if (this.cur?.kind === "file" && !this.ended) {
          this.ended = true;
          this.onEnded?.();
        }
      };
      this.el = el;
    }
    this.el.src = url;
    this.el.currentTime = 0;
    this.cur = { kind: "file", bpm: bpm || 110 };
    this.ended = false;
    this.playing = true;
    if (ctx.state !== "running") ctx.resume();
    this.el.play().catch(() => {
      /* autoplay guard */
    });
  }

  pause() {
    if (!this.ctx) return;
    this.playing = false;
    if (this.cur?.kind === "file") this.el?.pause();
    this.ctx.suspend();
  }

  resume() {
    if (!this.ctx || !this.cur) return;
    this.playing = true;
    this.ctx.resume();
    if (this.cur.kind === "file") this.el?.play().catch(() => {});
  }

  stop() {
    this.stopCurrent();
    this.playing = false;
  }

  hasTrack() {
    return !!this.cur;
  }

  seek(sec: number) {
    const ctx = this.ctx;
    const c = this.cur;
    if (!ctx || !c) return;
    if (c.kind === "file") {
      if (this.el) this.el.currentTime = Math.max(0, sec);
      return;
    }
    disposeBus(ctx, c.bus);
    const bus = buildBus(ctx, this.out!, c.comp);
    const step = Math.max(0, Math.min(c.comp.totalSteps - 1, Math.floor(sec / c.comp.sd)));
    const t0 = ctx.currentTime + 0.06;
    this.cur = { kind: "synth", comp: c.comp, bus, t0, off: step * c.comp.sd, next: step, nextT: t0 };
    this.ended = false;
  }

  time(): number {
    const ctx = this.ctx;
    const c = this.cur;
    if (!ctx || !c) return 0;
    if (c.kind === "synth") return c.off + Math.max(0, ctx.currentTime - c.t0);
    return this.el?.currentTime ?? 0;
  }

  duration(): number {
    const c = this.cur;
    if (!c) return 0;
    if (c.kind === "synth") return c.comp.duration;
    const d = this.el?.duration ?? 0;
    return isFinite(d) ? d : 0;
  }

  bpm(): number {
    const c = this.cur;
    if (!c) return 0;
    return c.kind === "synth" ? c.comp.bpm : c.bpm;
  }

  /** beat phase 0..1 */
  beat(): number {
    const b = this.bpm();
    if (!b) return 0;
    return ((this.time() * b) / 60) % 1;
  }

  setVolume(v: number) {
    this.vol = v;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.03);
  }

  bands(): Bands {
    const now = performance.now();
    const s = this.bandsCache;
    if (now - this.bandsAt < 14) return s;
    this.bandsAt = now;
    if (!this.ctx || !this.analyser || !this.playing) {
      s.bass *= 0.92;
      s.mid *= 0.92;
      s.high *= 0.92;
      s.level *= 0.92;
      for (let i = 0; i < this.freq.length; i++) this.freq[i] = (this.freq[i] * 0.92) | 0;
      return s;
    }
    this.analyser.getByteFrequencyData(this.freq);
    const hz = this.ctx.sampleRate / this.analyser.fftSize;
    const f = this.freq;
    const avg = (a: number, b: number) => {
      const i0 = Math.max(1, Math.floor(a / hz));
      const i1 = Math.min(f.length - 1, Math.ceil(b / hz));
      let sum = 0;
      for (let i = i0; i <= i1; i++) sum += f[i];
      return sum / (i1 - i0 + 1) / 255;
    };
    const bass = avg(25, 160);
    const mid = avg(160, 2200);
    const high = avg(2200, 10000);
    s.bass = s.bass * 0.5 + bass * 0.5;
    s.mid = s.mid * 0.5 + mid * 0.5;
    s.high = s.high * 0.5 + high * 0.5;
    s.level = s.bass * 0.5 + s.mid * 0.35 + s.high * 0.15;
    return s;
  }
}

export const engine = new Engine();
