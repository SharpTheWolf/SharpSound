import type { BassI, ChordI, Comp, LeadI, ArpI } from "../audio/synth";
import type { Track } from "./catalog";

/* ------------------------------------------------------------------ */
/* Mini Studio model: parts (structure) + lanes (instruments/timbres)  */
/* ------------------------------------------------------------------ */

export type SectionType = "intro" | "verse" | "chorus" | "break" | "outro";
export type LaneId = "drums" | "bass" | "chords" | "lead" | "arp";

export interface Lane {
  id: LaneId;
  on: boolean;
  voice: string;
  level: number; // 0..1.2
  oct: number; // -1 | 0 | 1
}

export interface Part {
  id: string;
  type: SectionType;
  len: number; // bars
}

export interface StudioMeta {
  bpm: number;
  parts: Part[];
  lanes: Lane[];
  seed: number;
}

export const SECTION_LABEL: Record<SectionType, { ru: string; en: string }> = {
  intro: { ru: "Вступление", en: "Intro" },
  verse: { ru: "Куплет", en: "Verse" },
  chorus: { ru: "Припев", en: "Chorus" },
  break: { ru: "Проигрыш", en: "Break" },
  outro: { ru: "Финал", en: "Outro" },
};

export const SECTION_ORDER: SectionType[] = ["intro", "verse", "chorus", "break", "outro"];
export const SECTION_HUE: Record<SectionType, number> = { intro: 272, verse: 214, chorus: 95, break: 188, outro: 316 };

export const LANE_LABEL: Record<LaneId, { ru: string; en: string }> = {
  drums: { ru: "Барабаны", en: "Drums" },
  bass: { ru: "Бас", en: "Bass" },
  chords: { ru: "Гармония", en: "Harmony" },
  lead: { ru: "Мелодия", en: "Lead" },
  arp: { ru: "Арпеджио", en: "Arpeggio" },
};

export const LANE_LETTERS: Record<LaneId, string> = { drums: "ks h", bass: "b", chords: "c", lead: "l", arp: "a" };
export const LANE_ICON: Record<LaneId, string> = { drums: "◑", bass: "▬", chords: "▤", lead: "♪", arp: "✦" };

export interface VoiceOption {
  id: string;
  ru: string;
  en: string;
}

export const VOICES: Record<LaneId, VoiceOption[]> = {
  drums: [
    { id: "four", ru: "Четыре на пол", en: "Four on the floor" },
    { id: "boombap", ru: "Бум-бэп", en: "Boom bap" },
    { id: "trap", ru: "Трэп", en: "Trap" },
    { id: "rock", ru: "Рок", en: "Rock" },
    { id: "phonk", ru: "Фонк", en: "Phonk" },
    { id: "halftime", ru: "Хафтайм", en: "Halftime" },
  ],
  bass: [
    { id: "saw", ru: "Жирный синт", en: "Fat synth" },
    { id: "sine", ru: "Мягкий синус", en: "Soft sine" },
    { id: "808", ru: "808", en: "808" },
    { id: "acid", ru: "Кислота", en: "Acid" },
    { id: "drone", ru: "Дрон", en: "Drone" },
    { id: "pick", ru: "Пик (щипок)", en: "Pick" },
  ],
  chords: [
    { id: "guitar", ru: "Гитара", en: "Guitar" },
    { id: "rhodes", ru: "Электропиано", en: "E-piano" },
    { id: "pad", ru: "Пэд", en: "Pad" },
    { id: "stab", ru: "Стаб", en: "Stab" },
    { id: "supersaw", ru: "Суперсоу", en: "Supersaw" },
  ],
  lead: [
    { id: "gtr", ru: "Гитара", en: "Guitar" },
    { id: "saw", ru: "Синт-лид", en: "Synth lead" },
    { id: "pluck", ru: "Щипок", en: "Pluck" },
    { id: "bell", ru: "Колокол", en: "Bell" },
    { id: "cowbell", ru: "Ковбелл", en: "Cowbell" },
    { id: "acid", ru: "Асид", en: "Acid" },
    { id: "chip", ru: "Чиптюн", en: "Chiptune" },
  ],
  arp: [
    { id: "square", ru: "Квадрат", en: "Square" },
    { id: "bell", ru: "Колокол", en: "Bell" },
    { id: "chip", ru: "Чиптюн", en: "Chiptune" },
  ],
};

/** Which octave lanes make sense for. */
export const LANE_OCT: Record<LaneId, boolean> = { drums: false, bass: true, chords: false, lead: true, arp: false };

const DRUM_PATTERNS: Record<string, { kick: string; snare: string; hat: string }> = {
  four: { kick: "x...x...x...x...", snare: "....x.......x...", hat: "..x...x...x...x." },
  boombap: { kick: "x.....x.x.......", snare: "....x.......x...", hat: "x.x.x.x.x.x.x.x." },
  trap: { kick: "x......x..x.....", snare: "........x.......", hat: "xxxxxxxxxxxrxxxx" },
  rock: { kick: "x.....x.x.......", snare: "....x.......x...", hat: "x.x.x.x.x.x.x.x." },
  phonk: { kick: "x.....x...x.....", snare: "....x.......x...", hat: "x.xxx.xxx.xxx.xr" },
  halftime: { kick: "x...........x...", snare: "........x.......", hat: "x...x...x...x..." },
};

const uid = () => Math.random().toString(36).slice(2, 9);

export function totalBars(parts: Part[]) {
  return parts.reduce((a, p) => a + p.len, 0);
}

export function metaSeconds(meta: StudioMeta) {
  return (totalBars(meta.parts) * 4 * 60) / meta.bpm + 1.2;
}

export function defaultLane(id: LaneId, on: boolean): Lane {
  const voices = VOICES[id];
  const fallback: Record<LaneId, string> = { drums: "four", bass: "saw", chords: "pad", lead: "saw", arp: "square" };
  return { id, on, voice: fallback[id] ?? voices[0].id, level: id === "drums" ? 1 : 0.85, oct: 0 };
}

export function createMeta(base: Comp, bpm: number): StudioMeta {
  const used = base.layers.join("");
  const present = (id: LaneId) => Array.from(LANE_LETTERS[id].replace(/\s/g, "")).some((ch) => used.includes(ch));
  const lanes = (Object.keys(LANE_LABEL) as LaneId[]).map((id) => {
    const lane = defaultLane(id, present(id));
    if (id === "drums") lane.voice = base.genre === "trap" ? "trap" : base.genre === "phonk" ? "phonk" : base.genre === "rock" ? "rock" : base.genre === "lofi" ? "boombap" : "four";
    if (id === "bass") lane.voice = base.P.bassI;
    if (id === "chords") lane.voice = base.P.chordI === "none" ? "pad" : base.P.chordI;
    if (id === "lead") lane.voice = base.P.leadI;
    if (id === "arp") lane.voice = base.P.arpI === "none" ? "square" : base.P.arpI;
    return lane;
  });
  const parts = groupParts(base.types);
  return { bpm, parts, lanes, seed: (base.bpm * 7919 + 13) >>> 0 };
}

function groupParts(types: string[]): Part[] {
  const out: Part[] = [];
  for (const raw of types) {
    const t = (SECTION_ORDER as string[]).includes(raw) ? (raw as SectionType) : "verse";
    const last = out[out.length - 1];
    if (last && last.type === t) last.len += 8;
    else out.push({ id: uid(), type: t, len: 8 });
  }
  return out.length ? out : [{ id: uid(), type: "verse", len: 16 }];
}

function blockFor(base: Comp, type: SectionType): string[] {
  const idx = base.types.indexOf(type);
  const start = idx >= 0 ? idx * 8 : 0;
  const block = base.layers.slice(start, start + 8);
  return block.length ? block : base.layers.slice(0, 8);
}

function inject(layer: string, letter: string, index: number, every: boolean) {
  if (layer.includes(letter)) return layer;
  if (!every && index % 2 !== 0) return layer;
  return `${layer} ${letter}`;
}

function trim(layer: string, on: Set<string>) {
  return Array.from(layer)
    .filter((ch) => ch === " " || on.has(ch))
    .join("")
    .replace(/\s+/g, " ")
    .trim();
}

/** Rebuild a playable composition from the draft: structure + timbres + levels. */
export function applyStudio(base: Comp, meta: StudioMeta): Comp {
  const laneOf = (id: LaneId) => meta.lanes.find((l) => l.id === id);
  const drums = laneOf("drums");
  const on = new Set<string>();
  for (const lane of meta.lanes) {
    if (!lane.on) continue;
    for (const ch of LANE_LETTERS[lane.id].replace(/\s/g, "")) on.add(ch);
  }
  // drums need at least a kick to be audible
  if (drums?.on && !on.has("k")) on.add("k");

  const pattern = DRUM_PATTERNS[drums?.voice ?? "four"] ?? DRUM_PATTERNS.four;
  const layers: string[] = [];
  for (const part of meta.parts) {
    const tmpl = blockFor(base, part.type);
    for (let i = 0; i < part.len; i++) {
      let l = tmpl[i % tmpl.length] ?? "";
      for (const lane of meta.lanes) {
        if (!lane.on || lane.id === "drums") continue;
        for (const ch of LANE_LETTERS[lane.id]) l = inject(l, ch, i, true);
      }
      if (drums?.on) {
        l = inject(l, "k", i, true);
        l = inject(l, "s", i, true);
        l = inject(l, "h", i, false);
      }
      layers.push(trim(l, on));
    }
  }

  const bass = laneOf("bass");
  const chords = laneOf("chords");
  const lead = laneOf("lead");
  const arp = laneOf("arp");

  const P = {
    ...base.P,
    bassI: (bass?.on ? (bass.voice as BassI) : base.P.bassI) as BassI,
    chordI: (chords?.on ? (chords.voice as ChordI) : base.P.chordI) as ChordI,
    leadI: (lead?.on ? (lead.voice as LeadI) : base.P.leadI) as LeadI,
    arpI: (arp?.on ? (arp.voice as ArpI) : base.P.arpI) as ArpI,
    kickP: pattern.kick,
    snareP: pattern.snare,
    hatP: pattern.hat,
    bassOct: Math.max(0, base.P.bassOct + (bass?.oct ?? 0)),
    leadOct: Math.max(1, base.P.leadOct + (lead?.oct ?? 0)),
  };

  const gains: Record<string, number> = {
    k: drums?.on ? drums.level : 0,
    s: drums?.on ? drums.level : 0,
    h: drums?.on ? drums.level : 0,
    b: bass?.on ? bass.level : 0,
    c: chords?.on ? chords.level : 0,
    l: lead?.on ? lead.level : 0,
    a: arp?.on ? arp.level : 0,
  };

  const bars = Math.max(4, layers.length);
  const bpm = Math.max(40, Math.min(220, Math.round(meta.bpm)));
  const sd = 60 / bpm / 4;
  const totalSteps = bars * 16;
  return {
    ...base,
    P,
    bpm,
    sd,
    bars,
    layers,
    totalSteps,
    gains,
    duration: totalSteps * sd + 1.2,
  };
}

/* ---------------- structure operations ---------------- */

export function splitPart(parts: Part[], id: string): Part[] {
  const i = parts.findIndex((p) => p.id === id);
  if (i < 0) return parts;
  const p = parts[i];
  if (p.len < 8) return parts;
  const half = Math.max(4, Math.round(p.len / 2 / 4) * 4);
  return [...parts.slice(0, i), { id: uid(), type: p.type, len: half }, { id: uid(), type: p.type, len: p.len - half }, ...parts.slice(i + 1)];
}

export function removePart(parts: Part[], id: string): Part[] {
  if (parts.length <= 1) return parts;
  return parts.filter((p) => p.id !== id);
}

export function appendPart(parts: Part[], type: SectionType, len = 8): Part[] {
  return [...parts, { id: uid(), type, len }];
}

export function cycleType(parts: Part[], id: string): Part[] {
  return parts.map((p) => (p.id === id ? { ...p, type: SECTION_ORDER[(SECTION_ORDER.indexOf(p.type) + 1) % SECTION_ORDER.length] } : p));
}

export function movePart(parts: Part[], id: string, dir: -1 | 1): Part[] {
  const i = parts.findIndex((p) => p.id === id);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= parts.length) return parts;
  const next = [...parts];
  [next[i], next[j]] = [next[j], next[i]];
  return next;
}

export function resizePart(parts: Part[], id: string, delta: number): Part[] {
  return parts.map((p) => (p.id === id ? { ...p, len: Math.max(4, Math.min(32, p.len + delta)) } : p));
}

export function resizeTotal(parts: Part[], target: number): Part[] {
  const diff = Math.round((target - totalBars(parts)) / 4) * 4;
  if (!diff) return parts;
  if (diff > 0) {
    const next = parts.map((p) => ({ ...p }));
    next[next.length - 1].len += diff;
    return next;
  }
  let left = -diff;
  const next = parts.map((p) => ({ ...p }));
  for (let i = next.length - 1; i >= 0 && left > 0; i--) {
    const cut = Math.min(left, Math.max(0, next[i].len - 4));
    next[i].len -= cut;
    left -= cut;
  }
  const kept = next.filter((p) => p.len > 0);
  return kept.length ? kept : parts;
}

/** Arrange the draft as intro → verse → chorus → verse → outro. */
export function autoStructure(bars: number): Part[] {
  const total = Math.max(8, Math.round(bars / 4) * 4);
  const intro = Math.min(8, Math.max(4, Math.floor(total / 8 / 4) * 4));
  const outro = intro;
  const body = Math.max(8, total - intro - outro);
  const verse = Math.max(4, Math.floor(body / 5 / 4) * 4);
  const chorus = Math.max(4, body - verse * 2);
  const draft: Part[] = [
    { id: uid(), type: "intro", len: intro },
    { id: uid(), type: "verse", len: verse },
    { id: uid(), type: "chorus", len: chorus },
    { id: uid(), type: "verse", len: verse },
    { id: uid(), type: "outro", len: outro },
  ];
  const parts = draft.filter((p) => p.len > 0);
  return parts.length ? parts : [{ id: uid(), type: "verse", len: 16 }];
}

/* ---------------- read-only helpers for the UI ---------------- */

export function metaFromTrack(t: Track, base: Comp): StudioMeta {
  return t.draft ?? createMeta(base, t.bpm);
}

/** Deterministic step grid shown in the lane rows. */
export function laneGrid(seed: number, laneId: LaneId, voice: string, cols = 32): boolean[] {
  const key = `${laneId}:${voice}`;
  let h = seed >>> 0;
  for (let i = 0; i < key.length; i++) h = (Math.imul(h ^ key.charCodeAt(i), 16777619) >>> 0) || 1;
  const out: boolean[] = [];
  for (let i = 0; i < cols; i++) {
    h = (Math.imul(h ^ (h >>> 15), 2246822519) >>> 0) || 7;
    const downbeat = i % 8 === 0;
    const beat = i % 4 === 0;
    const bias = laneId === "drums" ? (beat ? 0.82 : 0.12) : laneId === "bass" ? (beat ? 0.7 : 0.18) : laneId === "chords" ? (downbeat ? 0.85 : 0.2) : downbeat ? 0.6 : beat ? 0.42 : 0.18;
    out.push((h % 1000) / 1000 < bias);
  }
  return out;
}

export const fmtTime = (s: number) => `${Math.floor(s / 60)}:${Math.round(s % 60).toString().padStart(2, "0")}`;
