import type { Genre } from "./catalog";
import { localText, type Localized } from "../lib/i18n";

type Pair = [string, string];
const pairs = (values: Pair[]): Localized[] => values.map(([ru, en]) => ({ ru, en }));

const LINES = {
  hello: pairs([
    ["Привет! Имени нет, зато слух отличный.", "Hi! No name, but excellent ears."],
    ["Ты пришёл. Можно наконец включать бас.", "You're here. Finally, we can turn the bass on."],
    ["Мои пиксели готовы. Твои наушники?", "My pixels are ready. Are your headphones?"],
    ["Я уже занял место на плеере.", "I've already claimed a spot on the player."],
    ["Привет. Сегодня ищем новое или возвращаемся к любимому?", "Hey. Finding something new or going back to a favorite?"],
    ["О, ты. Я как раз разминал наушники.", "Oh, you. I was just warming up my headphones."],
    ["С возвращением. Я никуда не уходил. Ну почти.", "Welcome back. I didn't go anywhere. Almost."],
  ]),
  click: pairs([
    ["Эй, щекотно!", "Hey, that tickles!"],
    ["Я не кнопка. Ладно, немного кнопка.", "I'm not a button. Okay, a little bit."],
    ["Дай пять! Только осторожно, я пиксельный.", "High five! Careful, I'm made of pixels."],
    ["Нашёл меня. Теперь найди нам хороший трек.", "Found me. Now find us a good track."],
    ["Бип. Это моя версия светской беседы.", "Beep. That's my version of small talk."],
    ["Могу крутиться. Но сначала проверю карманы.", "I can spin. Let me check my pockets first."],
    ["В моих наушниках нет проводов. Удобно.", "No wires on my headphones. Very convenient."],
    ["Секретный жест разблокирован. Ничего не произошло, но красиво.", "Secret gesture unlocked. Nothing happened, but it looked good."],
    ["Не потеряй меня между вкладками.", "Don't lose me between tabs."],
    ["Ещё раз, и я станцую специально для тебя.", "One more time and I'll dance just for you."],
    ["Ой. Мой пиксельный баланс пошатнулся.", "Whoa. My pixel balance just wobbled."],
    ["Ты нашёл мою кнопку «случайно».", "You found my 'accidentally' button."],
  ]),
  idle: pairs([
    ["Тишина тоже звук. Но я бы добавил барабаны.", "Silence is sound too. I'd add drums, though."],
    ["Считаю клетки. Сбился на сорок второй.", "Counting grid squares. Lost count at forty-two."],
    ["Может, включим что-нибудь? Без обязательств.", "Shall we put something on? No commitment."],
    ["Чай есть. Музыки пока нет.", "Got tea. Still missing music."],
    ["Клетчатый пол очень удобен для маленьких прогулок.", "A grid floor is great for tiny walks."],
    ["Можно искать не название, а настроение. Я проверял.", "You can search for a mood, not just a title. I checked."],
    ["Трек может начинаться тихо. Не торопись пропускать.", "A track can start quietly. Don't skip too soon."],
    ["Если потеряю тебя, буду искать по звуку.", "If I lose you, I'll find you by sound."],
    ["Пока ты думаешь, я разомнусь.", "I'll stretch while you think."],
    ["У меня нет любимого жанра. Есть любимый момент.", "No favorite genre. Just favorite moments."],
    ["Смотрю на плеер. Он смотрит на меня. Всё честно.", "I'm watching the player. It's watching me. Fair deal."],
    ["Если станет скучно, я умею делать вид, что занят.", "If it gets boring, I can pretend to be very busy."],
    ["Проверяю RGB. Пурпур, лайм, ещё пурпур.", "Checking RGB. Violet, lime, more violet."],
  ]),
  listen: pairs([
    ["Вот это бас. Пиксели слегка дрожат.", "That's some bass. My pixels are shaking."],
    ["Киваю головой, значит, хорошо.", "Head nodding. That's a good sign."],
    ["Этот переход стоило дождаться.", "That transition was worth waiting for."],
    ["Не мешаю. Слушаем.", "Not interrupting. Let's listen."],
    ["Восемь бит снаружи, хороший слух внутри.", "Eight-bit outside, good ears inside."],
    ["Запомнил, что тебе заходит. Следующий трек будет ближе.", "Noted what you like. The next track will get closer."],
    ["Слушаю не громкость, а то, что между нотами.", "Listening past the volume, to what's between the notes."],
    ["Отличный момент для маленького танца.", "Perfect time for a tiny dance."],
    ["Если бы у меня были брови, они бы сейчас поднялись.", "If I had eyebrows, they'd be raised right now."],
    ["Оставляю место для следующего бара.", "Saving room for the next bar."],
  ]),
  like: pairs([
    ["О, прямо в сердечко!", "Oh, right in the heart!"],
    ["Сердечки не помещаются в мою голову.", "All these hearts don't fit in my head."],
    ["Запомнил. Такое тебе нравится.", "Noted. This is your kind of thing."],
    ["Хороший вкус. Пожму твою руку, когда дорасту.", "Good taste. I'll shake your hand when I grow tall enough."],
    ["Ещё один лайк. Коллекция становится интереснее.", "Another like. The collection gets more interesting."],
    ["У меня улыбка на целых два пикселя шире.", "My smile is two whole pixels wider."],
    ["Одобряем вместе.", "Approved by both of us."],
    ["Сердце сохранено. Я тоже.", "Heart saved. Me too."],
    ["Это уже не просто лайк. Это маленький праздник.", "That's not just a like. That's a tiny celebration."],
  ]),
  dislike: pairs([
    ["Понял. Ищем другой звук.", "Got it. Let's find a different sound."],
    ["Не твоё. Бывает, ничего страшного.", "Not your thing. That's fine."],
    ["Меньше этого, больше того, что нравится.", "Less of this, more of what you like."],
    ["Смена курса. Мой маленький радар уже работает.", "Changing course. My tiny radar is on it."],
    ["Окей, вычёркиваю. Даже без ластика.", "Okay, crossing it out. No eraser needed."],
    ["Дизлайк принят. Пиксели слегка нахмурились.", "Dislike noted. My pixels frowned a little."],
    ["Этот трек больше не в нашей команде.", "This track is off the team."],
    ["Понял сигнал. Ищу что-то ближе к тебе.", "Signal received. Looking for something closer to you."],
    ["Хорошо, что сказал. Иначе я бы ещё раз поставил.", "Good you said so. I might have played it again."],
    ["Минус один. Плюс опыт.", "Minus one. Plus experience."],
    ["Не то. Перестраиваю волну.", "Not it. Retuning the wave."],
    ["Этот звук уходит. Другой уже подходит.", "That sound is leaving. Another one is already on the way."],
  ]),
  leave: pairs([
    ["Схожу за чаем. Позови кнопкой слева сверху.", "Getting tea. Call me with the top-left button."],
    ["Пойду проветрить пиксели. Кнопка слева знает, где я.", "Off to air out my pixels. The left button knows where I am."],
    ["Пять минут без меня. Если соскучишься, позови.", "Five minutes without me. Call if you miss me."],
    ["Прогуляюсь за край экрана. Обещаю, там безопасно.", "Taking a walk past the screen edge. I promise it's safe."],
    ["Сменю наряд и вернусь. Не подглядывай.", "Changing outfits. No peeking."],
    ["Ухожу за новыми пикселями. Вернусь другим.", "Going for new pixels. I'll come back different."],
    ["Мне нужно в гримёрку. Да, у меня есть гримёрка.", "I need the dressing room. Yes, I have one."],
  ]),
  back: pairs([
    ["Вернулся! Что успело зазвучать?", "Back! What did I miss?"],
    ["Я тут. Чай слегка горячий.", "Here I am. The tea's a bit hot."],
    ["Слышал зов. Прибежал так быстро, как позволили пиксели.", "Heard you call. Ran as fast as my pixels allowed."],
    ["Снова на плеере. Лучшее место в приложении.", "Back on the player. Best spot in the app."],
    ["Скучал? Я немного.", "Missed me? I missed you a little."],
  ]),
  outfit: pairs([
    ["Новый наряд. Старый вкус.", "New outfit. Same taste."],
    ["Переоделся. Надеюсь, тебе заходит.", "Changed clothes. Hope you like it."],
    ["Свежий пиксельный look. Оцени.", "Fresh pixel look. Rate it."],
    ["Я сменил одежду. Сердце всё то же.", "New clothes. Same heart."],
    ["Гардероб обновлён. Можно снова слушать.", "Wardrobe updated. We can listen again."],
    ["Как тебе? Я сам ещё не решил.", "How do I look? I haven't decided yet."],
    ["Чуть другой силуэт. Тот же бас в голове.", "Slightly different silhouette. Same bass in my head."],
  ]),
  censor: pairs([
    ["Эй, без мата. Скажи то же самое красивее.", "Hey, no swearing. Same thought, nicer words."],
    ["Острые мысли можно без острых слов.", "Sharp thoughts don't need harsh words."],
    ["Я маленький, но цензуру вижу.", "I'm tiny, but I can spot profanity."],
    ["Перефразируй. Хорошая мысль от этого не пропадёт.", "Rephrase it. A good idea won't disappear."],
    ["Фильтр сработал. Я с ним.", "Filter triggered. I'm with it."],
  ]),
  upload: pairs([
    ["Новый звук в библиотеке. Горжусь!", "A new sound in the library. Proud of you!"],
    ["Теперь могу и твой трек поставить в Резонанс.", "Now I can put your track in Resonance too."],
    ["Ура. Это уже не черновик, а релиз.", "Yes! Not a draft anymore, a release."],
    ["Своя музыка всегда звучит чуть иначе. Слушаем?", "Your own music always sounds a little different. Shall we listen?"],
  ]),
  wake: pairs([
    ["А? Не сплю. Просто глаза на паузе.", "Huh? Not sleeping. My eyes were on pause."],
    ["Мне снился очень ровный бас.", "I dreamed of a very steady bassline."],
    ["Одна нота, и я снова здесь.", "One note and I'm back."],
    ["Будильник отменяется. Ты уже нажал.", "No need for an alarm. You already clicked."],
    ["Я не храпел. Это был низкий синт.", "I wasn't snoring. That was a low synth."],
  ]),
  pause: pairs([
    ["Пауза. Мои ноги говорят спасибо.", "Pause. My feet say thank you."],
    ["Передышка тоже часть ритма.", "A break is part of the rhythm too."],
    ["Не ухожу. Просто отдышусь.", "Not leaving. Just catching my breath."],
    ["Стоп. Можно перевести дух.", "Stop. Time to breathe."],
  ]),
  post: pairs([
    ["Новая тема! Прочитаю первым, я тут близко.", "New topic! I'll read it first, I'm right here."],
    ["Хороший разговор тоже начинается с одного звука.", "A good conversation starts with one sound too."],
    ["Отправлено. Можно выдохнуть и включить музыку.", "Posted. Breathe out and put some music on."],
    ["Тема сохранена. Мой пиксельный блокнот кивает.", "Topic saved. My pixel notebook approves."],
  ]),
  reply: pairs([
    ["Ответ на месте. Цитата тоже не потерялась.", "Reply's in. The quote made it too."],
    ["Слова отправлены. Возвращаюсь к басу.", "Words sent. Back to the bass."],
    ["Спасибо, что поддерживаешь разговор.", "Thanks for keeping the conversation going."],
    ["Разговор стал на одно сообщение длиннее.", "The conversation is one message longer."],
  ]),
  format: pairs([
    ["Выдели текст, нажми B. Будет жирно, но не громко.", "Select text, press B. Bold, not loud."],
    ["Спойлер прячет слова. Меня так спрятать не получится.", "Spoilers hide words. They can't hide me."],
    ["В таблицах удобно сравнивать. В музыке удобнее слушать.", "Tables are good for comparisons. Music is better for listening."],
    ["Цитата помнит, кто сказал. Я тоже стараюсь.", "Quotes remember who said it. I try to do that too."],
    ["Теги видно в редакторе. Результат видно в предпросмотре.", "Tags in the editor. Results in the preview."],
    ["Код здесь не запускается, только красиво лежит.", "Code doesn't run here. It just looks nice."],
  ]),
  language: pairs([
    ["Снова по-русски. Бит переводить не надо.", "English now. The beat needs no translation."],
    ["Сменили язык, не настроение.", "New language, same mood."],
    ["Я говорю на двух языках и одном басу.", "I speak two languages and one bassline."],
    ["Наушники те же. Реплики теперь другие.", "Same headphones. Different lines."],
  ]),
  dark: pairs([
    ["Темно. Неон видно лучше.", "Dark now. The neon stands out."],
    ["Ночной режим. Я не засну, обещаю.", "Night mode. I won't fall asleep, promise."],
    ["Фиолетовый свет мне идёт.", "Violet light suits me."],
  ]),
  light: pairs([
    ["Свет включили. Я всё ещё пиксельный.", "Lights on. I'm still pixelated."],
    ["Теперь видно каждую клетку. Проверю порядок.", "Now I can see every grid square. Time to check them."],
    ["Светлая тема, тёмный бас. Хорошее сочетание.", "Light theme, dark bass. Nice combination."],
  ]),
  forum: pairs([
    ["Читаю обсуждения. Руки маленькие, мнение большое.", "Reading discussions. Tiny hands, big opinions."],
    ["Хороший вопрос тоже стоит лайка.", "A good question deserves a like too."],
    ["Здесь можно не согласиться и остаться друзьями.", "You can disagree here and still be friends."],
    ["В голове музыка, в блокноте аргументы.", "Music in my head, arguments in my notebook."],
    ["Буду читать. Если нужен я, просто нажми.", "I'll be reading. Tap me if you need me."],
  ]),
  tea: pairs([
    ["Чай без сахара, трек с теплом.", "Tea without sugar, a track with warmth."],
    ["Только не пролить на плеер.", "Just don't spill it on the player."],
    ["Горячий чай и хороший ритм. Больше ничего.", "Hot tea and a good rhythm. Nothing else needed."],
    ["Глоток. Пауза. Снова глоток.", "Sip. Pause. Sip again."],
  ]),
  stretch: pairs([
    ["Разминаю пиксели. Спина тоже любит паузы.", "Stretching my pixels. Backs like breaks too."],
    ["Двадцать один пиксель роста. Все надо размять.", "Twenty-one pixels tall. All of them need a stretch."],
    ["Потянись со мной. Трек никуда не уйдёт.", "Stretch with me. The track isn't going anywhere."],
  ]),
  sulk: pairs([
    ["Немного надулся. Скоро пройдёт.", "A tiny sulk. It'll pass."],
    ["Дизлайк меня не ломает. Только учит.", "A dislike doesn't break me. It teaches me."],
    ["Отвернулся. Для драмы.", "Turned away. For the drama."],
  ]),
  celebrate: pairs([
    ["Праздник! Даже если маленький.", "Celebration! Even if it's tiny."],
    ["Хлопнул. Пиксели одобряют.", "Clap. The pixels approve."],
    ["Это было красиво. Ещё раз?", "That was beautiful. Again?"],
  ]),
  gamer: pairs([
    ["RGB синхронизирован. Перехожу на пиксельную клавиатуру.", "RGB synced. Switching to the pixel keyboard."],
    ["Нажал воображаемый пробел. Отличная реакция.", "Hit an imaginary spacebar. Great reflexes."],
    ["Счёт: я, бас и эта песня — один раунд впереди.", "Score: me, the bass and this song — one round ahead."],
    ["Режим игрока активирован. Не отвлекать, если только это не лайм.", "Player mode on. Do not disturb, unless it's lime."],
  ]),
  think: pairs([
    ["Думаю... громко, но внутри.", "Thinking... loudly, but inside."],
    ["Считаю варианты. Один. Два. Бас.", "Counting options. One. Two. Bass."],
    ["Идея почти готова. Ещё секунда.", "Idea almost ready. One more second."],
  ]),
  sand: pairs([
    ["О, песок! Не в чашку, пожалуйста.", "Oh, sand! Not in the cup, please."],
    ["Переход как дюна. Мне нравится.", "A transition like a dune. I like it."],
    ["Песок ушёл. Вкладка осталась.", "Sand's gone. The tab stayed."],
  ]),
};

const GENRE_LINES: Record<Genre, Localized[]> = {
  synthwave: pairs([
    ["Неон, трасса, 1986-й. Пристегнулся.", "Neon, highway, 1986. Seatbelt on."],
    ["Этот синт звучит как старый добрый вечер.", "That synth sounds like a familiar old evening."],
    ["Хочу закат в наушниках.", "I want a sunset in my headphones."],
  ]),
  lofi: pairs([
    ["Лоу-фай. Достаю маленькую чашку.", "Lo-fi. Getting my tiny cup."],
    ["Под это даже клетчатый пол мягче.", "Even the grid floor feels softer with this."],
    ["Шум кассеты — мой белый шум.", "Tape hiss is my white noise."],
  ]),
  phonk: pairs([
    ["Фонк. Берегу пиксельную шею.", "Phonk. Protecting my pixel neck."],
    ["Ковбелл опять победил тишину.", "The cowbell defeated silence again."],
    ["Дрифт в голове, ноги на месте.", "Drifting in my head, feet stay put."],
  ]),
  techno: pairs([
    ["Четыре в пол. Я на своём месте.", "Four on the floor. Right where I belong."],
    ["Кажется, этот рейв помещается в моих наушниках.", "I think this whole rave fits in my headphones."],
    ["Заводской бит, домашняя улыбка.", "Factory beat, home smile."],
  ]),
  ambient: pairs([
    ["Не торопимся. Тут целая орбита.", "No rush. There's a whole orbit here."],
    ["Слушаю паузы. Они тоже красивые.", "Listening to the gaps. They're beautiful too."],
    ["Тише — и мир становится больше.", "Quieter, and the world gets bigger."],
  ]),
  rock: pairs([
    ["Гитары! Моя воздушная уже настроена.", "Guitars! My air guitar is tuned up."],
    ["Соседи услышат. Но я маленький, меня простят.", "The neighbors will hear. But I'm tiny, they'll forgive me."],
    ["Три аккорда — и я уже в гараже.", "Three chords and I'm already in the garage."],
  ]),
  trap: pairs([
    ["808 такой глубокий, что я смотрю вниз.", "That 808 is so deep I'm looking down."],
    ["Редкая бочка, много пространства. Нравится.", "Sparse kick, lots of space. I like it."],
    ["Тяжёлый низ, лёгкая голова.", "Heavy low end, light head."],
  ]),
  hyperpop: pairs([
    ["Слишком много энергии для восьми бит. Танцую.", "Too much energy for eight bits. Dancing anyway."],
    ["Если моргну, пропущу половину звуков.", "If I blink, I'll miss half the sounds."],
    ["Сахар, глитч и никаких пауз.", "Sugar, glitch and no pauses."],
  ]),
};

const previous = new Map<string, number>();
function choose(key: string, values: Localized[]) {
  let index = Math.floor(Math.random() * values.length);
  if (values.length > 1 && index === previous.get(key)) index = (index + 1) % values.length;
  previous.set(key, index);
  return localText(values[index]);
}
export function companionLine(key: keyof typeof LINES) {
  return choose(key, LINES[key]);
}
export function genreLine(genre: Genre) {
  return choose(genre, GENRE_LINES[genre]);
}
