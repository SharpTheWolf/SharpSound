import type { Localized } from "../lib/i18n";

export type RoomId = "general" | "discoveries" | "production" | "ideas" | "help";
export type TopicKind = "discussion" | "artwork" | "guide";
export interface ForumAuthor { id: string; name: string; hue: number; shape: number; team?: boolean }
export interface ForumImage { src: string; caption: string | Localized }
export interface Reply {
  id: string;
  author: ForumAuthor;
  body: string | Localized;
  createdAt: number;
  editedAt?: number;
  votes: number;
}
export interface Topic {
  id: string;
  title: string | Localized;
  body: string | Localized;
  author: ForumAuthor;
  room: RoomId;
  kind: TopicKind;
  createdAt: number;
  lastAt: number;
  editedAt?: number;
  pinned?: boolean;
  example?: boolean;
  votes: number;
  replies: Reply[];
  image?: ForumImage;
  trackId?: string;
}
export interface TopicDraft { title: string; body: string; room: RoomId; kind: TopicKind; image?: ForumImage; trackId?: string }

export const ROOMS: { id: RoomId; label: Localized; desc: Localized; hue: number; shape: number }[] = [
  { id: "general", label: { ru: "Общий звук", en: "Common ground" }, desc: { ru: "Разговоры без жанровых границ", en: "Conversations beyond genres" }, hue: 270, shape: 0 },
  { id: "discoveries", label: { ru: "Музыкальные находки", en: "Music discoveries" }, desc: { ru: "То, что хочется передать дальше", en: "Sounds worth passing on" }, hue: 95, shape: 2 },
  { id: "production", label: { ru: "За пультом", en: "Behind the decks" }, desc: { ru: "Сведение, обложки и первые релизы", en: "Mixing, covers and first releases" }, hue: 190, shape: 5 },
  { id: "ideas", label: { ru: "Идеи для SharpSound", en: "Ideas for SharpSound" }, desc: { ru: "Что стоит сделать по-другому", en: "What could be done differently" }, hue: 315, shape: 4 },
  { id: "help", label: { ru: "Помощь и вопросы", en: "Help and questions" }, desc: { ru: "Разберёмся вместе", en: "Let's figure it out together" }, hue: 215, shape: 1 },
];

export const EMPTY_DRAFT: TopicDraft = { title: "", body: "", room: "general", kind: "discussion" };

export function seedTopics(): Topic[] {
  const now = Date.now();
  const hour = 3600000;
  const ago = (h: number) => now - h * hour;
  const people: ForumAuthor[] = [
    { id: "team", name: "SharpSound", hue: 270, shape: 0, team: true },
    { id: "luma", name: "luma.wav", hue: 95, shape: 2 },
    { id: "niko", name: "niko / 404", hue: 270, shape: 5 },
    { id: "tape", name: "tape.dust", hue: 25, shape: 1 },
    { id: "echo", name: "echo.exe", hue: 315, shape: 4 },
    { id: "sora", name: "Sora", hue: 190, shape: 3 },
  ];
  const reply = (id: string, who: number, h: number, ru: string, en: string, votes = 0): Reply => ({ id, author: people[who], body: { ru, en }, createdAt: ago(h), votes });
  const topic = (id: string, who: number, h: number, room: RoomId, ruTitle: string, enTitle: string, ru: string, en: string, replies: Reply[], extra: Partial<Topic> = {}): Topic => ({
    id, author: people[who], createdAt: ago(h), lastAt: replies.length ? replies[replies.length - 1].createdAt : ago(h), room,
    title: { ru: ruTitle, en: enTitle }, body: { ru, en }, kind: "discussion", example: true, votes: 0, replies, ...extra,
  });
  return [
    topic("welcome", 0, 72, "general", "Сначала звук. Потом разговор.", "Sound first. Conversation second.",
      "[h2]Добро пожаловать в SharpSound[/h2]\nЗдесь делятся находками, спорят о звуке и помогают друг другу собрать первый релиз.\n[list][*]Обсуждай музыку, а не человека.[*]Показывай свои работы, не выдавая чужие за свои.[*]Если нужен совет, расскажи, что уже пробовал.[/list]\n[hr][/hr]\n[b]Сейчас это локальное пространство.[/b] Эти темы служат примерами. Твои публикации сохраняются на устройстве, без отправки на сервер. Для общения с другими людьми понадобится подключение сервера.",
      "[h2]Welcome to SharpSound[/h2]\nShare discoveries, discuss sound and help each other finish a first release.\n[list][*]Discuss the music, not the person.[*]Share your work without claiming someone else's.[*]When asking for advice, explain what you've tried.[/list]\n[hr][/hr]\n[b]This is a local space for now.[/b] These topics are examples. Your posts stay on your device and are not sent to a server. Connecting a server is needed to talk with other people.", [], { pinned: true, votes: 12 }),
    topic("night", 1, 8, "discoveries", "Один трек для пустого города в 03:00?", "One track for an empty city at 03:00?",
      "Есть музыка для дороги, а есть для момента, когда дорога уже закончилась.\n[b]Какой трек включаете, когда город наконец затих?[/b]\nУ меня это «Тихая орбита». Не торопится, не требует внимания. А у вас?",
      "There's music for the journey, and music for when the journey is over.\n[b]What do you play when the city finally goes quiet?[/b]\nMine is 'Тихая орбита'. No rush, no demands. What's yours?",
      [reply("night-r1", 2, 6.3, "[quote=luma.wav]Когда город наконец затих?[/quote]У меня наоборот: «Ксенон». Дорога пустая, а бас нет.", "[quote=luma.wav]When the city finally goes quiet?[/quote]The opposite for me: 'Ксенон'. The road is empty but the bass isn't.", 8),
       reply("night-r2", 3, 2, "«Окно на пятом». Особенно если дождь. Наушники и никакого плана.", "'Окно на пятом'. Especially in the rain. Headphones, no plan.", 5),
       reply("night-r3", 5, 0.7, "[b]Тихая орбита[/b] тоже в списке. Самая интересная часть там между нотами.", "[b]Тихая орбита[/b] is on my list too. The best part is between the notes.", 3)], { votes: 24, trackId: "a5t1" }),
    topic("companion", 4, 5, "ideas", "А что если помощник будет учиться вашим танцам?", "What if the companion could learn your dance moves?",
      "Он уже качает головой под бит. Хочется сохранить любимые движения для разных жанров.\n[list][*]Рок: воздушная гитара.[*]Фонк: маленький хедбанг.[*]Лоу-фай: плед и чай.[/list]\n[spoiler]Да, я полчаса смотрел, как он ходит по плееру.[/spoiler]",
      "It already nods to the beat. I'd love to keep favorite moves for different genres.\n[list][*]Rock: air guitar.[*]Phonk: a tiny headbang.[*]Lo-fi: blanket and tea.[/list]\n[spoiler]Yes, I spent half an hour watching it walk around the player.[/spoiler]",
      [reply("companion-r1", 1, 3, "Голосую за воздушную гитару. Только не пусть он её ест.", "Voting for air guitar. Just don't let it eat the guitar.", 6),
       reply("companion-r2", 2, 1.2, "И кнопку, чтобы дать пять. Это важно.", "And a high-five button. This is important.", 9)], { votes: 31 }),
    topic("mix", 2, 14, "production", "808 и бочка спорят. Как их помирить?", "The 808 and kick are fighting. How do I make peace?",
      "Оба инструмента отдельно звучат нормально, вместе съедают друг друга.\n[code]kick: 55 Hz\n808: 45 Hz\nmaster peak: -1 dB[/code]\nСайдчейн уже пробовал. Может, слишком длинная бочка?",
      "Both sound fine on their own, but together they eat each other.\n[code]kick: 55 Hz\n808: 45 Hz\nmaster peak: -1 dB[/code]\nAlready tried sidechain. Could the kick be too long?",
      [reply("mix-r1", 3, 10, "[b]Да, начни с длины.[/b] Укороти хвост бочки, потом проверь фазу. Эквалайзер лучше оставить напоследок.", "[b]Start with the length.[/b] Shorten the kick tail, then check the phase. Leave EQ for last.", 11),
       reply("mix-r2", 5, 4, "Послушай в моно и на тихой громкости. Часто там всё становится понятно.", "Listen in mono at low volume. That usually makes things clear.", 7)], { votes: 17 }),
    topic("art", 5, 22, "production", "Набросок персонажа для ночного синтвейва", "A character sketch for late-night synthwave",
      "Не хотелось делать очередной силуэт на фоне заката. Получился пилот, которому не нужен обратный билет.\n[i]Покритикуйте свет и палитру, особенно лаймовые акценты.[/i]",
      "I didn't want another silhouette against a sunset. Ended up with a pilot who doesn't need a return ticket.\n[i]Feedback on lighting and the palette is welcome, especially the lime accents.[/i]",
      [reply("art-r1", 4, 12, "Свет классный! На маленькой обложке лучше чуть сильнее отделить голову от фона.", "Love the light! On a small cover, I'd separate the head from the background a bit more.", 4)],
      { kind: "artwork", image: { src: "characters/synthwave.jpg", caption: { ru: "Ретро-пилот, исследование палитры SharpSound", en: "Retro pilot, a SharpSound palette study" } }, votes: 19 }),
    topic("formatting", 0, 36, "help", "Как оформить пост, чтобы его хотелось читать", "How to write a post people want to read",
      "[h2]Не стена текста, а разговор[/h2]\n[h3]Три простых правила[/h3]\n[olist][*]Главная мысль в первой строке.[*]Длинные части разбивай заголовками.[*]Чужие слова оформляй цитатой.[/olist]\n[quote=SharpSound]Хороший вопрос часто важнее длинного ответа.[/quote]\n[table equalcells=1][tr][th]Нужно[/th][th]Разметка[/th][/tr][tr][td]Выделить мысль[/td][td][noparse][b]мысль[/b][/noparse][/td][/tr][tr][td]Убрать спойлер[/td][td][noparse][spoiler]секрет[/spoiler][/noparse][/td][/tr][/table]\nКнопки над редактором вставляют теги за тебя. В справке есть все примеры.",
      "[h2]A conversation, not a wall of text[/h2]\n[h3]Three simple rules[/h3]\n[olist][*]Put the main point in the first line.[*]Break long sections up with headings.[*]Quote other people's words.[/olist]\n[quote=SharpSound]A good question often matters more than a long answer.[/quote]\n[table equalcells=1][tr][th]Goal[/th][th]Markup[/th][/tr][tr][td]Emphasize a point[/td][td][noparse][b]point[/b][/noparse][/td][/tr][tr][td]Hide a spoiler[/td][td][noparse][spoiler]secret[/spoiler][/noparse][/td][/tr][/table]\nToolbar buttons insert the tags for you. The formatting guide has all the examples.", [], { kind: "guide", votes: 15 }),
    topic("mic", 3, 7, "help", "Распознавание не слышит музыку. Что проверить?", "Recognition can't hear my music. What should I check?",
      "Микрофон разрешён, но приложение пишет, что слишком тихо. С ноутбука всё работает, а с телефона нет.\n[b]Есть идеи, что мог пропустить?[/b]",
      "Microphone permission is on, but the app says it's too quiet. It works on my laptop, not on my phone.\n[b]Any ideas what I'm missing?[/b]",
      [reply("mic-r1", 0, 5.5, "Проверь, что источник не играет в наушники. Для микрофона нужна защищённая страница (HTTPS) или localhost. Можно также распознать файл.", "Check that the source isn't playing through headphones. The microphone needs a secure page (HTTPS) or localhost. You can also recognize a file.", 6)], { votes: 4 }),
    topic("lofi", 3, 18, "general", "Шум кассеты: атмосфера или просто шум?", "Tape hiss: atmosphere or just noise?",
      "Люблю кассеты, но иногда в лоу-фай шум слышно громче самой музыки.\n[u]Где ваша граница?[/u] И нужен ли виниловый треск, если трек никогда не был на виниле?",
      "I love tapes, but in some lo-fi the hiss is louder than the music.\n[u]Where do you draw the line?[/u] And does a track need vinyl crackle if it was never on vinyl?",
      [reply("lofi-r1", 1, 11, "Если хочется выключить шум, значит, его много. Всё остальное дело вкуса.", "If you want to turn the hiss off, there's too much. Everything else is taste.", 12),
       reply("lofi-r2", 2, 8, "[strike]Чем больше шума, тем дороже кассета.[/strike]\nСерьёзно: он должен быть частью ритма, а не маскировать плохое сведение.", "[strike]More hiss, more expensive tape.[/strike]\nSeriously though: it should be part of the rhythm, not a mask for bad mixing.", 8)], { votes: 21, trackId: "a2t3" }),
  ];
}