import { compose, rng, type Comp, type Genre } from "../audio/synth";
import type { FP } from "../audio/analysis";
import { applyStudio, type StudioMeta } from "./studio";

export type { Genre };

export interface Features {
  energy: number;
  bright: number;
  dark: number;
  tempo: number;
  dense: number;
  acoustic: number;
}

export type CoverStyle = "ring" | "waves" | "spiral" | "blob" | "wire" | "claws" | "bars" | "iso";

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  albumId: string;
  genre: Genre;
  bpm: number;
  duration: number;
  seed: number;
  hue: number;
  cover: CoverStyle;
  f: Features;
  tags: string[];
  source: "synth" | "upload";
  studio?: boolean;
  draft?: StudioMeta;
  coverUrl?: string;
  fp?: FP;
  desc?: string;
  createdAt?: number;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  genre: Genre;
  hue: number;
  cover: CoverStyle;
  year: number;
  seed: number;
  trackIds: string[];
}

export interface GenreMeta {
  label: string;
  hue: number;
  color: string;
  base: Features;
  tags: string[];
  char: { name: string; desc: string; img: string };
}

export const GENRES: Record<Genre, GenreMeta> = {
  synthwave: {
    label: "Синтвейв", hue: 285, color: "#c084fc",
    base: { energy: 0.62, bright: 0.62, dark: 0.5, tempo: 0.4, dense: 0.6, acoustic: 0.08 },
    tags: ["синтвейв", "synthwave", "ретро", "80", "неон", "ночь", "трасса", "драйв", "retrowave", "вечер"],
    char: { name: "Ретро-пилот", desc: "Летит в 1986-й, обратный билет не брал. Любит неон, длинные трассы и тёплый аналоговый звук.", img: "characters/synthwave.jpg" },
  },
  lofi: {
    label: "Лоу-фай", hue: 28, color: "#fdba74",
    base: { energy: 0.24, bright: 0.3, dark: 0.4, tempo: 0.12, dense: 0.35, acoustic: 0.72 },
    tags: ["лоуфай", "lofi", "lo-fi", "учеба", "учёба", "чай", "дождь", "уют", "спокойн", "chill", "чилл", "фон", "грустн"],
    char: { name: "Мечтатель с пледом", desc: "Чай остыл, конспект открыт на той же странице. Ему хорошо, и это главное.", img: "characters/lofi.jpg" },
  },
  phonk: {
    label: "Фонк", hue: 275, color: "#a78bfa",
    base: { energy: 0.86, bright: 0.55, dark: 0.86, tempo: 0.65, dense: 0.74, acoustic: 0.04 },
    tags: ["фонк", "phonk", "дрифт", "drift", "машин", "бас", "ковбел", "cowbell", "ночь", "злой", "агрессив", "тачк"],
    char: { name: "Ночной гонщик", desc: "Ксенон, туман, педаль в пол. Разговаривает только басом.", img: "characters/phonk.jpg" },
  },
  techno: {
    label: "Техно", hue: 90, color: "#bef264",
    base: { energy: 0.8, bright: 0.5, dark: 0.64, tempo: 0.56, dense: 0.7, acoustic: 0.04 },
    tags: ["техно", "techno", "клуб", "рейв", "rave", "танц", "завод", "4/4", "кислот", "acid", "электрон"],
    char: { name: "Рейвер", desc: "Живёт в размере 4/4 и засыпает после восхода. Знает все склады города.", img: "characters/techno.jpg" },
  },
  ambient: {
    label: "Эмбиент", hue: 190, color: "#67e8f9",
    base: { energy: 0.1, bright: 0.45, dark: 0.35, tempo: 0.04, dense: 0.14, acoustic: 0.55 },
    tags: ["эмбиент", "ambient", "космос", "сон", "медитац", "тихо", "спокойн", "фокус", "пространств", "релакс"],
    char: { name: "Звездочёт", desc: "Слушает тишину между нотами и считает спутники вместо овец.", img: "characters/ambient.jpg" },
  },
  rock: {
    label: "Рок", hue: 350, color: "#fb7185",
    base: { energy: 0.86, bright: 0.7, dark: 0.5, tempo: 0.58, dense: 0.82, acoustic: 0.42 },
    tags: ["рок", "rock", "гитар", "гараж", "панк", "punk", "драйв", "громк", "живой"],
    char: { name: "Рокер из гаража", desc: "Три аккорда, честный звук и соседи, которые уже всё поняли.", img: "characters/rock.jpg" },
  },
  trap: {
    label: "Трэп", hue: 262, color: "#8b5cf6",
    base: { energy: 0.6, bright: 0.4, dark: 0.8, tempo: 0.68, dense: 0.55, acoustic: 0.08 },
    tags: ["трэп", "trap", "рэп", "rap", "хип-хоп", "хипхоп", "808", "район", "бас", "мрачн"],
    char: { name: "Районный поэт", desc: "Басы глубже, чем разговоры на кухне. Пишет строки в заметках телефона.", img: "characters/trap.jpg" },
  },
  hyperpop: {
    label: "Гиперпоп", hue: 315, color: "#f0abfc",
    base: { energy: 0.95, bright: 0.95, dark: 0.14, tempo: 0.8, dense: 0.9, acoustic: 0 },
    tags: ["гиперпоп", "hyperpop", "поп", "pop", "весел", "энерг", "глитч", "glitch", "сахар", "быстр", "радост"],
    char: { name: "Глитч-кид", desc: "Сахар, баги и 160 ударов в минуту. Паузу не ставит никогда.", img: "characters/hyperpop.jpg" },
  },
};

export const GENRE_LIST = Object.keys(GENRES) as Genre[];

type RawTrack = [string, CoverStyle, string[]];
const RAW: { id: string; artist: string; album: string; genre: Genre; hue: number; year: number; tracks: RawTrack[] }[] = [
  { id: "a1", artist: "Night Ferry", album: "Хромовый закат", genre: "synthwave", hue: 282, year: 2024,
    tracks: [["Хромовый закат", "bars", ["закат", "вечер"]], ["Полоса 404", "ring", ["трасса", "скорость"]], ["Ветер с трассы", "wire", ["ветер", "дорога"]]] },
  { id: "a2", artist: "тёплый плед", album: "Чай остыл", genre: "lofi", hue: 24, year: 2023,
    tracks: [["Чай остыл", "blob", ["чай", "утро"]], ["Окно на пятом", "waves", ["окно", "дождь"]], ["Пыль на кассете", "spiral", ["кассета", "винтаж"]]] },
  { id: "a3", artist: "MRAK DRIVE", album: "Обочина", genre: "phonk", hue: 272, year: 2025,
    tracks: [["Обочина", "claws", ["трасса", "тьма"]], ["Ксенон", "ring", ["фары", "свет"]], ["Дрифт под фонарями", "bars", ["дрифт", "город"]]] },
  { id: "a4", artist: "Kollektor", album: "Цех №7", genre: "techno", hue: 88, year: 2024,
    tracks: [["Цех №7", "iso", ["завод", "индастриал"]], ["Бетон и пар", "wire", ["бетон", "пар"]], ["Сигнал на рассвете", "bars", ["рассвет", "утро"]]] },
  { id: "a5", artist: "Sora Lume", album: "Тихая орбита", genre: "ambient", hue: 188, year: 2023,
    tracks: [["Тихая орбита", "waves", ["орбита", "космос"]], ["Глубина 3000", "blob", ["океан", "глубина"]], ["Снег на антенне", "wire", ["снег", "зима"]]] },
  { id: "a6", artist: "Кривые Струны", album: "Шум в подъезде", genre: "rock", hue: 352, year: 2025,
    tracks: [["Шум в подъезде", "ring", ["подъезд", "двор"]], ["Ржавый мост", "claws", ["мост", "река"]], ["Последний трамвай", "iso", ["трамвай", "ночь"]]] },
  { id: "a7", artist: "VIOLET 9", album: "Кислотный дождь", genre: "trap", hue: 262, year: 2025,
    tracks: [["Кислота", "blob", ["кислота", "дождь"]], ["Лёд в стакане", "claws", ["лёд", "лед"]], ["Ночной район", "spiral", ["район", "ночь"]]] },
  { id: "a8", artist: "glitchgirl.exe", album: "<3 перегрузка", genre: "hyperpop", hue: 312, year: 2025,
    tracks: [["Перегрузка", "spiral", ["перегрузка", "громко"]], ["Сахарный баг", "blob", ["сахар", "баг"]], ["Пиксельное сердце", "iso", ["пиксель", "сердце", "любовь"]]] },
];

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const COMPS = new Map<string, Comp>();

export const TRACKS: Track[] = [];
export const ALBUMS: Album[] = [];

RAW.forEach((a, ai) => {
  const al: Album = {
    id: a.id, title: a.album, artist: a.artist, genre: a.genre, hue: a.hue, cover: a.tracks[0][1],
    year: a.year, seed: 500 + ai * 131, trackIds: [],
  };
  a.tracks.forEach(([title, cover, tags], ti) => {
    const seed = 1000 + ai * 7919 + ti * 104729;
    const comp = compose(seed, a.genre);
    const id = `${a.id}t${ti + 1}`;
    COMPS.set(id, comp);
    const r = rng(seed + 7);
    const base = GENRES[a.genre].base;
    const j = (v: number) => clamp01(v + (r() - 0.5) * 0.14);
    TRACKS.push({
      id, title, artist: a.artist, album: a.album, albumId: a.id, genre: a.genre,
      bpm: comp.bpm, duration: comp.duration, seed, hue: (a.hue + ti * 16) % 360, cover,
      f: { energy: j(base.energy), bright: j(base.bright), dark: j(base.dark), tempo: clamp01((comp.bpm - 60) / 110), dense: j(base.dense), acoustic: j(base.acoustic) },
      tags, source: "synth",
    });
    al.trackIds.push(id);
  });
  ALBUMS.push(al);
});

export function getComp(t: Track): Comp {
  let c = COMPS.get(t.id);
  if (!c) {
    c = compose(t.seed, t.genre);
    COMPS.set(t.id, c);
  }
  // Draft structure (length, parts, stems) rebuilds the playable composition.
  if (t.studio && t.draft) return applyStudio(c, t.draft);
  if (t.studio && t.bpm > 0 && c.bpm !== t.bpm) {
    const sd = 60 / t.bpm / 4;
    return { ...c, bpm: t.bpm, sd, duration: c.totalSteps * sd + 1.2 };
  }
  return c;
}

export interface Mood {
  id: string;
  label: string;
  hue: number;
  shape: number;
  genres: Genre[];
  target: Partial<Features>;
}

export const MOODS: Mood[] = [
  { id: "neon", label: "Неоновая ночь", hue: 276, shape: 0, genres: ["synthwave", "phonk", "trap"], target: { energy: 0.65, dark: 0.65 } },
  { id: "gas", label: "Педаль в пол", hue: 214, shape: 1, genres: ["phonk", "rock", "techno"], target: { energy: 0.9, dense: 0.8 } },
  { id: "calm", label: "Тише воды", hue: 156, shape: 2, genres: ["ambient", "lofi"], target: { energy: 0.12, dense: 0.2 } },
  { id: "rain", label: "Дождь по стеклу", hue: 190, shape: 3, genres: ["lofi", "trap", "ambient"], target: { energy: 0.3, dark: 0.55 } },
  { id: "sugar", label: "Сахарный шторм", hue: 318, shape: 4, genres: ["hyperpop", "synthwave"], target: { energy: 0.95, bright: 0.9 } },
  { id: "focus", label: "Голова в порядке", hue: 92, shape: 5, genres: ["techno", "lofi", "ambient"], target: { energy: 0.45, acoustic: 0.3 } },
];

/** polar-harmonic glyph shapes (k, amplitude, phase) */
export const GLYPHS: [number, number, number][][] = [
  [[2, 0.22, 0.3], [3, 0.16, 1.2], [5, 0.07, 2.1]],
  [[1, 0.18, 2.5], [3, 0.2, 0.4], [4, 0.08, 1.7]],
  [[2, 0.3, 1.1], [5, 0.09, 0.2], [7, 0.04, 3]],
  [[3, 0.26, 2.2], [6, 0.06, 0.9]],
  [[4, 0.16, 0.5], [2, 0.14, 2.6], [9, 0.03, 1]],
  [[5, 0.17, 1.4], [1, 0.15, 0.3], [3, 0.08, 2]],
  [[2, 0.18, 2], [3, 0.22, 0.7], [8, 0.04, 1.3]],
  [[1, 0.22, 1.6], [4, 0.14, 2.9], [6, 0.05, 0.4]],
];

export const fmtTime = (s: number) => {
  if (!isFinite(s) || s < 0) s = 0;
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${m}:${ss.toString().padStart(2, "0")}`;
};
