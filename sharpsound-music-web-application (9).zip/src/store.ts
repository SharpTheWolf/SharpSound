import { create } from "zustand";
import { persist } from "zustand/middleware";
import { engine } from "./audio/engine";
import { MOODS, TRACKS, getComp, type Track } from "./data/catalog";
import { audioUrl } from "./lib/db";
import { computeTaste, rankForResonance, type Stat } from "./lib/reco";
import { translate } from "./lib/i18n";

export type Tab = "search" | "home" | "recognize" | "collection" | "contribute" | "community" | "studio";
export type Mode = "list" | "resonance";
export type ChibiKind = "like" | "play" | "say" | "found" | "upload" | "censor" | "dislike" | "summon" | "post" | "reply" | "format" | "language" | "theme";
export interface ChibiEvt {
  kind: ChibiKind;
  text?: string;
  ts: number;
}

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
  hue: number;
  shape: number;
}

interface State {
  theme: "dark" | "light";
  tab: Tab;
  uploads: Track[];
  studioTracks: Track[];
  studioPreviews: Track[];
  currentId: string | null;
  isPlaying: boolean;
  mode: Mode;
  mood: string | null;
  queue: string[];
  qi: number;
  liked: Record<string, number>;
  disliked: Record<string, number>;
  stats: Record<string, Stat>;
  hours: number[];
  volume: number;
  hideTaste: boolean;
  chibiAway: boolean;
  chibiEvt: ChibiEvt | null;
  chibiOutfit: string;
  playlists: Playlist[];
  toastMsg: { text: string; ts: number } | null;

  setTheme: (t: "dark" | "light") => void;
  setChibiOutfit: (id: string) => void;
  createPlaylist: (name: string) => string | null;
  deletePlaylist: (id: string) => void;
  addToPlaylist: (pid: string, trackId: string) => void;
  removeFromPlaylist: (pid: string, trackId: string) => void;
  setTab: (t: Tab) => void;
  setUploads: (u: Track[]) => void;
  addStudioTrack: (track: Track) => void;
  deleteStudioTrack: (id: string) => void;
  setStudioPreview: (track: Track) => void;
  playTrack: (id: string, queue?: string[]) => void;
  togglePlay: () => void;
  next: () => void;
  prev: () => void;
  seek: (s: number) => void;
  setVolume: (v: number) => void;
  startResonance: (mood?: string | null, seedId?: string) => void;
  retune: () => Track | null;
  toggleLike: (id: string) => void;
  dislike: (id: string) => void;
  tick: (sec: number) => void;
  setHideTaste: (b: boolean) => void;
  setChibiAway: (b: boolean) => void;
  chibi: (kind: ChibiKind, text?: string) => void;
  toast: (text: string) => void;
}

export const allTracks = (): Track[] => [...TRACKS, ...useStore.getState().uploads, ...useStore.getState().studioTracks];
export const findTrack = (id: string | null | undefined): Track | null =>
  id ? [...allTracks(), ...useStore.getState().studioPreviews].find((t) => t.id === id) ?? null : null;

export const useStore = create<State>()(
  persist(
    (set, get) => {
      const playAt = async (q: string[], i: number, mode: Mode) => {
        const id = q[i];
        const t = findTrack(id);
        if (!t) return;
        engine.unlock();
        const st = get();
        const s = st.stats[id] ?? { plays: 0, secs: 0, last: 0 };
        set({
          queue: q, qi: i, mode, currentId: id, isPlaying: true,
          stats: { ...st.stats, [id]: { ...s, plays: s.plays + 1, last: Date.now() } },
        });
        if (t.source === "synth") engine.playSynth(getComp(t));
        else {
          const url = await audioUrl(t.id);
          if (get().currentId !== id) return;
          if (!url) {
            get().toast(translate("Файл трека не найден на устройстве"));
            set({ isPlaying: false });
            return;
          }
          engine.playFile(url, t.bpm);
        }
        get().chibi("play");
      };

      const extend = (st: State, seedId: string | null, count = 6): string[] => {
        const all = allTracks();
        const taste = computeTaste(all, st.stats, st.liked);
        const recent = new Set(st.queue.slice(Math.max(0, st.qi - 10), st.qi + 1));
        if (seedId) recent.add(seedId);
        const ranked = rankForResonance(all, {
          seed: findTrack(seedId), mood: MOODS.find((m) => m.id === st.mood) ?? null, taste,
          disliked: st.disliked, liked: st.liked, exclude: recent,
        });
        let ids = ranked.slice(0, count).map((t) => t.id);
        if (!ids.length)
          ids = all
            .filter((t) => !st.disliked[t.id])
            .map((t) => t.id)
            .sort(() => Math.random() - 0.5)
            .slice(0, count);
        return ids;
      };

      return {
        theme: "dark", tab: "home", uploads: [], studioTracks: [], studioPreviews: [], currentId: null, isPlaying: false, mode: "list", mood: null,
        queue: [], qi: 0, liked: {}, disliked: {}, stats: {}, hours: Array(24).fill(0), volume: 0.85,
        hideTaste: false, chibiAway: false, chibiEvt: null, chibiOutfit: "classic", playlists: [], toastMsg: null,

        setTheme: (theme) => {
          document.documentElement.setAttribute("data-theme", theme);
          set({ theme });
        },
        setChibiOutfit: (chibiOutfit) => set({ chibiOutfit }),
        createPlaylist: (name) => {
          const n = name.trim();
          if (!n || n.length > 60) return null;
          const id = "pl" + Date.now().toString(36);
          const list = [...get().playlists, { id, name: n, trackIds: [], createdAt: Date.now(), hue: 270 + (Math.random() * 120) % 360, shape: Math.floor(Math.random() * 8) }];
          set({ playlists: list });
          return id;
        },
        deletePlaylist: (id) => set({ playlists: get().playlists.filter((p) => p.id !== id) }),
        addToPlaylist: (pid, trackId) =>
          set({
            playlists: get().playlists.map((p) => (p.id === pid && !p.trackIds.includes(trackId) ? { ...p, trackIds: [...p.trackIds, trackId] } : p)),
          }),
        removeFromPlaylist: (pid, trackId) =>
          set({
            playlists: get().playlists.map((p) => (p.id === pid ? { ...p, trackIds: p.trackIds.filter((x) => x !== trackId) } : p)),
          }),
        setTab: (tab) => set({ tab }),
        setUploads: (uploads) => set({ uploads }),
        addStudioTrack: (track) => set({ studioTracks: [...get().studioTracks.filter((t) => t.id !== track.id), track] }),
        setStudioPreview: (track) => set({ studioPreviews: [...get().studioPreviews.filter((t) => t.id !== track.id), track].slice(-8) }),
        deleteStudioTrack: (id) => {
          const state = get();
          set({ studioTracks: state.studioTracks.filter((t) => t.id !== id) });
          if (state.currentId === id) {
            engine.stop();
            set({ isPlaying: false, currentId: null, queue: [], qi: 0 });
          }
        },

        playTrack: (id, queue) => {
          const st = get();
          if (queue && queue.length) {
            void playAt(queue, Math.max(0, queue.indexOf(id)), "list");
            return;
          }
          const i = st.queue.indexOf(id);
          if (i >= 0) void playAt(st.queue, i, st.mode);
          else void playAt([id], 0, "list");
        },

        togglePlay: () => {
          const st = get();
          if (!st.currentId) {
            get().startResonance(null);
            return;
          }
          if (st.isPlaying) {
            engine.pause();
            set({ isPlaying: false });
          } else {
            engine.unlock();
            if (engine.hasTrack()) {
              engine.resume();
              set({ isPlaying: true });
            } else if (st.queue.length) void playAt(st.queue, st.qi, st.mode);
            else void playAt([st.currentId], 0, "list");
          }
        },

        next: () => {
          const st = get();
          if (st.mode === "resonance") {
            let q = st.queue;
            if (st.qi + 1 >= q.length - 1) q = [...q, ...extend(st, st.currentId)];
            if (q[st.qi + 1]) void playAt(q, st.qi + 1, "resonance");
          } else if (st.qi + 1 < st.queue.length) void playAt(st.queue, st.qi + 1, "list");
          else get().startResonance(null, st.currentId ?? undefined);
        },

        prev: () => {
          const st = get();
          if (engine.time() > 3 || st.qi === 0) {
            engine.seek(0);
            return;
          }
          void playAt(st.queue, st.qi - 1, st.mode);
        },

        seek: (s) => engine.seek(s),

        setVolume: (v) => {
          engine.setVolume(v);
          set({ volume: v });
        },

        startResonance: (moodId = null, seedId) => {
          const st = get();
          const base: State = { ...st, mood: moodId, queue: [], qi: 0 };
          const ids = extend(base, seedId ?? null, 10);
          set({ mood: moodId });
          void playAt(ids, 0, "resonance");
        },

        retune: () => {
          const st = get();
          if (st.mode !== "resonance" || !st.currentId) return null;
          const ids = extend(st, st.currentId, 6);
          set({ queue: [...st.queue.slice(0, st.qi + 1), ...ids] });
          return findTrack(ids[0]);
        },

        toggleLike: (id) => {
          const st = get();
          const liked = { ...st.liked };
          const disliked = { ...st.disliked };
          if (liked[id]) delete liked[id];
          else {
            liked[id] = Date.now();
            delete disliked[id];
            get().chibi("like");
          }
          set({ liked, disliked });
        },

        dislike: (id) => {
          const st = get();
          const liked = { ...st.liked };
          delete liked[id];
          set({ disliked: { ...st.disliked, [id]: Date.now() }, liked });
          get().chibi("dislike");
          if (st.currentId === id) get().next();
        },

        tick: (sec) => {
          const st = get();
          const id = st.currentId;
          if (!id || !st.isPlaying) return;
          const s = st.stats[id] ?? { plays: 1, secs: 0, last: Date.now() };
          const hours = st.hours.slice();
          hours[new Date().getHours()] += sec;
          set({ stats: { ...st.stats, [id]: { ...s, secs: s.secs + sec } }, hours });
        },

        setHideTaste: (hideTaste) => set({ hideTaste }),
        setChibiAway: (chibiAway) => {
          set({ chibiAway });
          if (!chibiAway) get().chibi("summon");
        },
        chibi: (kind, text) => set({ chibiEvt: { kind, text, ts: Date.now() + Math.random() } }),
        toast: (text) => set({ toastMsg: { text, ts: Date.now() } }),
      };
    },
    {
      name: "sharpsound",
      partialize: (s) => ({
        theme: s.theme, liked: s.liked, disliked: s.disliked, stats: s.stats, hours: s.hours,
        volume: s.volume, hideTaste: s.hideTaste, chibiOutfit: s.chibiOutfit, playlists: s.playlists, studioTracks: s.studioTracks,
      }),
    }
  )
);

engine.onEnded = () => useStore.getState().next();
