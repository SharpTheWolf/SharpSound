import { motion } from "framer-motion";
import { X } from "lucide-react";
import { useEffect, useId, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useI18n } from "../lib/i18n";
import { cn } from "../utils/cn";

let opened = 0;
let oldOverflow = "";

export function Modal({ title, children, onClose, className }: { title: string; children: ReactNode; onClose: () => void; className?: string }) {
  const { t } = useI18n();
  const ref = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    if (!opened) { oldOverflow = document.body.style.overflow; document.body.style.overflow = "hidden"; }
    opened++;
    const timer = setTimeout(() => (ref.current?.querySelector<HTMLElement>("[data-autofocus], input, textarea, button") ?? ref.current)?.focus(), 80);
    const onKey = (e: KeyboardEvent) => {
      if (!ref.current?.contains(document.activeElement)) return;
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); closeRef.current(); }
      if (e.key !== "Tab") return;
      const items = [...(ref.current?.querySelectorAll<HTMLElement>("button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), select:not(:disabled), [tabindex='0']") ?? [])].filter((el) => el.getClientRects().length > 0);
      const first = items[0];
      const last = items[items.length - 1];
      if (!first) { e.preventDefault(); return; }
      if (e.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { e.preventDefault(); last.focus(); }
      if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("keydown", onKey);
      if (--opened === 0) document.body.style.overflow = oldOverflow;
      previous?.focus();
    };
  }, []);
  return createPortal(
    <motion.div className="fixed inset-0 z-[90] flex items-center justify-center bg-[#07060b]/75 p-3 backdrop-blur-xl sm:p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <motion.div ref={ref} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} initial={{ opacity: 0, y: 35, rotateX: -8, scale: 0.96 }} animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.97 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }} className={cn("glass-strong shadow-deep relative flex max-h-[88dvh] w-full max-w-[960px] flex-col overflow-hidden rounded-[32px] outline-none sm:rounded-[40px]", className)}>
        <div className="flex shrink-0 items-center justify-between gap-4 border-b border-line px-5 py-5 sm:px-8">
          <h2 id={titleId} className="font-display text-lg font-bold sm:text-xl">{title}</h2>
          <button type="button" onClick={onClose} aria-label={t("Закрыть")} className="btn-soft grid h-9 w-9 shrink-0 place-items-center rounded-full"><X className="h-4 w-4" /></button>
        </div>
        <div className="min-h-0 overflow-y-auto p-5 sm:p-8">{children}</div>
      </motion.div>
    </motion.div>, document.body
  );
}