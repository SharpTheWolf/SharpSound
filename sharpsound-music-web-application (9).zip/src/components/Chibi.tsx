import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { engine } from "../audio/engine";
import { GENRES } from "../data/catalog";
import { findTrack, useStore } from "../store";
import { companionLine, genreLine } from "../data/companionLines";
import { localText, translate, useI18n } from "../lib/i18n";
import { cn } from "../utils/cn";

/* ------------------------------------------------------------------ */
/* Pixel art                                                           */
/* ------------------------------------------------------------------ */

export const BASE_PAL: Record<string, string> = {
  k: "#1b1030", h: "#f4f0ff", H: "#c3b5f0", s: "#ffdcc7", e: "#2a1650", w: "#ffffff",
  p: "#7c3aed", P: "#5b21b6", g: "#b4f03c", G: "#6aa312", W: "#f8f8ff", r: "#ff8fb8", m: "#9b3b5a", n: "#ede9fe",
  o: "#fb923c", O: "#c2410c", b: "#38bdf8", B: "#0369a1", y: "#fde047", Y: "#ca8a04",
  a: "#f472b6", A: "#be185d", t: "#2dd4bf", T: "#0f766e", d: "#94a3b8", D: "#475569",
};

export type OutfitId = "classic" | "neon" | "deep" | "lime" | "glow" | "gamer";

export interface Outfit {
  id: OutfitId;
  name: { ru: string; en: string };
  pal: Record<string, string>;
  body: string[];
}

const rep = (c: string, n: number) => c.repeat(n);
const HEAD: string[] = [
  rep(".", 5) + rep("k", 6) + rep(".", 5),
  rep(".", 3) + "kk" + rep("h", 6) + "kk" + rep(".", 3),
  "..k" + rep("h", 10) + "k..",
  ".k" + rep("h", 12) + "k.",
  ".k" + "hHhhhhhhhhHh" + "k.",
  ".k" + "hhHhhHhhHhhh" + "k.",
  ".k" + "hH" + rep("s", 8) + "Hh" + "k.",
  ".k" + "h" + rep("s", 10) + "h" + "k.",
  ".k" + "ss" + "we" + "ssss" + "we" + "ss" + "k.",
  ".k" + "ss" + "ee" + "ssss" + "ee" + "ss" + "k.",
  ".k" + "ss" + "sss" + "mm" + "sss" + "ss" + "k.",
  "..k" + rep("s", 10) + "k..",
];

function outfitBody(c1: string, c2: string, c3: string, accent: string, shoe: string): string[] {
  return [
    `...k${c1}${c1}${c1}${accent}${accent}${c1}${c1}${c1}k...`,
    `.k${c1}${c1}${c1}${c1}${accent}${accent}${c1}${c1}${c1}${c1}pk.`,
    `.k${c1}${c2}${c2}${c2}${accent}${accent}${c2}${c2}${c2}${c1}pk.`,
    `.ks${c3}${c3}${c3}${c3}${accent}${accent}${c3}${c3}${c3}${c3}sk.`,
    `..k${c2}${c2}${c2}${c2}${c2}${c2}${c2}${c2}${c2}${c2}k..`,
    `...k${c3}${c3}${c3}${c3}${c3}${c3}${c3}${c3}k...`,
    `...k${c3}${c3}${c3}kk${c3}${c3}${c3}k...`,
    `..k${shoe}${shoe}${shoe}k..k${shoe}${shoe}${shoe}k..`,
    `..${rep("k", 5)}..${rep("k", 5)}..`,
  ];
}

export const OUTFITS: Outfit[] = [
  {
    id: "classic",
    name: { ru: "Классика", en: "Classic" },
    pal: { ...BASE_PAL },
    body: [
      "...k" + "ppp" + "nn" + "ppp" + "k...",
      ".kp" + "pppp" + "nn" + "pppp" + "pk.",
      ".kp" + "gggg" + "nn" + "gggg" + "pk.",
      ".ks" + "PPPP" + "nn" + "PPPP" + "sk.",
      "..k" + rep("g", 10) + "k..",
      "...k" + rep("W", 8) + "k...",
      "...k" + "WWW" + "kk" + "WWW" + "k...",
      "..k" + "ggg" + "k..k" + "ggg" + "k..",
      ".." + rep("k", 5) + ".." + rep("k", 5) + "..",
    ],
  },
  {
    id: "neon",
    name: { ru: "Неон", en: "Neon" },
    pal: { ...BASE_PAL, p: "#a78bfa", P: "#6d28d9", g: "#bef264", G: "#65a30d", W: "#e0e7ff", n: "#c4b5fd" },
    body: outfitBody("p", "g", "W", "n", "g"),
  },
  {
    id: "deep",
    name: { ru: "Тёмный", en: "Deep" },
    pal: { ...BASE_PAL, p: "#4c1d95", P: "#3b0f80", g: "#c4b5fd", G: "#7c3aed", W: "#ede9fe", n: "#b4f03c" },
    body: outfitBody("p", "g", "W", "n", "G"),
  },
  {
    id: "lime",
    name: { ru: "Лайм", en: "Lime" },
    pal: { ...BASE_PAL, p: "#a3e635", P: "#65a30d", g: "#7c3aed", G: "#4c1d95", W: "#f7fee7", n: "#e9d5ff" },
    body: outfitBody("p", "g", "W", "n", "G"),
  },
  {
    id: "glow",
    name: { ru: "Свечение", en: "Glow" },
    pal: { ...BASE_PAL, p: "#8b5cf6", P: "#5b21b6", g: "#c6f432", G: "#84cc16", W: "#ffffff", n: "#d8b4fe" },
    body: outfitBody("p", "W", "g", "n", "G"),
  },
  {
    id: "gamer",
    name: { ru: "Геймер", en: "Gamer" },
    pal: { ...BASE_PAL, p: "#a78bfa", P: "#4c1d95", g: "#b4f03c", G: "#65a30d", W: "#e9d5ff", n: "#c4b5fd" },
    body: [
      "...kkkkkkkkkk...",
      "..kppppggppppk..",
      ".kpppppggpppppk.",
      ".kgppppppppppgk.",
      ".kPPPPkkPPPPPPk.",
      "..kPWWWWWWWWPPk.",
      "..kWgggggggggWk.",
      "...kWWWWWWWWk...",
      "....kGGkkGGk....",
    ],
  },
];

export const PAL = OUTFITS[0].pal;

type Patch = [number, number, string][];
export type Eyes = "open" | "blink" | "happy" | "left" | "right" | "closed" | "wide" | "wink" | "hearts" | "sad" | "angry";
export type Mouth = "smile" | "open" | "flat" | "frown" | "smirk";
export type Arms = "down" | "up" | "wave" | "hold" | "guitar" | "clap" | "stretch" | "crossed" | "point" | "game";
export type Legs = "stand" | "a" | "b";

const EYES: Record<Eyes, Patch> = {
  open: [],
  blink: [[4, 8, "ss"], [10, 8, "ss"], [4, 9, "kk"], [10, 9, "kk"]],
  closed: [[4, 8, "ss"], [10, 8, "ss"], [4, 9, "kk"], [10, 9, "kk"]],
  happy: [[4, 8, "kk"], [10, 8, "kk"], [3, 9, "kssk"], [9, 9, "kssk"]],
  left: [[3, 8, "wes"], [9, 8, "wes"], [3, 9, "ees"], [9, 9, "ees"]],
  right: [[4, 8, "swe"], [10, 8, "swe"], [4, 9, "see"], [10, 9, "see"]],
  wide: [[4, 7, "ee"], [10, 7, "ee"]],
  wink: [[10, 8, "ss"], [10, 9, "kk"]],
  hearts: [[4, 8, "rr"], [10, 8, "rr"], [4, 9, "rs"], [10, 9, "rs"]],
  sad: [[4, 9, "ee"], [10, 9, "ee"], [3, 8, "ss"], [11, 8, "ss"]],
  angry: [[3, 7, "kk"], [11, 7, "kk"], [4, 8, "ee"], [10, 8, "ee"]],
};
const MOUTH: Record<Mouth, Patch> = {
  smile: [],
  open: [[7, 10, "mm"], [7, 11, "mm"]],
  flat: [[7, 10, "kk"]],
  frown: [[6, 11, "kkk"]],
  smirk: [[8, 10, "kk"]],
};
const ARMS: Record<Arms, Patch> = {
  down: [],
  up: [[0, 10, "s"], [15, 10, "s"], [0, 11, "p"], [15, 11, "p"], [1, 12, "pp"], [13, 12, "pp"], [2, 15, "P"], [13, 15, "P"]],
  wave: [[15, 10, "s"], [15, 11, "p"], [13, 12, "pp"], [13, 15, "P"]],
  hold: [[3, 14, "s"], [12, 14, "s"], [4, 15, "ss"], [10, 15, "ss"]],
  guitar: [[4, 13, "ss"], [10, 14, "ss"], [3, 15, "P"], [12, 15, "P"]],
  clap: [[4, 13, "ss"], [10, 13, "ss"], [6, 14, "ssss"]],
  stretch: [[0, 9, "s"], [15, 9, "s"], [0, 10, "p"], [15, 10, "p"], [1, 11, "pp"], [13, 11, "pp"], [2, 15, "P"], [13, 15, "P"]],
  crossed: [[4, 13, "ssssssss"], [5, 14, "ssssss"]],
  point: [[15, 11, "s"], [14, 12, "p"], [13, 13, "pp"], [12, 14, "P"]],
  game: [[3, 12, "pp"], [11, 12, "pp"], [4, 13, "pp"], [10, 13, "pp"], [5, 14, "pppppp"], [5, 15, "gggggg"]],
};
const LEGS: Record<Legs, Patch> = {
  stand: [],
  a: [[0, 18, "..kWWWk..kWWWk.."], [0, 19, ".kgggk....kgggk."], [0, 20, ".kkkkk....kkkkk."]],
  b: [[0, 18, "....kWWWWWWk...."], [0, 19, "...kgggkgggk...."], [0, 20, "...kkkkkkkkk...."]],
};
const PHONES: Patch = [
  [5, 0, "gggggg"], [3, 1, "gg"], [11, 1, "gg"], [2, 2, "g"], [13, 2, "g"], [1, 3, "g"], [14, 3, "g"], [1, 4, "g"], [14, 4, "g"],
  [0, 5, "kg"], [14, 5, "gk"], [0, 6, "gG"], [14, 6, "Gg"], [0, 7, "gG"], [14, 7, "Gg"], [0, 8, "kk"], [14, 8, "kk"],
];
const BLUSH: Patch = [[2, 10, "rr"], [12, 10, "rr"]];

const cache = new Map<string, string[]>();
export function buildSprite(o: {
  eyes: Eyes;
  mouth: Mouth;
  arms: Arms;
  legs: Legs;
  phones: boolean;
  blush: boolean;
  outfit?: Outfit;
}) {
  const fit = o.outfit ?? OUTFITS[0];
  const key = `${fit.id}|${o.eyes}|${o.mouth}|${o.arms}|${o.legs}|${o.phones}|${o.blush}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const base = [...HEAD, ...fit.body];
  const g = base.map((r) => r.padEnd(16, ".").slice(0, 16).split(""));
  const apply = (p: Patch) =>
    p.forEach(([x, y, s]) => {
      for (let i = 0; i < s.length; i++) if (g[y] && x + i < 16) g[y][x + i] = s[i];
    });
  apply(EYES[o.eyes]);
  apply(MOUTH[o.mouth]);
  if (o.blush) apply(BLUSH);
  apply(ARMS[o.arms]);
  apply(LEGS[o.legs]);
  // the gamer skin draws its own pixel RGB headphones on top
  if (o.phones && fit.id !== "gamer") apply(PHONES);
  const rows = g.map((r) => r.join(""));
  cache.set(key, rows);
  return rows;
}

export function PixelGrid({
  rows,
  pal = PAL,
  scale = 4,
  className,
  style,
}: {
  rows: string[];
  pal?: Record<string, string>;
  scale?: number;
  className?: string;
  style?: CSSProperties;
}) {
  const w = rows[0]?.length ?? 0;
  const h = rows.length;
  const paths = useMemo(() => {
    const by: Record<string, string> = {};
    rows.forEach((r, y) => {
      for (let x = 0; x < r.length; x++) {
        const c = r[x];
        if (c === "." || !pal[c]) continue;
        by[c] = (by[c] || "") + `M${x} ${y}h1v1h-1z`;
      }
    });
    return by;
  }, [rows, pal]);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w * scale} height={h * scale} shapeRendering="crispEdges" className={className} style={style} aria-hidden>
      {Object.entries(paths).map(([c, d]) => (
        <path key={c} d={d} fill={pal[c]} />
      ))}
    </svg>
  );
}

/* Pixel-art gaming headphones: a crisp 16×9 mask cycled through RGB hues. */
const HP_MASK = [
  "...RRRRRRRRRR...",
  "..RR........RR..",
  ".RR..........RR.",
  ".R............R.",
  "BB............BB",
  "BL............LB",
  "BL............LB",
  "BB............BB",
  ".B............B.",
];

function hslHex(h: number, s: number, l: number) {
  const a = (s * Math.min(l, 1 - l)) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l / 100 - a * Math.max(-1, Math.min(Math.min(k - 3, 9 - k), 1));
    return Math.round(255 * c).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

export function GamerHeadphones({ w, h, className, style }: { w: number; h: number; className?: string; style?: CSSProperties }) {
  const [hue, setHue] = useState(0);
  const reduced = useMemo(() => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches, []);

  useEffect(() => {
    if (reduced) return;
    // stepped updates keep the LED look chunky instead of a smooth rainbow
    const iv = window.setInterval(() => setHue((v) => (v + 24) % 360), 130);
    return () => clearInterval(iv);
  }, [reduced]);

  const pal = useMemo(
    () => ({
      R: hslHex(hue, 92, 62),
      L: hslHex((hue + 40) % 360, 96, 72),
      B: "#1a0f33",
    }),
    [hue]
  );

  return (
    <span className={cn("pointer-events-none absolute left-0 top-0 block", className)} style={{ width: w, height: h, ...style }} aria-hidden>
      <PixelGrid rows={HP_MASK} pal={pal} scale={w / 16} />
    </span>
  );
}

export function ChibiHead({ scale = 2.5, away = false, outfit }: { scale?: number; away?: boolean; outfit?: Outfit }) {
  const rows = away
    ? buildSprite({ eyes: "closed", mouth: "flat", arms: "down", legs: "stand", phones: false, blush: false, outfit }).slice(0, 12)
    : buildSprite({ eyes: "open", mouth: "smile", arms: "down", legs: "stand", phones: true, blush: false, outfit }).slice(0, 12);
  return (
    <div className="relative shrink-0" style={{ width: 16 * scale, height: 12 * scale }}>
      <PixelGrid rows={rows} pal={outfit?.pal ?? PAL} scale={scale} className="absolute left-0 top-0" />
      {outfit?.id === "gamer" && <GamerHeadphones w={16 * scale} h={12 * scale} className="absolute left-0 top-0" />}
    </div>
  );
}

const HEART = [".rr.rr.", "rwrrrrr", "rrrrrrr", ".rrrrr.", "..rrr..", "...r..."];
const NOTE = ["..ggg", "..g.g", "..g..", "ggg..", "ggg.."];
const ZED = ["hhhh", "..h.", ".h..", "hhhh"];
const BANG = ["gg", "gg", "gg", "..", "gg"];
const STAR = ["..g..", ".ggg.", "ggwgg", ".ggg.", "..g.."];
const CHAT = ["hhhhhhh", "hwwwwwh", "hwgwgwh", "hwwwwwh", "hhhhhhh", ".hh...."];
const STORM = ["..d..", ".ddd.", "dDdDd", ".ddd.", "..d.."];
const CUP = [".wwwww..", ".wpppwkw", ".wpppw.w", ".wpppwkw", ".wwwww..", "..ggg..."];
const BOOK = [".kkkkkkkkkkk.", "kggggkppppppk", "kgwwgkpwwpppk", "kgwwgkpwwpppk", "kggggkppppppk", ".kkkkkkkkkkk."];
const GUITAR = [".............gGg", "............ggG.", ".........kkggG..", "...ppp..kwwk....", ".pprrppkwwk.....", "ppwwrrrwwk......", "ppwwrrwwk.......", ".ppppppk........", "..ppppk........."];
const PART_PAL: Record<string, string> = { r: "#ff5c9a", w: "#ffd0e2", g: "#b4f03c", h: "#c3b5f0", d: "#94a3b8", D: "#64748b" };

/* ------------------------------------------------------------------ */
/* Behaviour                                                           */
/* ------------------------------------------------------------------ */

type Act =
  | "idle" | "walk" | "look" | "listen" | "dance" | "love" | "sleep" | "think" | "jump" | "wave" | "talk"
  | "airguitar" | "headbang" | "spin" | "stretch" | "tea" | "read" | "clap" | "sulk" | "stomp" | "celebrate" | "point" | "game" | "chair";
const MUSIC_ACTS: Act[] = ["listen", "dance", "airguitar", "headbang", "spin"];
interface Part {
  id: number;
  kind: "heart" | "note" | "z" | "bang" | "star" | "chat" | "storm";
  dx: number;
  x: number;
  delay: number;
}

const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];
const energyWord = (e: number) => localText(e > 0.8 ? { ru: "Пол дрожит.", en: "The floor is shaking." } : e > 0.55 ? { ru: "Бодро.", en: "Upbeat." } : e > 0.3 ? { ru: "Ровный вайб.", en: "Steady vibe." } : { ru: "Тихо и мягко.", en: "Soft and quiet." });

function danceForGenre(): Act {
  const track = findTrack(useStore.getState().currentId);
  if (track?.genre === "rock") return "airguitar";
  if (track?.genre === "phonk") return "headbang";
  if (track?.genre === "hyperpop") return "spin";
  return "dance";
}

const bounds = () => {
  const w = window.innerWidth;
  return { min: w >= 1024 ? 300 : w >= 768 ? 132 : 12, max: w - (w < 640 ? 60 : 90) };
};

export default function Chibi() {
  const { t: tx, text } = useI18n();
  const away = useStore((s) => s.chibiAway);
  const evt = useStore((s) => s.chibiEvt);
  const isPlaying = useStore((s) => s.isPlaying);

  const [act, setActS] = useState<Act>("idle");
  const [x, setX] = useState(-120);
  const [dir, setDir] = useState(1);
  const [walkMs, setWalkMs] = useState(0);
  const [eyes, setEyes] = useState<Eyes>("open");
  const [frame, setFrame] = useState(0);
  const [bubble, setBubble] = useState<{ text: string; id: number } | null>(null);
  const [parts, setParts] = useState<Part[]>([]);
  const [small, setSmall] = useState(false);
  const [typed, setTyped] = useState(0);
  const [outfitFlash, setOutfitFlash] = useState(false);
  const outfitId = useStore((s) => s.chibiOutfit) as OutfitId;
  const setOutfitId = (id: string) => useStore.getState().setChibiOutfit(id);

  const actRef = useRef<Act>("idle");
  const actStarted = useRef(performance.now());
  const xRef = useRef(-120);
  const busyUntil = useRef(0);
  const lastInteract = useRef(Date.now());
  const arrived = useRef(Date.now());
  const lastAnalysis = useRef(0);
  const firstRef = useRef(true);
  const timers = useRef<number[]>([]);
  const bubbleTimer = useRef(0);
  const posRef = useRef<HTMLDivElement>(null);
  const bobRef = useRef<HTMLDivElement>(null);
  const jumpRef = useRef<HTMLDivElement>(null);
  const uid = useRef(1);
  const particleTimers = useRef<number[]>([]);
  const wasPlaying = useRef(false);
  const pendingOutfit = useRef<OutfitId | null>(null);
  const outfitRef = useRef(outfitId);
  outfitRef.current = outfitId;
  const outfit = OUTFITS.find((o) => o.id === outfitId) ?? OUTFITS[0];

  const setAct = (a: Act) => {
    if (actRef.current !== a) actStarted.current = performance.now();
    actRef.current = a;
    setActS(a);
  };
  const later = (ms: number, fn: () => void) => {
    timers.current.push(window.setTimeout(fn, ms));
  };
  const clearTimers = () => {
    timers.current.forEach((t) => clearTimeout(t));
    timers.current = [];
  };
  const busy = (ms: number) => {
    busyUntil.current = Math.max(busyUntil.current, Date.now() + ms);
  };
  const restAct = (): Act => (useStore.getState().isPlaying ? "listen" : "idle");

  const say = (text: string, ms?: number) => {
    clearTimeout(bubbleTimer.current);
    setBubble({ text, id: uid.current++ });
    bubbleTimer.current = window.setTimeout(() => setBubble(null), ms ?? Math.min(6500, 1800 + text.length * 55));
  };

  useEffect(() => {
    setTyped(0);
    if (!bubble) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setTyped(bubble.text.length); return; }
    let n = 0;
    const iv = window.setInterval(() => { n += 2; setTyped(Math.min(n, bubble.text.length)); if (n >= bubble.text.length) clearInterval(iv); }, 28);
    return () => clearInterval(iv);
  }, [bubble?.id]);

  const spawn = (kind: Part["kind"], count: number, spread = 26) => {
    const items: Part[] = Array.from({ length: count }, (_, i) => ({
      id: uid.current++, kind, dx: (Math.random() - 0.5) * spread * 2, x: (Math.random() - 0.5) * 28, delay: i * 170,
    }));
    setParts((p) => [...p.slice(-14), ...items]);
    particleTimers.current.push(window.setTimeout(() => setParts((p) => p.filter((q) => !items.includes(q))), 2200 + count * 170));
  };

  const curX = () => {
    const el = posRef.current;
    return el ? el.getBoundingClientRect().left : xRef.current;
  };

  const freeze = () => {
    clearTimers();
    busyUntil.current = Date.now();
    const cx = curX();
    setWalkMs(0);
    setX(cx);
    xRef.current = cx;
  };

  const jump = () => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    jumpRef.current?.animate(
      [
        { transform: "translateY(0) scale(1,1)" },
        { transform: "translateY(2px) scale(1.08,0.9)", offset: 0.15 },
        { transform: "translateY(-30px) scale(0.94,1.08)", offset: 0.5 },
        { transform: "translateY(0) scale(1.06,0.94)", offset: 0.85 },
        { transform: "translateY(0) scale(1,1)" },
      ],
      { duration: 620, easing: "cubic-bezier(.3,.7,.4,1)" }
    );
  };

  const gesture = (a: Act, duration: number, words?: string) => {
    freeze();
    setAct(a);
    busy(duration);
    if (words) say(words);
    if (a === "spin" || a === "clap") jump();
    later(duration, () => setAct(restAct()));
  };

  const walkTo = (tx: number, then?: () => void, free = false) => {
    if (!free) {
      const b = bounds();
      tx = Math.max(b.min, Math.min(b.max, tx));
    }
    const from = curX();
    const dist = Math.abs(tx - from);
    if (dist < 6) {
      then?.();
      return;
    }
    const ms = (dist / 75) * 1000;
    setDir(tx > from ? 1 : -1);
    setWalkMs(ms);
    setX(tx);
    xRef.current = tx;
    setAct("walk");
    busy(ms + 200);
    later(ms, () => {
      if (actRef.current === "walk") setAct(restAct());
      then?.();
    });
  };

  const changeOutfit = () => {
    const others = OUTFITS.filter((o) => o.id !== outfitRef.current);
    return pick(others);
  };

  const leave = () => {
    const next = changeOutfit();
    pendingOutfit.current = next.id;
    say(companionLine("leave") + " " + localText({ ru: `(сменюсь в «${next.name.ru}»)`, en: `(I'll come back in the ${next.name.en} outfit)` }), 3400);
    busy(999999);
    later(1800, () => {
      const left = Math.random() < 0.55;
      walkTo(left ? -140 : window.innerWidth + 60, () => {
        setBubble(null);
        if (pendingOutfit.current) setOutfitId(pendingOutfit.current);
        useStore.getState().setChibiAway(true);
      }, true);
    });
  };

  const enter = (greet: string) => {
    clearTimers();
    setWalkMs(0);
    setX(-110);
    xRef.current = -110;
    setAct("idle");
    busyUntil.current = Date.now() + 5000;
    arrived.current = Date.now();
    const changed = !firstRef.current && !!pendingOutfit.current;
    pendingOutfit.current = null;
    later(80, () => {
      const b = bounds();
      walkTo(b.min + 40 + Math.random() * Math.min(260, b.max - b.min - 40), () => {
        firstRef.current = false;
        setAct(changed ? "celebrate" : "wave");
        setOutfitFlash(true);
        later(900, () => setOutfitFlash(false));
        say(changed ? companionLine("outfit") : greet, changed ? 3600 : 2800);
        jump();
        spawn(changed ? "star" : "bang", changed ? 6 : 1, 18);
        later(changed ? 2800 : 1600, () => setAct(restAct()));
      });
    });
  };

  // first appearance & summon
  useEffect(() => {
    if (away) {
      clearTimers();
      setBubble(null);
      return;
    }
    const first = firstRef.current;
    enter(first ? companionLine("hello") : companionLine("back"));
    return () => clearTimers();
  }, [away]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const onResize = () => setSmall(window.innerWidth < 640);
    onResize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      clearTimers();
      clearTimeout(bubbleTimer.current);
      particleTimers.current.forEach((timer) => clearTimeout(timer));
    };
  }, []);

  // store events
  useEffect(() => {
    if (!evt || useStore.getState().chibiAway) return;
    const st = useStore.getState();
    switch (evt.kind) {
      case "like":
        freeze();
        setAct("love");
        spawn("heart", 7);
        say(companionLine("like"), 2600);
        busy(2600);
        later(2600, () => setAct(restAct()));
        break;
      case "dislike": {
        freeze();
        const mood = Math.random() < 0.5 ? "sulk" : "stomp";
        setAct(mood);
        spawn("storm", 7, 26);
        spawn("bang", 2, 12);
        say(companionLine("dislike"), 3400);
        busy(4200);
        jump();
        later(900, () => setDir((d) => -d));
        later(2000, () => {
          setAct("point");
          setDir((d) => d);
          say(companionLine("sulk"), 2400);
          spawn("storm", 2, 14);
        });
        later(4200, () => setAct(restAct()));
        break;
      }
      case "play": {
        freeze();
        lastInteract.current = Date.now();
        if (actRef.current === "sleep") setAct("idle");
        setAct("jump");
        jump();
        spawn("bang", 1, 4);
        busy(3600);
        const now = Date.now();
        const verbose = now - lastAnalysis.current > 15000 || st.mode === "resonance";
        later(650, () => {
          if (!verbose) {
            setAct("listen");
            return;
          }
          setAct("think");
          say(localText({ ru: "Слушаю...", en: "Listening..." }), 1500);
          later(1600, () => {
            const s2 = useStore.getState();
            const t = findTrack(s2.currentId);
            if (!t) return;
            lastAnalysis.current = Date.now();
            const nx = s2.retune();
            const head = `${translate(GENRES[t.genre].label)}, ~${Math.round(t.bpm)} BPM. ${energyWord(t.f.energy)}`;
            say(nx ? localText({ ru: `${head} Следом поставлю «${nx.title}».`, en: `${head} Next up: '${nx.title}'.` }) : localText({ ru: `${head} Подберу похожее в Резонанс.`, en: `${head} I'll find more like this in Resonance.` }), 5200);
            setAct(s2.isPlaying ? (t.f.energy > 0.7 ? danceForGenre() : "listen") : "idle");
          });
        });
        break;
      }
      case "found":
      case "upload":
        freeze();
        setAct("love");
        spawn("heart", 5);
        jump();
        say(evt.text ?? companionLine("upload"), 3600);
        busy(3000);
        later(3000, () => setAct(restAct()));
        break;
      case "censor":
        freeze();
        setAct("talk");
        spawn("bang", 1, 4);
        jump();
        say(evt.text ?? companionLine("censor"), 3000);
        busy(2500);
        later(2500, () => setAct(restAct()));
        break;
      case "say":
        freeze();
        setAct("wave");
        jump();
        say(evt.text ?? companionLine("back"), 3200);
        busy(1800);
        later(1800, () => setAct(restAct()));
        break;
      case "summon":
        break;
      case "post":
        gesture("clap", 3200, evt.text ?? companionLine("post"));
        spawn("chat", 3, 18); spawn("star", 5);
        break;
      case "reply":
        gesture("wave", 2800, evt.text ?? companionLine("reply"));
        spawn("chat", 3, 18);
        break;
      case "format":
        gesture("read", 5000, companionLine("format"));
        spawn("star", 2, 10);
        break;
      case "language":
        gesture("spin", 2200, companionLine("language"));
        spawn("star", 5);
        break;
      case "theme":
        gesture("look", 2500, companionLine(st.theme === "dark" ? "dark" : "light"));
        spawn("star", 3);
        break;
    }
  }, [evt?.ts]); // eslint-disable-line react-hooks/exhaustive-deps

  // react to pause
  useEffect(() => {
    if (!isPlaying && wasPlaying.current && MUSIC_ACTS.includes(actRef.current)) gesture("stretch", 2400, companionLine("pause"));
    wasPlaying.current = isPlaying;
  }, [isPlaying]);

  // autonomous loop
  useEffect(() => {
    let to = 0;
    const loop = () => {
      const st = useStore.getState();
      const now = Date.now();
      if (!st.chibiAway && now >= busyUntil.current) {
        const r = Math.random();
        const b = bounds();
        const rx = () => b.min + Math.random() * (b.max - b.min);
        if (st.tab === "community" && r < 0.2) {
          gesture("read", 5000, Math.random() < 0.45 ? companionLine("forum") : undefined);
        } else if (st.isPlaying) {
          if (outfitRef.current === "gamer" && r < 0.14) gesture("game", 4200, companionLine("gamer"));
          else if (outfitRef.current === "gamer" && r < 0.22) gesture("chair", 3600);
          else if (r < 0.32) setAct(engine.bands().level > 0.4 ? danceForGenre() : "listen");
          else if (r < 0.5) gesture(danceForGenre(), 4500);
          else if (r < 0.58) gesture("celebrate", 3400);
          else if (r < 0.7) walkTo(rx());
          else if (r < 0.8 && findTrack(st.currentId)?.genre === "lofi") gesture("tea", 5000, companionLine("tea"));
          else if (r < 0.9) {
            setAct("look");
            busy(1800);
            later(1800, () => setAct(restAct()));
          } else {
            const track = findTrack(st.currentId);
            say(track && Math.random() < 0.6 ? genreLine(track.genre) : companionLine("listen"));
            busy(2500);
          }
        } else {
          const idleFor = now - lastInteract.current;
          if (actRef.current === "sleep") {
            if (r < 0.15) setAct("idle");
          } else if (idleFor > 70000 && r < 0.3) {
            setAct("sleep");
            busy(14000);
          } else if (outfitRef.current === "gamer" && r < 0.16) gesture("game", 4200, companionLine("gamer"));
          else if (outfitRef.current === "gamer" && r < 0.24) gesture("chair", 3600);
          else if (r < 0.1) gesture("tea", 5500, Math.random() < 0.5 ? companionLine("tea") : undefined);
          else if (r < 0.2) gesture("stretch", 3500, Math.random() < 0.5 ? companionLine("stretch") : undefined);
          else if (r < 0.28) gesture("celebrate", 3600, Math.random() < 0.4 ? companionLine("celebrate") : undefined);
          else if (r < 0.36) {
            setAct("look");
            busy(1800);
            later(1800, () => setAct("idle"));
          } else if (r < 0.56) walkTo(rx());
          else if (r < 0.64) {
            setAct("wave");
            busy(1400);
            later(1400, () => setAct("idle"));
          } else if (r < 0.7) {
            gesture("point", 3000, Math.random() < 0.4 ? companionLine("idle") : undefined);
          } else if (r < 0.78) {
            say(companionLine("idle"));
            busy(2500);
          } else if (r < 0.85 && now - arrived.current > 55000) leave();
          else setAct("idle");
        }
      }
      to = window.setTimeout(loop, 2400 + Math.random() * 2600);
    };
    to = window.setTimeout(loop, 4500);
    return () => clearTimeout(to);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // blinking
  useEffect(() => {
    let to = 0;
    const loop = () => {
      setEyes((e) => (e === "open" ? "blink" : e));
      window.setTimeout(() => setEyes((e) => (e === "blink" ? "open" : e)), 130);
      to = window.setTimeout(loop, 2200 + Math.random() * 3200);
    };
    to = window.setTimeout(loop, 2000);
    return () => clearTimeout(to);
  }, []);

  // look around sequence
  useEffect(() => {
    if (act !== "look") return;
    setEyes("left");
    const a = window.setTimeout(() => {
      setEyes("right");
      setDir((d) => -d);
    }, 650);
    const b = window.setTimeout(() => setEyes("open"), 1350);
    return () => {
      clearTimeout(a);
      clearTimeout(b);
      setEyes("open");
    };
  }, [act]);

  // frame toggling (walk / dance / talk / think)
  const animating =
    act === "walk" || MUSIC_ACTS.includes(act) || act === "wave" || act === "think" || act === "clap" ||
    act === "read" || act === "stomp" || act === "celebrate" || act === "sulk" || act === "game" || act === "chair" || !!bubble;
  useEffect(() => {
    if (!animating) return;
    const iv = window.setInterval(() => setFrame((f) => f ^ 1), act === "think" || act === "sulk" ? 420 : act === "game" ? 90 : 170);
    return () => clearInterval(iv);
  }, [animating, act]);

  // particles while listening / sleeping
  useEffect(() => {
    if (away || (!MUSIC_ACTS.includes(act) && act !== "sleep")) return;
    const iv = window.setInterval(() => spawn(act === "sleep" ? "z" : "note", 1, 18), act === "sleep" ? 1600 : 1300);
    return () => clearInterval(iv);
  }, [act, away]); // eslint-disable-line react-hooks/exhaustive-deps

  // beat bob
  useEffect(() => {
    if (away || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const loop = (now: number) => {
      const a = actRef.current;
      const el = bobRef.current;
      if (el) {
        let y = 0;
        let rot = 0;
        let sx = 1;
        let sy = 1;
        let yaw = 0;
        if (MUSIC_ACTS.includes(a)) {
          const ph = engine.beat();
          const k = Math.abs(Math.sin(ph * Math.PI));
          const lv = engine.bands().level;
          if (a === "listen") {
            y = -k * (2 + lv * 4);
            rot = Math.sin(ph * Math.PI * 2) * 3;
          } else if (a === "airguitar") {
            y = -k * 5;
            rot = -7 + Math.sin(ph * Math.PI * 4) * 6;
            sx = 1 + k * 0.025;
          } else if (a === "headbang") {
            y = -k * (4 + lv * 6);
            rot = Math.sin(ph * Math.PI * 2) * 13;
            sy = 1 - k * 0.08;
          } else if (a === "spin") {
            y = -Math.abs(Math.sin(now / 230)) * 13;
            yaw = ((now - actStarted.current) / 900) * 360;
            rot = Math.sin(now / 230) * 5;
          } else {
            y = -k * (6 + lv * 10);
            rot = Math.sin(ph * Math.PI * 2) * 8;
            sy = 1 - (1 - k) * 0.06;
            sx = 1 + (1 - k) * 0.04;
          }
        } else if (a === "walk") y = -Math.abs(Math.sin(now / 95)) * 3;
        else if (a === "sleep") sy = 1 + Math.sin(now / 700) * 0.03;
        else if (a === "stretch") { sy = 1.04 + Math.sin(now / 450) * 0.04; rot = Math.sin(now / 500) * 5; }
        else if (a === "tea") rot = -3 + Math.sin(now / 650) * 2;
        else if (a === "read") sy = 1 + Math.sin(now / 500) * 0.02;
        else if (a === "clap" || a === "celebrate") y = -Math.abs(Math.sin(now / 210)) * 4;
        else if (a === "sulk") { rot = -8 + Math.sin(now / 700) * 2; sy = 0.96; }
        else if (a === "stomp") { y = -Math.abs(Math.sin(now / 140)) * 5; rot = Math.sin(now / 140) * 6; }
        else if (a === "point") { rot = 4; sx = 1.02; }
        else if (a === "game") { y = -Math.abs(Math.sin(now / 110)) * 2; rot = Math.sin(now / 180) * 1.7; }
        else if (a === "chair") { rot = Math.sin(now / 230) * 5; sx = 1 + Math.sin(now / 250) * 0.025; }
        else sy = 1 + Math.sin(now / 900) * 0.015;
        el.style.transform = `translateY(${y.toFixed(2)}px) rotate(${rot.toFixed(2)}deg) rotateY(${yaw.toFixed(2)}deg) scale(${sx.toFixed(3)}, ${sy.toFixed(3)})`;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [away]);

  const onClick = () => {
    lastInteract.current = Date.now();
    freeze();
    if (actRef.current === "sleep") {
      setAct("jump");
      jump();
      spawn("bang", 1, 4);
      say(companionLine("wake"));
    } else {
      const action = pick<Act>(["jump", "clap", "spin", "wave", "stretch"]);
      setAct(action);
      jump();
      spawn(action === "clap" ? "star" : "bang", action === "clap" ? 4 : 1, 16);
      say(companionLine("click"));
    }
    busy(3000);
    later(2500, () => setAct(restAct()));
  };

  if (away) return null;

  const scale = small ? 3 : 4;
  const eyesF: Eyes =
    act === "sleep" ? "closed"
      : act === "love" || act === "celebrate" ? "hearts"
      : act === "jump" ? "wide"
      : act === "sulk" ? "sad"
      : act === "stomp" || act === "point" ? "angry"
      : act === "think" || act === "read" ? (frame ? "left" : "right")
      : act === "clap" || act === "wave" ? (frame ? "wink" : "open")
      : act === "tea" ? "happy"
      : eyes;
  const mouth: Mouth =
    act === "love" || act === "dance" || act === "celebrate" ? "open"
      : act === "sulk" || act === "stomp" ? "frown"
      : act === "point" ? "smirk"
      : act === "sleep" ? "flat"
      : bubble && frame ? "open"
      : "smile";
  const arms: Arms =
    act === "stretch" ? "stretch"
      : act === "read" || act === "tea" ? "hold"
      : act === "airguitar" ? "guitar"
      : act === "game" ? "game"
      : act === "sulk" ? "crossed"
      : act === "point" ? "point"
      : act === "clap" || act === "celebrate" ? (frame ? "clap" : "hold")
      : act === "dance" || act === "spin" || act === "stomp" ? (frame ? "up" : "down")
      : act === "wave" ? (frame ? "wave" : "down")
      : act === "love" || act === "jump" ? "up"
      : "down";
  const legs: Legs =
    act === "walk" || act === "stomp" ? (frame ? "a" : "b")
      : act === "dance" || act === "airguitar" || act === "celebrate" ? (frame ? "a" : "stand")
      : "stand";
  const rows = buildSprite({ eyes: eyesF, mouth, arms, legs, phones: isPlaying, blush: act === "love" || act === "celebrate", outfit });
  const nearRight = x > window.innerWidth - 260;

  return (
    <div
      ref={posRef}
      className="pointer-events-none fixed left-0 z-[45]"
      style={{
        bottom: "var(--chibi-floor)",
        transform: `translateX(${x}px)`,
        transition: `transform ${walkMs}ms linear`,
      }}
    >
      <div className="relative" style={{ width: 16 * scale, height: 21 * scale }}>
        {/* speech bubble */}
        {bubble && (
          <div
            key={bubble.id}
            className={`pixel-bubble wobble-in absolute bottom-full mb-5 w-max max-w-[230px] px-3 py-2 text-[13px] leading-snug ${nearRight ? "right-0" : "left-0"}`}
          >
            <span className="sr-only" role="status">{bubble.text}</span>
            <span className="grid" aria-hidden><span className="invisible col-start-1 row-start-1">{bubble.text}</span><span className="col-start-1 row-start-1">{bubble.text.slice(0, typed)}{typed < bubble.text.length && <span className="blink-dot ml-px inline-block h-3 w-px bg-current align-middle" />}</span></span>
            <span className={`absolute -bottom-[9px] h-[9px] w-[9px] bg-white ${nearRight ? "right-6" : "left-6"}`} style={{ boxShadow: "3px 0 0 #1b1030, -3px 0 0 #1b1030, 0 3px 0 #1b1030" }} />
          </div>
        )}
        {/* particles */}
        {parts.map((p) => (
          <div
            key={p.id}
            className="float-up absolute bottom-[78%] left-1/2 opacity-0"
            style={{ marginLeft: p.x, animationDelay: `${p.delay}ms`, ["--dx" as string]: `${p.dx}px` }}
          >
            <PixelGrid
              rows={p.kind === "heart" ? HEART : p.kind === "note" ? NOTE : p.kind === "z" ? ZED : p.kind === "star" ? STAR : p.kind === "chat" ? CHAT : p.kind === "storm" ? STORM : BANG}
              pal={PART_PAL}
              scale={p.kind === "heart" ? 3 : 2.5}
            />
          </div>
        ))}
        <div ref={jumpRef} className="absolute inset-0">
          <div ref={bobRef} className="absolute inset-0 origin-bottom">
            <button
              onClick={onClick}
              className="pointer-events-auto block cursor-pointer"
              aria-label={tx("Помощник")}
              title={text(outfit.name)}
              style={{
                transform: `scaleX(${dir})`,
                filter: outfitFlash
                  ? "drop-shadow(0 6px 0 rgba(27,16,48,0.25)) drop-shadow(0 0 12px rgba(180,240,60,0.8))"
                  : "drop-shadow(0 6px 0 rgba(27,16,48,0.25))",
                transition: "filter 0.4s ease",
              }}
            >
              <span className="relative block" style={{ width: 16 * scale, height: 21 * scale }}>
                <PixelGrid rows={rows} pal={outfit.pal} scale={scale} />
                {outfit.id === "gamer" && <GamerHeadphones w={16 * scale} h={12 * scale} className="absolute left-0 top-0" />}
              </span>
              {act === "tea" && <div className="absolute right-0 top-[56%] -rotate-6"><PixelGrid rows={CUP} pal={outfit.pal} scale={scale * 0.75} /></div>}
              {act === "read" && <div className="absolute left-1/2 top-[59%] -translate-x-1/2 -rotate-3"><PixelGrid rows={BOOK} pal={outfit.pal} scale={scale * 0.8} /></div>}
              {act === "airguitar" && <div className="absolute left-[-6%] top-[44%] rotate-[-8deg]"><PixelGrid rows={GUITAR} pal={outfit.pal} scale={scale * 1.05} /></div>}
              {act === "game" && <div className="absolute left-1/2 top-[84%] -translate-x-1/2"><PixelGrid rows={[".kkkkkkkkkk.", "kpppggggpppk", "kggggggggggk", ".kkkkkkkkkk."]} pal={outfit.pal} scale={scale * 0.84} /></div>}
            </button>
          </div>
        </div>
        {/* shadow */}
        <div className="absolute -bottom-1 left-1/2 h-2 w-12 -translate-x-1/2 rounded-full bg-black/30 blur-[2px]" />
      </div>
    </div>
  );
}
