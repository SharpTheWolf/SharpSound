import { useI18n } from "../../lib/i18n";
import { Modal } from "../Modal";
import { RichText } from "./RichText";

export function FormatHelp({ onClose }: { onClose: () => void }) {
  const { tr } = useI18n();
  const word = tr("Текст", "Text");
  const samples = [
    [tr("Заголовки", "Headings"), `[h1]${tr("Большой заголовок", "Main heading")}[/h1]\n[h2]${tr("Заголовок", "Heading")}[/h2]\n[h3]${tr("Подзаголовок", "Subheading")}[/h3]`],
    [tr("Полужирный", "Bold"), `[b]${word}[/b]`],
    [tr("Курсив", "Italic"), `[i]${word}[/i]`],
    [tr("Подчёркнутый", "Underline"), `[u]${word}[/u]`],
    [tr("Зачёркнутый", "Strikethrough"), `[strike]${word}[/strike]`],
    [tr("Спойлер, нажми на него", "Spoiler, click to reveal"), `[spoiler]${tr("Секретный трек", "Secret track")}[/spoiler]`],
    [tr("Без обработки тегов", "Literal tags"), `[noparse][b]${word}[/b][/noparse]`],
    [tr("Разделитель", "Divider"), "[hr][/hr]"],
    [tr("Ссылка", "Link"), `[url=https://example.com]${tr("Открыть ссылку", "Open link")}[/url]`],
    [tr("Маркированный список", "Bullet list"), `[list]\n[*]${tr("Первый трек", "First track")}\n[*]${tr("Второй трек", "Second track")}\n[/list]`],
    [tr("Нумерованный список", "Numbered list"), `[olist]\n[*]${tr("Послушать", "Listen")}\n[*]${tr("Обсудить", "Discuss")}\n[/olist]`],
    [tr("Цитата с автором", "Quote with author"), `[quote=SharpSound]${tr("Сначала звук. Потом разговор.", "Sound first. Conversation second.")}[/quote]`],
    [tr("Код, пробелы сохраняются", "Code, whitespace preserved"), "[code]\nkick:  55 Hz\n808:   45 Hz\n[/code]"],
    [tr("Таблица", "Table"), `[table equalcells=1]\n[tr][th]${tr("Жанр", "Genre")}[/th][th]BPM[/th][/tr]\n[tr][td]Phonk[/td][td]140[/td][/tr]\n[tr][td]Lo-fi[/td][td]80[/td][/tr]\n[/table]`],
    [tr("Трек из библиотеки", "Library track"), "[track=a5t1]"],
    [tr("Видео, загрузка по нажатию", "Video, click to load"), "https://www.youtube.com/watch?v=jfKfPfyJRdk"],
  ];
  return <Modal title={tr("Форматирование текста", "Text formatting")} onClose={onClose}>
    <p className="mb-6 text-sm leading-relaxed text-ink2">{tr("Теги работают в темах и ответах. Выдели текст и нажми кнопку в редакторе, или впиши разметку вручную. HTML не выполняется.", "Tags work in topics and replies. Select text and use the toolbar, or type the markup yourself. HTML is never executed.")}</p>
    <div className="mb-2 hidden grid-cols-2 gap-5 px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-ink3 sm:grid"><span>{tr("Синтаксис", "Syntax")}</span><span>{tr("Пример", "Preview")}</span></div>
    {samples.map(([label, value]) => <section key={label} className="grid gap-4 border-t border-line py-5 sm:grid-cols-2">
      <div><div className="mb-2 text-xs font-bold text-ink2">{label}</div><pre className="whitespace-pre-wrap break-all rounded-[18px] bg-ink/5 p-3 font-mono text-[11px] leading-relaxed text-ink3">{value}</pre></div>
      <div className="min-w-0 self-center px-1"><RichText value={value} /></div>
    </section>)}
    <div className="mt-3 rounded-[22px] bg-vio/10 p-4 text-xs leading-relaxed text-ink2">
      <p><code>[list=1]</code> {tr("тоже создаёт нумерованный список.", "also makes a numbered list.")}</p>
      <p className="mt-2"><code>[table noborder=1]</code> {tr("убирает границы,", "removes borders,")} <code>[table equalcells=1]</code> {tr("делает колонки одинаковыми. Можно сочетать оба параметра.", "makes columns equal. Both options can be combined.")}</p>
      <p className="mt-2">{tr("Ссылки YouTube превращаются в виджет. Внешний плеер загружается только после нажатия и требует интернета.", "YouTube links become widgets. The external player only loads after a click and needs an internet connection.")}</p>
    </div>
    <button onClick={onClose} className="btn-grad ml-auto mt-6 block rounded-full px-6 py-3 text-sm font-bold">{tr("Понятно", "Got it")}</button>
  </Modal>;
}