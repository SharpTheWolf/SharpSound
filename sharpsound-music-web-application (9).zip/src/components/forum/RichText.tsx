import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink, Music, Pause, Play } from "lucide-react";
import { Fragment, useMemo, useState, type ReactNode } from "react";
import { parseBBCode, nodeText, safeImage, safeUrl, youtubeId, type BBNode } from "../../lib/bbcode";
import { useI18n } from "../../lib/i18n";
import { findTrack, useStore } from "../../store";
import { cn } from "../../utils/cn";
import { Cover } from "../Cover";

function Spoiler({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const { tr } = useI18n();
  return <button type="button" className={cn("rich-spoiler", open && "revealed")} aria-expanded={open} aria-label={tr(open ? "Скрыть спойлер" : "Показать спойлер", open ? "Hide spoiler" : "Reveal spoiler")} onClick={() => setOpen((v) => !v)}>
    <span aria-hidden={!open}>{children}</span>
  </button>;
}

export function TrackEmbed({ id }: { id: string }) {
  useStore((s) => s.uploads);
  useStore((s) => s.studioTracks);
  const currentId = useStore((s) => s.currentId);
  const playing = useStore((s) => s.isPlaying);
  const { tr } = useI18n();
  const track = findTrack(id);
  if (!track) return <span className="text-sm text-ink3">{tr("Трек больше не доступен", "Track no longer available")}</span>;
  const active = currentId === id && playing;
  return <motion.button type="button" whileHover={{ y: -3 }} whileTap={{ scale: 0.98 }} onClick={() => currentId === id ? useStore.getState().togglePlay() : useStore.getState().playTrack(id)} className="forum-track-embed my-3 flex w-full max-w-lg items-center gap-3 rounded-[23px] p-3 text-left">
    <div className="h-14 w-14 shrink-0 -rotate-6 overflow-hidden rounded-[18px] shadow-lg"><Cover t={track} spin={active} /></div>
    <span className="min-w-0 flex-1"><span className="mb-0.5 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-ink3"><Music className="h-3 w-3" /> SharpSound</span><span className="block truncate text-sm font-extrabold">{track.title}</span><span className="block truncate text-xs text-ink3">{track.artist}</span></span>
    <span className="btn-grad grid h-10 w-10 shrink-0 place-items-center rounded-full">{active ? <Pause className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 translate-x-px fill-current" />}</span>
  </motion.button>;
}

function VideoEmbed({ url }: { url: string }) {
  const [loaded, setLoaded] = useState(false);
  const { tr } = useI18n();
  const id = youtubeId(url);
  if (!id) return <a href={url} target="_blank" rel="noopener noreferrer">{url}</a>;
  return <div className="my-4 max-w-xl overflow-hidden rounded-[26px] border border-vio/25 bg-vio/5">
    <AnimatePresence mode="wait" initial={false}>
      {loaded ? <motion.div key="player" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="aspect-video">
        <iframe src={`https://www.youtube-nocookie.com/embed/${id}`} title="YouTube video" loading="lazy" referrerPolicy="strict-origin-when-cross-origin" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowFullScreen className="h-full w-full border-0" />
      </motion.div> : <motion.button key="preview" type="button" onClick={() => setLoaded(true)} whileHover={{ backgroundColor: "rgba(139,92,246,.12)" }} className="flex w-full items-center gap-4 p-5 text-left">
        <span className="btn-grad grid h-14 w-14 shrink-0 place-items-center rounded-[20px] shadow-lg"><Play className="h-5 w-5 fill-current" /></span>
        <span className="min-w-0"><span className="block text-sm font-extrabold">YouTube</span><span className="block truncate text-xs text-ink3">{url}</span><span className="mt-1 block text-[11px] text-ink2">{tr("Нажми, чтобы загрузить внешний плеер", "Tap to load the external player")}</span></span>
      </motion.button>}
    </AnimatePresence>
    <a href={url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-end gap-1.5 border-t border-line px-4 py-2 text-[11px] font-semibold text-ink3"><ExternalLink className="h-3 w-3" />{tr("Открыть на YouTube", "Open on YouTube")}</a>
  </div>;
}

function PlainText({ value, embeds }: { value: string; embeds: boolean }) {
  const pieces = value.split(/(https?:\/\/[^\s\[\]<>]+)/g);
  return <>{pieces.map((piece, i) => {
    if (!/^https?:\/\//.test(piece)) return <Fragment key={i}>{piece}</Fragment>;
    const clean = piece.replace(/[.,;!?)]*$/, "");
    const trailing = piece.slice(clean.length);
    const url = safeUrl(clean);
    if (!url) return <Fragment key={i}>{piece}</Fragment>;
    return <Fragment key={i}>{embeds && youtubeId(url) ? <VideoEmbed url={url} /> : <a href={url} target="_blank" rel="noopener noreferrer">{clean}</a>}{trailing}</Fragment>;
  })}</>;
}

function BB({ node, embeds = true }: { node: BBNode; embeds?: boolean }) {
  const { tr } = useI18n();
  const children = (allow = embeds) => node.children.map((child, i) => <BB key={i} node={child} embeds={allow} />);
  switch (node.tag) {
    case "text": return <PlainText value={node.value ?? ""} embeds={embeds} />;
    case "h1": return <h2 className="rich-h1">{children(false)}</h2>;
    case "h2": return <h3 className="rich-h2">{children(false)}</h3>;
    case "h3": return <h4 className="rich-h3">{children(false)}</h4>;
    case "b": return <strong>{children(false)}</strong>;
    case "i": return <em>{children(false)}</em>;
    case "u": return <u>{children(false)}</u>;
    case "strike": return <s>{children(false)}</s>;
    case "spoiler": return <Spoiler>{children(false)}</Spoiler>;
    case "noparse": return <span>{node.value}</span>;
    case "code": return <pre className="rich-code"><code>{node.value}</code></pre>;
    case "hr": return <hr />;
    case "quote": return <blockquote>{node.attr && <div className="rich-quote-author">{tr("Цитата", "Quote")} / {node.attr.replace(/^=["']?|["']$/g, "")}</div>}{children(false)}</blockquote>;
    case "list":
    case "olist": {
      const items = node.children.filter((c) => c.tag === "li");
      return node.tag === "olist" || /^=\s*1/.test(node.attr) ? <ol>{items.map((c, i) => <li key={i}>{c.children.map((cc, j) => <BB key={j} node={cc} embeds={false} />)}</li>)}</ol> : <ul>{items.map((c, i) => <li key={i}>{c.children.map((cc, j) => <BB key={j} node={cc} embeds={false} />)}</li>)}</ul>;
    }
    case "table": return <div className="rich-table-scroll"><table className={cn(/noborder\s*=\s*1/i.test(node.attr) && "borderless", /equalcells\s*=\s*1/i.test(node.attr) && "equal-cells")}><tbody>{node.children.filter((c) => c.tag === "tr").map((row, i) => <tr key={i}>{row.children.filter((c) => c.tag === "th" || c.tag === "td").map((cell, j) => cell.tag === "th" ? <th key={j}>{cell.children.map((cc, k) => <BB key={k} node={cc} embeds={false} />)}</th> : <td key={j}>{cell.children.map((cc, k) => <BB key={k} node={cc} embeds={false} />)}</td>)}</tr>)}</tbody></table></div>;
    case "url": {
      const url = safeUrl(node.attr || nodeText(node));
      if (!url) return <span>{children(false)}</span>;
      return <><a href={url} target="_blank" rel="noopener noreferrer">{node.children.length ? children(false) : url}</a>{embeds && youtubeId(url) && <VideoEmbed url={url} />}</>;
    }
    case "img": {
      const url = safeImage(nodeText(node).trim());
      return url ? <img src={url} loading="lazy" alt={tr("Изображение в сообщении", "Post image")} className="my-4 max-h-[520px] max-w-full rounded-[24px] object-contain" /> : <span>{tr("Недопустимая ссылка на изображение", "Invalid image URL")}</span>;
    }
    case "track": return <TrackEmbed id={node.attr.replace(/^=/, "").trim()} />;
    default: return <>{children(false)}</>;
  }
}

export function RichText({ value, className }: { value: string; className?: string }) {
  const nodes = useMemo(() => parseBBCode(value), [value]);
  return <div className={cn("rich-text", className)}>{nodes.map((node, i) => <BB key={i} node={node} />)}</div>;
}