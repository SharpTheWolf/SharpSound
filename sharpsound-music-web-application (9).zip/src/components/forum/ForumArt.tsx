import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useId } from "react";

export function ForumArt() {
  const id = useId().replace(/[^a-z0-9]/gi, "");
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 65, damping: 19 });
  const sy = useSpring(y, { stiffness: 65, damping: 19 });
  const rx = useTransform(sy, (v) => -v * 14);
  const ry = useTransform(sx, (v) => v * 18);
  const backX = useTransform(sx, (v) => -v * 14);
  const backY = useTransform(sy, (v) => -v * 10);
  const frontX = useTransform(sx, (v) => v * 24);
  const frontY = useTransform(sy, (v) => v * 16);
  const purple = "M91 111 Q85 77 119 67 L261 40 Q295 34 303 69 L322 165 Q329 201 295 210 L183 233 L146 271 L136 243 L121 246 Q87 251 82 219Z";
  const lime = "M157 68 Q155 37 188 41 L333 61 Q367 64 365 97 L359 199 Q357 230 324 226 L294 222 L264 248 L266 217 L183 205 Q151 201 152 171Z";
  return <div className="forum-art relative h-full w-full" style={{ perspective: 1000 }} onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); x.set((e.clientX - r.left) / r.width - 0.5); y.set((e.clientY - r.top) / r.height - 0.5); }} onMouseLeave={() => { x.set(0); y.set(0); }}>
    <motion.svg viewBox="0 0 460 330" aria-hidden className="h-full w-full overflow-visible" style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}>
      <defs>
        <linearGradient id={`${id}p`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#c4b5fd" /><stop offset="0.42" stopColor="#8b5cf6" /><stop offset="1" stopColor="#4c1d95" /></linearGradient>
        <linearGradient id={`${id}l`} x1="0" y1="0" x2="0.8" y2="1"><stop offset="0" stopColor="#eeffb7" /><stop offset="0.5" stopColor="#b4f03c" /><stop offset="1" stopColor="#65a30d" /></linearGradient>
        <filter id={`${id}blur`} x="-50%" y="-100%" width="200%" height="300%"><feGaussianBlur stdDeviation="12" /></filter>
        <pattern id={`${id}grid`} width="18" height="18" patternUnits="userSpaceOnUse"><path d="M18 0H0V18" fill="none" stroke="white" strokeOpacity=".13" /></pattern>
        <clipPath id={`${id}clip`}><path d={lime} /></clipPath>
      </defs>
      <ellipse cx="245" cy="284" rx="134" ry="19" fill="#7c3aed" opacity=".3" filter={`url(#${id}blur)`} />
      <motion.ellipse cx="235" cy="177" rx="207" ry="72" fill="none" strokeWidth="1" strokeDasharray="4 9" style={{ stroke: "var(--vio)" }} opacity=".45" transform="rotate(-17 235 177)" animate={{ strokeDashoffset: [0, -104] }} transition={{ duration: 12, repeat: Infinity, ease: "linear" }} />
      <motion.g style={{ x: backX, y: backY }}>
        <motion.g animate={{ y: [2, -8, 2], rotate: [-2, 1, -2] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}>
          <path d={purple} transform="translate(-10 11)" fill="#2e1065" /><path d={purple} transform="translate(-5 5)" fill="#5b21b6" /><path d={purple} fill={`url(#${id}p)`} stroke="#ddd6fe" strokeOpacity=".6" />
          <path d="M113 156 L248 130 M120 176 L216 157 M126 198 L253 174" fill="none" stroke="#eee8ff" strokeWidth="7" strokeLinecap="round" opacity=".5" />
        </motion.g>
      </motion.g>
      <motion.g style={{ x: frontX, y: frontY }}>
        <motion.g animate={{ y: [-5, 7, -5], rotate: [2, -2, 2] }} transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}>
          <path d={lime} transform="translate(11 12)" fill="#365314" /><path d={lime} transform="translate(6 6)" fill="#4d7c0f" /><path d={lime} fill={`url(#${id}l)`} stroke="#e9ff9b" strokeOpacity=".8" />
          <rect x="145" y="37" width="230" height="224" fill={`url(#${id}grid)`} clipPath={`url(#${id}clip)`} />
          {[0, 1, 2].map((i) => <motion.circle key={i} cx={222 + i * 34} cy={132 + i * 5} r="9" fill="#1b2c05" animate={{ y: [0, -6, 0], opacity: [0.65, 1, 0.65] }} transition={{ duration: 1.8, repeat: Infinity, delay: i * 0.2 }} />)}
          <path d="M179 61 Q198 58 215 62" fill="none" stroke="white" strokeOpacity=".7" strokeWidth="4" strokeLinecap="round" />
        </motion.g>
      </motion.g>
      <motion.path d="M77 80 L84 97 L101 104 L84 111 L77 128 L70 111 L53 104 L70 97 Z" fill="#c4b5fd" animate={{ rotate: [0, 90, 180], scale: [0.85, 1.1, 0.85] }} style={{ transformOrigin: "77px 104px" }} transition={{ duration: 12, repeat: Infinity }} />
      <motion.circle cx="390" cy="219" r="10" fill="#b4f03c" animate={{ y: [0, -20, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }} />
      <circle cx="64" cy="221" r="4" fill="#c4b5fd" /><circle cx="343" cy="34" r="3" fill="#b4f03c" />
    </motion.svg>
  </div>;
}