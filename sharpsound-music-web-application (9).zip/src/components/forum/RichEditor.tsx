import { AnimatePresence, motion } from "framer-motion";
import { Bold, CircleHelp, Code, Eye, Heading1, Italic, Link, List, ListOrdered, Quote, Strikethrough, Table, Underline } from "lucide-react";
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { plainBBCode, safeUrl } from "../../lib/bbcode";
import { censor } from "../../lib/censor";
import { useI18n } from "../../lib/i18n";
import { useStore } from "../../store";
import { cn } from "../../utils/cn";
import { Modal } from "../Modal";
import { FormatHelp } from "./FormatHelp";
import { RichText } from "./RichText";

export interface EditorHandle { insert: (markup: string) => void; focus: () => void }
interface Props { value: string; onChange: (value: string) => void; placeholder?: string; onSubmit?: () => void; compact?: boolean }

export const RichEditor = forwardRef<EditorHandle, Props>(function RichEditor({ value, onChange, placeholder, onSubmit, compact }, ref) {
  const { tr } = useI18n();
  const field = useRef<HTMLTextAreaElement>(null);
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const [help, setHelp] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [url, setUrl] = useState("https://");
  const [headingOpen, setHeadingOpen] = useState(false);
  const selection = useRef({ a: 0, b: 0 });
  const pendingSelection = useRef<{ a: number; b: number } | null>(null);
  const bad = !censor(plainBBCode(value)).ok;

  useEffect(() => { if (bad) useStore.getState().chibi("censor"); }, [bad]);

  const focusSelection = (a: number, b: number) => {
    pendingSelection.current = { a, b };
    setMode("edit");
    requestAnimationFrame(() => {
      if (!field.current || !pendingSelection.current) return;
      field.current.focus(); field.current.setSelectionRange(a, b);
      pendingSelection.current = null;
    });
  };
  useEffect(() => {
    if (mode !== "edit") return;
    const timer = window.setTimeout(() => {
      const position = pendingSelection.current;
      if (!position || !field.current) return;
      field.current.focus(); field.current.setSelectionRange(position.a, position.b);
      pendingSelection.current = null;
    }, 190);
    return () => clearTimeout(timer);
  }, [mode]);

  const apply = (before: string, after: string, sample = tr("текст", "text")) => {
    const el = field.current;
    const a = el?.selectionStart ?? selection.current.a;
    const b = el?.selectionEnd ?? selection.current.b;
    const selected = value.slice(a, b) || sample;
    const next = value.slice(0, a) + before + selected + after + value.slice(b);
    if (next.length > 10000) return;
    onChange(next);
    focusSelection(a + before.length, a + before.length + selected.length);
  };
  const insert = (markup: string) => {
    const a = field.current?.selectionStart ?? value.length;
    const b = field.current?.selectionEnd ?? value.length;
    const next = value.slice(0, a) + markup + value.slice(b);
    if (next.length > 10000) return;
    onChange(next);
    focusSelection(a + markup.length, a + markup.length);
  };
  useImperativeHandle(ref, () => ({ insert, focus: () => focusSelection(value.length, value.length) }));
  const buttons = [
    { tag: "b", icon: Bold, name: tr("Полужирный (Ctrl+B)", "Bold (Ctrl+B)") },
    { tag: "i", icon: Italic, name: tr("Курсив (Ctrl+I)", "Italic (Ctrl+I)") },
    { tag: "u", icon: Underline, name: tr("Подчёркнутый (Ctrl+U)", "Underline (Ctrl+U)") },
    { tag: "strike", icon: Strikethrough, name: tr("Зачёркнутый", "Strikethrough") },
    { tag: "spoiler", icon: Eye, name: tr("Спойлер", "Spoiler") },
    { tag: "quote", icon: Quote, name: tr("Цитата", "Quote") },
    { tag: "code", icon: Code, name: tr("Код", "Code") },
  ];
  const tool = "grid h-8 w-8 shrink-0 place-items-center rounded-[10px] text-ink2 transition-colors hover:bg-vio/20 hover:text-vio focus-visible:outline-2 focus-visible:outline-vio";

  return <div className={cn("overflow-hidden rounded-[25px] border bg-ink/[0.025] transition-colors", bad ? "border-[#ff5c7a]/70" : "border-line focus-within:border-vio/50")}>
    <div className="flex flex-wrap items-center gap-0.5 border-b border-line p-2.5">
      <div className="relative">
        <button type="button" className={tool} title={tr("Заголовок", "Heading")} aria-label={tr("Заголовок", "Heading")} onClick={() => setHeadingOpen((v) => !v)}><Heading1 className="h-4 w-4" /></button>
        {headingOpen && <div className="glass-strong absolute left-0 top-10 z-10 flex gap-1 rounded-[14px] p-1 shadow-lg">{[1, 2, 3].map((i) => <button key={i} type="button" className="h-8 w-9 rounded-[10px] text-xs font-black hover:bg-vio/20" onMouseDown={(e) => e.preventDefault()} onClick={() => { apply(`[h${i}]`, `[/h${i}]`, tr("Заголовок", "Heading")); setHeadingOpen(false); }}>H{i}</button>)}</div>}
      </div>
      {buttons.map(({ tag, icon: Icon, name }) => <motion.button type="button" key={tag} whileTap={{ scale: 0.86 }} className={tool} title={name} aria-label={name} onMouseDown={(e) => e.preventDefault()} onClick={() => apply(`[${tag}]`, `[/${tag}]`)}><Icon className="h-4 w-4" /></motion.button>)}
      <span className="mx-1 h-5 w-px bg-line" />
      <button type="button" className={tool} title={tr("Маркированный список", "Bullet list")} aria-label={tr("Маркированный список", "Bullet list")} onMouseDown={(e) => e.preventDefault()} onClick={() => apply("[list]\n[*]", "\n[/list]", tr("Первый пункт\n[*]Второй пункт", "First item\n[*]Second item"))}><List className="h-4 w-4" /></button>
      <button type="button" className={tool} title={tr("Нумерованный список", "Numbered list")} aria-label={tr("Нумерованный список", "Numbered list")} onMouseDown={(e) => e.preventDefault()} onClick={() => apply("[olist]\n[*]", "\n[/olist]", tr("Первый пункт\n[*]Второй пункт", "First item\n[*]Second item"))}><ListOrdered className="h-4 w-4" /></button>
      <button type="button" className={tool} title={tr("Ссылка", "Link")} aria-label={tr("Ссылка", "Link")} onClick={() => { selection.current = { a: field.current?.selectionStart ?? value.length, b: field.current?.selectionEnd ?? value.length }; setUrl("https://"); setLinkOpen(true); }}><Link className="h-4 w-4" /></button>
      <button type="button" className={tool} title={tr("Таблица", "Table")} aria-label={tr("Таблица", "Table")} onMouseDown={(e) => e.preventDefault()} onClick={() => insert(`\n[table equalcells=1]\n[tr][th]${tr("Жанр", "Genre")}[/th][th]BPM[/th][/tr]\n[tr][td]Phonk[/td][td]140[/td][/tr]\n[/table]\n`)}><Table className="h-4 w-4" /></button>
      <button type="button" className={cn(tool, "text-[10px] font-bold")} title={tr("Разделитель", "Divider")} onMouseDown={(e) => e.preventDefault()} onClick={() => insert("\n[hr][/hr]\n")}>HR</button>
      <button type="button" className={cn(tool, "ml-auto")} title={tr("Справка по форматированию", "Formatting guide")} aria-label={tr("Справка по форматированию", "Formatting guide")} onClick={() => { setHelp(true); useStore.getState().chibi("format"); }}><CircleHelp className="h-4 w-4" /></button>
    </div>
    <div className="flex items-center justify-between gap-3 px-4 pt-3">
      <div className="flex gap-4 text-xs font-bold">{(["edit", "preview"] as const).map((m) => <button key={m} type="button" onClick={() => setMode(m)} className={cn("relative pb-2", mode === m ? "text-ink" : "text-ink3")}>
        {m === "edit" ? tr("Редактор", "Editor") : tr("Предпросмотр", "Preview")}
        {mode === m && <motion.span initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-gradient-to-r from-vio to-acid" />}
      </button>)}</div>
      <span className="text-[10px] font-semibold text-ink3">BBCode</span>
    </div>
    <AnimatePresence mode="wait" initial={false}>
      {mode === "edit" ? <motion.div key="edit" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
        <textarea ref={field} aria-label={tr("Текст сообщения", "Message text")} value={value} maxLength={10000} onChange={(e) => onChange(e.target.value)} placeholder={placeholder ?? tr("Напиши, что думаешь...", "Write what you think...")} className={cn("w-full resize-y bg-transparent px-4 py-3 text-sm leading-relaxed outline-none placeholder:text-ink3", compact ? "min-h-[140px]" : "min-h-[210px]")} onKeyDown={(e) => {
          if ((e.ctrlKey || e.metaKey) && ["b", "i", "u"].includes(e.key.toLowerCase())) { e.preventDefault(); const tag = e.key.toLowerCase(); apply(`[${tag}]`, `[/${tag}]`); }
          if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); onSubmit?.(); }
        }} />
      </motion.div> : <motion.div key="preview" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }} className={cn("px-4 py-4", compact ? "min-h-[140px]" : "min-h-[210px]")}>
        {value.trim() ? <RichText value={value} /> : <p className="text-sm text-ink3">{tr("Здесь появится твой текст", "Your text will appear here")}</p>}
      </motion.div>}
    </AnimatePresence>
    <div className="flex items-center justify-between gap-3 border-t border-line px-4 py-2 text-[10px] text-ink3"><span className={bad ? "text-[#ff5c7a]" : ""}>{bad ? tr("Цензура: убери мат перед публикацией", "Word filter: remove profanity before posting") : tr("Ctrl+Enter отправляет сообщение", "Ctrl+Enter sends your message")}</span><span className="tabular-nums">{value.length.toLocaleString()}/10 000</span></div>
    <AnimatePresence>{help && <FormatHelp onClose={() => setHelp(false)} />}</AnimatePresence>
    <AnimatePresence>{linkOpen && <Modal title={tr("Добавить ссылку", "Add a link")} onClose={() => setLinkOpen(false)} className="max-w-[480px]">
      <label className="block text-xs font-bold text-ink3">URL<input data-autofocus value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://" className="mt-2 w-full rounded-[18px] border border-line bg-ink/5 px-4 py-3 text-sm text-ink outline-none focus:border-vio" /></label>
      {!safeUrl(url) && url !== "https://" && <p className="mt-2 text-xs text-[#ff5c7a]">{tr("Нужна действующая HTTP(S) ссылка", "Enter a valid HTTP(S) URL")}</p>}
      <button type="button" disabled={!safeUrl(url)} className="btn-grad ml-auto mt-5 block rounded-full px-5 py-2.5 text-sm font-bold disabled:opacity-40" onClick={() => { const safe = safeUrl(url); if (!safe) return; apply(`[url=${safe}]`, "[/url]", tr("Ссылка", "Link")); setLinkOpen(false); }}>{tr("Вставить", "Insert")}</button>
    </Modal>}</AnimatePresence>
  </div>;
});