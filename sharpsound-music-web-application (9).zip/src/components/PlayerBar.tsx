import { AnimatePresence, motion } from "framer-motion";
import { Music, Pause, Play, SkipBack, SkipForward, ThumbsDown, Volume2, VolumeX } from "lucide-react";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { engine } from "../audio/engine";
import { fmtTime, MOODS } from "../data/catalog";
import { findTrack, useStore } from "../store";
import { cn } from "../utils/cn";
import { Cover } from "./Cover";
import { IconBtn, LikeButton } from "./ui";
import { useI18n } from "../lib/i18n";

function Marquee({ text, className }: { text: string; className?: string }) {
  const box = useRef<HTMLDivElement>(null);
  const inner = useRef<HTMLSpanElement>(null);
  const [over, setOver] = useState(false);
  useLayoutEffect(() => {
    const b = box.current;
    const i = inner.current;
    if (b && i) setOver(i.scrollWidth > b.clientWidth + 2);
  }, [text]);
  return (
    <div ref={box} className={cn("relative overflow-hidden whitespace-nowrap", className)} style={over ? { maskImage: "linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)" } : undefined}>
      <span ref={inner} className="invisible absolute left-0 top-0 whitespace-nowrap" aria-hidden>
        {text}
      </span>
      {over ? (
        <div className="marquee-track inline-flex">
          <span className="pr-10">{text}</span>
          <span className="pr-10">{text}</span>
        </div>
      ) : (
        <span className="inline-block">{text}</span>
      )}
    </div>
  );
}

function PlayBtn({ size = "md" }: { size?: "sm" | "md" }) {
  const { t } = useI18n();
  const isPlaying = useStore((s) => s.isPlaying);
  const togglePlay = useStore((s) => s.togglePlay);
  return (
    <motion.button
      whileTap={{ scale: 0.88 }}
      whileHover={{ scale: 1.06 }}
      onClick={togglePlay}
      aria-label={t(isPlaying ? "Пауза" : "Играть")}
      className={cn("btn-grad grid shrink-0 place-items-center rounded-full", size === "md" ? "h-12 w-12" : "h-11 w-11")}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span key={isPlaying ? "p" : "s"} initial={{ scale: 0.4, rotate: -40, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} exit={{ scale: 0.4, opacity: 0 }} transition={{ duration: 0.18 }}>
          {isPlaying ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 translate-x-[1px] fill-current" />}
        </motion.span>
      </AnimatePresence>
    </motion.button>
  );
}

export default function PlayerBar() {
  const { t: tx } = useI18n();
  const currentId = useStore((s) => s.currentId);
  useStore((s) => s.uploads);
  useStore((s) => s.studioTracks);
  const isPlaying = useStore((s) => s.isPlaying);
  const mode = useStore((s) => s.mode);
  const mood = useStore((s) => s.mood);
  const volume = useStore((s) => s.volume);
  const t = findTrack(currentId);
  const fill = useRef<HTMLDivElement>(null);
  const mfill = useRef<HTMLDivElement>(null);
  const cur = useRef<HTMLSpanElement>(null);
  const dur = useRef<HTMLSpanElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const lastVol = useRef(0.85);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const d = engine.duration() || t?.duration || 0;
      const c = Math.min(d, engine.time());
      const p = d ? (c / d) * 100 : 0;
      if (fill.current && !dragging.current) fill.current.style.width = `${p}%`;
      if (mfill.current) mfill.current.style.width = `${p}%`;
      if (cur.current) cur.current.textContent = fmtTime(c);
      if (dur.current) dur.current.textContent = fmtTime(d);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [t]);

  const ratio = (x: number) => {
    const el = track.current;
    if (!el) return 0;
    const r = el.getBoundingClientRect();
    return Math.max(0, Math.min(1, (x - r.left) / r.width));
  };
  const commit = (x: number) => {
    const d = engine.duration() || t?.duration || 0;
    useStore.getState().seek(ratio(x) * d);
  };

  const st = useStore.getState();
  const moodLabel = MOODS.find((m) => m.id === mood)?.label;

  return (
    <motion.div
      initial={{ y: 140, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.3, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed bottom-[84px] left-3 right-3 z-40 md:bottom-4 md:left-[124px] md:right-4 lg:left-[288px]"
    >
      <div className="glass-strong shadow-deep relative flex h-[64px] items-center gap-3 overflow-hidden rounded-[24px] px-2.5 md:h-[80px] md:rounded-[30px] md:px-4">
        <div className="absolute inset-x-0 top-0 h-[3px] bg-ink/5 md:hidden">
          <div ref={mfill} className="h-full bg-gradient-to-r from-vio to-acid" />
        </div>

        <div className="flex min-w-0 flex-1 items-center gap-3 md:w-[30%] md:flex-none">
          <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-[15px] shadow-lg md:h-14 md:w-14 md:rounded-[18px]">
            <AnimatePresence mode="popLayout" initial={false}>
              {t ? (
                <motion.div key={t.id} initial={{ opacity: 0, scale: 0.5, rotate: -14 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} exit={{ opacity: 0, scale: 0.5, rotate: 10 }} transition={{ duration: 0.4 }} className="h-full w-full">
                  <Cover t={t} spin={isPlaying} />
                </motion.div>
              ) : (
                <div className="grid h-full w-full place-items-center bg-ink/10 text-ink3">
                  <Music className="h-5 w-5" />
                </div>
              )}
            </AnimatePresence>
          </div>
          <div className="min-w-0 flex-1">
            <Marquee text={t?.title ?? tx("Тишина")} className="text-[15px] font-extrabold" />
            <div className="truncate text-xs text-ink3">{t ? t.artist : tx("Нажми play — помощник подберёт музыку")}</div>
          </div>
        </div>

        <div className="hidden flex-1 flex-col items-center gap-1.5 md:flex">
          <div className="flex items-center gap-2.5">
            {mode === "resonance" && t ? (
              <IconBtn title="Не нравится" onClick={() => st.dislike(t.id)} className="h-10 w-10">
                <ThumbsDown className="h-4 w-4" />
              </IconBtn>
            ) : (
              <span className="w-10" />
            )}
            <IconBtn title="Назад" onClick={st.prev} className="h-10 w-10">
              <SkipBack className="h-4 w-4 fill-current" />
            </IconBtn>
            <PlayBtn />
            <IconBtn title="Дальше" onClick={st.next} className="h-10 w-10">
              <SkipForward className="h-4 w-4 fill-current" />
            </IconBtn>
            {t ? <LikeButton id={t.id} className="h-10 w-10 btn-soft" /> : <span className="w-10" />}
          </div>
          <div className="flex w-full max-w-[580px] items-center gap-3 text-[11px] tabular-nums text-ink3">
            <span ref={cur} className="w-9 text-right">
              0:00
            </span>
            <div
              ref={track}
              className="group relative h-1.5 flex-1 cursor-pointer rounded-full bg-ink/10"
              onPointerDown={(e) => {
                dragging.current = true;
                (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
                if (fill.current) fill.current.style.width = `${ratio(e.clientX) * 100}%`;
              }}
              onPointerMove={(e) => {
                if (dragging.current && fill.current) fill.current.style.width = `${ratio(e.clientX) * 100}%`;
              }}
              onPointerUp={(e) => {
                if (!dragging.current) return;
                dragging.current = false;
                commit(e.clientX);
              }}
            >
              <div ref={fill} className="relative h-full rounded-full bg-gradient-to-r from-vio to-acid">
                <span className="absolute right-0 top-1/2 h-3.5 w-3.5 -translate-y-1/2 translate-x-1/2 rounded-full bg-ink opacity-0 shadow transition-opacity group-hover:opacity-100" />
              </div>
            </div>
            <span ref={dur} className="w-9">
              0:00
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 md:w-[30%] md:justify-end">
          <div className="md:hidden">
            <PlayBtn size="sm" />
          </div>
          <IconBtn title="Дальше" onClick={st.next} className="h-10 w-10 md:hidden">
            <SkipForward className="h-4 w-4 fill-current" />
          </IconBtn>
          {mode === "resonance" && (
            <div className="hidden items-center gap-2 rounded-full bg-vio/15 px-3 py-1.5 text-xs font-bold xl:flex">
              <span className="blink-dot h-2 w-2 rounded-full bg-acid" />
              {tx("Резонанс")}{moodLabel ? ` · ${tx(moodLabel)}` : ""}
            </div>
          )}
          <div className="hidden items-center gap-2 md:flex">
            <button
              onClick={() => {
                if (volume > 0) {
                  lastVol.current = volume;
                  st.setVolume(0);
                } else st.setVolume(lastVol.current || 0.85);
              }}
              className="grid h-9 w-9 place-items-center rounded-full text-ink2 hover:bg-ink/5"
              aria-label={tx("Звук")}
            >
              {volume === 0 ? <VolumeX className="h-[18px] w-[18px]" /> : <Volume2 className="h-[18px] w-[18px]" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={volume}
              onChange={(e) => st.setVolume(parseFloat(e.target.value))}
              className="range w-20 lg:w-24"
              style={{ ["--val" as string]: `${volume * 100}%` }}
              aria-label={tx("Громкость")}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
