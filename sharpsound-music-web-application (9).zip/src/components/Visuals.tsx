import { useEffect, useId, useRef } from "react";
import { engine } from "../audio/engine";
import { cn } from "../utils/cn";

const sid = (s: string) => s.replace(/[^a-zA-Z0-9]/g, "");

function useCanvasLoop(draw: (ctx: CanvasRenderingContext2D, w: number, h: number, dt: number, now: number) => void, scale = 1) {
  const ref = useRef<HTMLCanvasElement>(null);
  const drawRef = useRef(draw);
  drawRef.current = draw;
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let visible = true;
    const resize = () => {
      const r = cv.getBoundingClientRect();
      const k = Math.min(2, window.devicePixelRatio || 1) * scale;
      cv.width = Math.max(1, Math.round(r.width * k));
      cv.height = Math.max(1, Math.round(r.height * k));
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(cv);
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting));
    io.observe(cv);
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (visible) drawRef.current(ctx, cv.width, cv.height, dt, now);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
    };
  }, [scale]);
  return ref;
}

/** "Резонанс" aura – blurred morphing blobs that follow bass / mids / highs */
export function ResonanceOrb({ className }: { className?: string }) {
  const st = useRef({ t: 0 });
  const blobs = [
    { c: [76, 29, 149], x: 0.52, y: 0.5, r: 0.44, k: [1, 3, 6], p: 3.1 },
    { c: [139, 92, 246], x: 0.5, y: 0.52, r: 0.33, k: [2, 3, 5], p: 0 },
    { c: [180, 240, 60], x: 0.4, y: 0.6, r: 0.22, k: [3, 2, 4], p: 1.3 },
    { c: [240, 171, 252], x: 0.62, y: 0.42, r: 0.19, k: [2, 5, 3], p: 2.4 },
  ];
  const ref = useCanvasLoop((ctx, w, h, dt) => {
    const b = engine.bands();
    const s = st.current;
    s.t += dt * (0.45 + b.level * 2.4);
    const t = s.t;
    const m = Math.min(w, h);
    ctx.clearRect(0, 0, w, h);
    ctx.globalCompositeOperation = document.documentElement.getAttribute("data-theme") === "light" ? "source-over" : "lighter";
    for (const bl of blobs) {
      const cx = w * (bl.x + Math.sin(t * 0.3 + bl.p) * 0.05);
      const cy = h * (bl.y + Math.cos(t * 0.25 + bl.p) * 0.05);
      const R = m * bl.r * (1 + b.level * 0.5 + b.bass * 0.22);
      ctx.beginPath();
      for (let i = 0; i <= 48; i++) {
        const a = (i / 48) * Math.PI * 2;
        const rr =
          1 +
          0.09 * Math.sin(bl.k[0] * a + t + bl.p) +
          (0.05 + b.bass * 0.24) * Math.sin(bl.k[1] * a - t * 1.3) +
          (0.03 + b.high * 0.14) * Math.sin(bl.k[2] * a + t * 2.1);
        const x = cx + Math.cos(a) * R * rr;
        const y = cy + Math.sin(a) * R * rr;
        if (i) ctx.lineTo(x, y);
        else ctx.moveTo(x, y);
      }
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.2);
      const [r, gg, bb] = bl.c;
      g.addColorStop(0, `rgba(${r},${gg},${bb},0.95)`);
      g.addColorStop(0.6, `rgba(${r},${gg},${bb},0.5)`);
      g.addColorStop(1, `rgba(${r},${gg},${bb},0)`);
      ctx.fillStyle = g;
      ctx.fill();
    }
  }, 0.5);
  return <canvas ref={ref} className={className} style={{ filter: "blur(26px) saturate(1.35)" }} />;
}

/** 90-gon prism made of verticals only, with a blob at every vertex. Audio reactive. */
export function PrismVis({ className, n = 90 }: { className?: string; n?: number }) {
  const st = useRef({ rot: 0, t: 0 });
  const ref = useCanvasLoop((ctx, w, h, dt) => {
    const b = engine.bands();
    const spec = engine.freq;
    const s = st.current;
    s.rot += dt * (0.16 + b.level * 0.9);
    s.t += dt;
    const light = document.documentElement.getAttribute("data-theme") === "light";
    ctx.clearRect(0, 0, w, h);
    const cx = w / 2;
    const cy = h * 0.7;
    const rx = w * 0.4;
    const ry = rx * 0.26;
    const H = h * 0.52;
    const k = w / 400;
    const items = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + s.rot;
      const z = Math.sin(a);
      const mi = i < n / 2 ? i : n - i;
      const bin = Math.floor(3 + Math.pow(mi / (n / 2), 1.6) * 220);
      const mag = (spec[bin] || 0) / 255;
      const idle = 0.2 + 0.12 * Math.sin(s.t * 1.4 + i * 0.35) + 0.06 * Math.sin(s.t * 0.7 - i * 0.12);
      const hh = H * (idle * (1 - b.level * 0.5) + mag * 0.85);
      items.push({ i, z, x: cx + Math.cos(a) * rx, y: cy + z * ry, hh, mag });
    }
    // top ring
    ctx.beginPath();
    items.forEach((p, i) => {
      if (i) ctx.lineTo(p.x, p.y - p.hh);
      else ctx.moveTo(p.x, p.y - p.hh);
    });
    ctx.closePath();
    ctx.strokeStyle = light ? "rgba(124,58,237,0.18)" : "rgba(180,240,60,0.14)";
    ctx.lineWidth = 1 * k;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    ctx.strokeStyle = light ? "rgba(124,58,237,0.25)" : "rgba(139,92,246,0.3)";
    ctx.stroke();
    items.sort((a, b2) => a.z - b2.z);
    for (const p of items) {
      const u = (Math.sin((p.i / n) * Math.PI * 4) + 1) / 2;
      const r = Math.round(139 + (180 - 139) * u);
      const g = Math.round(92 + (240 - 92) * u);
      const bl = Math.round(246 + (60 - 246) * u);
      const alpha = 0.16 + (0.84 * (p.z + 1)) / 2;
      const grad = ctx.createLinearGradient(p.x, p.y, p.x, p.y - p.hh);
      grad.addColorStop(0, `rgba(${r},${g},${bl},0)`);
      grad.addColorStop(1, `rgba(${r},${g},${bl},${alpha})`);
      ctx.strokeStyle = grad;
      ctx.lineWidth = (0.6 + (p.z + 1) * 0.9) * k;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x, p.y - p.hh);
      ctx.stroke();
      const rad = (1.4 + p.mag * 5 + (p.z + 1) * 0.9) * k;
      ctx.fillStyle = `rgba(${r},${g},${bl},${alpha * 0.22})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y - p.hh, rad * 2.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = `rgba(${r},${g},${bl},${alpha})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y - p.hh, rad, 0, Math.PI * 2);
      ctx.fill();
      const ix = p.x + (cx - p.x) * 0.14;
      ctx.fillStyle = `rgba(${r},${g},${bl},${alpha * 0.35})`;
      ctx.beginPath();
      ctx.arc(ix, p.y - p.hh * 0.55, rad * 0.8, 0, Math.PI * 2);
      ctx.fill();
    }
  });
  return <canvas ref={ref} className={className} />;
}

export function Cube3D({ size = 120, className }: { size?: number; className?: string }) {
  const half = size / 2;
  const faces = [
    `rotateY(0deg) translateZ(${half}px)`,
    `rotateY(90deg) translateZ(${half}px)`,
    `rotateY(180deg) translateZ(${half}px)`,
    `rotateY(-90deg) translateZ(${half}px)`,
    `rotateX(90deg) translateZ(${half}px)`,
    `rotateX(-90deg) translateZ(${half}px)`,
  ];
  return (
    <div className={className} style={{ width: size, height: size, perspective: 900 }}>
      <div className="cube-spin relative h-full w-full" style={{ transformStyle: "preserve-3d" }}>
        {faces.map((tf, i) => (
          <div key={i} className="cube-face" style={{ transform: tf }}>
            {i === 0 && (
              <svg viewBox="0 0 100 100" className="h-full w-full p-[22%] opacity-90">
                <g stroke="url(#cubeG)" strokeLinecap="round" fill="none">
                  <path d="M40 18V82M60 18V82" strokeWidth="9" />
                  <path d="M24 42L76 32M24 66L76 56" strokeWidth="12" />
                </g>
                <defs>
                  <linearGradient id="cubeG" x1="0" y1="1" x2="1" y2="0">
                    <stop offset="0" stopColor="#8b5cf6" />
                    <stop offset="1" stopColor="#b4f03c" />
                  </linearGradient>
                </defs>
              </svg>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

const TONGUES = [
  { d: "M118 118 C 100 84, 128 62, 112 18 C 146 56, 150 92, 130 120 Z", dur: 1.5, delay: 0 },
  { d: "M196 112 C 182 78, 210 58, 204 6 C 236 52, 236 90, 212 116 Z", dur: 1.8, delay: -0.5 },
  { d: "M150 150 C 140 120, 160 104, 156 70 C 176 100, 178 130, 166 152 Z", dur: 1.3, delay: -0.9 },
  { d: "M80 196 C 64 170, 82 150, 70 118 C 100 146, 104 176, 94 198 Z", dur: 1.7, delay: -0.3 },
  { d: "M244 166 C 236 140, 254 124, 252 92 C 274 124, 272 152, 258 170 Z", dur: 1.4, delay: -1.1 },
];

/** Sharp sign (#) wrapped in a fire-like but not-fire violet→lime animated aura */
export function FlameSharp({ className }: { className?: string }) {
  const id = "f" + sid(useId());
  const sharp = (
    <>
      <path d="M134 120V336M204 120V336" strokeWidth="32" />
      <path d="M70 216L266 178M70 292L266 254" strokeWidth="44" />
    </>
  );
  return (
    <svg viewBox="0 0 320 380" className={cn("overflow-visible", className)} aria-hidden>
      <defs>
        <linearGradient id={`${id}g`} x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#3b0d8c" />
          <stop offset="0.32" stopColor="#7c3aed" />
          <stop offset="0.56" stopColor="#c084fc" />
          <stop offset="0.82" stopColor="#b4f03c" />
          <stop offset="1" stopColor="#f4ffd4" />
        </linearGradient>
        <linearGradient id={`${id}s`} gradientUnits="userSpaceOnUse" x1="60" y1="340" x2="280" y2="120">
          <stop offset="0" stopColor="#6d28d9" />
          <stop offset="0.55" stopColor="#b794ff" />
          <stop offset="1" stopColor="#c6f432" />
        </linearGradient>
        <filter id={`${id}f`} x="-25%" y="-25%" width="150%" height="150%">
          <feTurbulence type="fractalNoise" baseFrequency="0.012 0.045" numOctaves="2" seed="7" result="n">
            <animate attributeName="baseFrequency" dur="6s" values="0.012 0.045;0.018 0.07;0.012 0.045" repeatCount="indefinite" />
          </feTurbulence>
          <feDisplacementMap in="SourceGraphic" in2="n" scale="20" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        <filter id={`${id}b`} x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="18" />
        </filter>
      </defs>
      <g filter={`url(#${id}b)`} opacity="0.8">
        {TONGUES.map((t, i) => (
          <path key={i} d={t.d} fill={`url(#${id}g)`} />
        ))}
        <g fill="none" stroke="#7c3aed" strokeLinecap="round">
          {sharp}
        </g>
      </g>
      <g filter={`url(#${id}f)`}>
        {TONGUES.map((t, i) => (
          <path key={i} d={t.d} fill={`url(#${id}g)`} className="flame-lick" style={{ animationDuration: `${t.dur}s`, animationDelay: `${t.delay}s` }} />
        ))}
      </g>
      <g fill="none" strokeLinecap="round" transform="translate(9 11)" style={{ stroke: "var(--ext)" }}>
        {sharp}
      </g>
      <g fill="none" strokeLinecap="round" transform="translate(5 6)" stroke="#4c1d95">
        {sharp}
      </g>
      <g fill="none" strokeLinecap="round" stroke={`url(#${id}s)`} filter={`url(#${id}f)`}>
        {sharp}
      </g>
      {Array.from({ length: 9 }, (_, i) => (
        <circle
          key={i}
          cx={90 + ((i * 37) % 160)}
          cy={170 + ((i * 53) % 120)}
          r={2 + (i % 3)}
          fill={i % 2 ? "#b4f03c" : "#c084fc"}
          className="ember"
          style={{ animationDelay: `${-i * 0.37}s`, ["--dx" as string]: `${(i % 2 ? 1 : -1) * (6 + i * 3)}px` }}
        />
      ))}
    </svg>
  );
}

export function CircleText({ text, className, reverse, size = 13 }: { text: string; className?: string; reverse?: boolean; size?: number }) {
  const id = "ct" + sid(useId());
  return (
    <svg viewBox="0 0 200 200" className={cn(reverse ? "animate-spin-rev" : "animate-spin-slow", className)} aria-hidden>
      <defs>
        <path id={id} d="M100,100 m-82,0 a82,82 0 1,1 164,0 a82,82 0 1,1 -164,0" />
      </defs>
      <text fontFamily="Unbounded Variable, sans-serif" fontWeight="700" fontSize={size} letterSpacing="2" fill="currentColor">
        <textPath href={`#${id}`} textLength={510} lengthAdjust="spacing">
          {text}
        </textPath>
      </text>
    </svg>
  );
}

export function MiniEq({ on, className }: { on: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex h-3.5 items-end gap-[2px]", className)}>
      {[0, 1, 2, 3].map((i) => (
        <span
          key={i}
          className="eq-bar w-[3px] rounded-full bg-current"
          style={{ animationDelay: `${i * 0.17}s`, animationPlayState: on ? "running" : "paused", height: on ? undefined : "30%" }}
        />
      ))}
    </span>
  );
}
