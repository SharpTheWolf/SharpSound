import { memo, useId, type ReactNode } from "react";
import { rng } from "../audio/synth";
import type { CoverStyle } from "../data/catalog";
import { cn } from "../utils/cn";

export interface CoverSrc {
  id: string;
  title: string;
  hue: number;
  cover: CoverStyle;
  seed: number;
  coverUrl?: string;
}

const hsl = (h: number, s: number, l: number, a = 1) => `hsla(${((h % 360) + 360) % 360}, ${s}%, ${l}%, ${a})`;
const DISPLAY = "Unbounded Variable, Unbounded, sans-serif";

export const Cover = memo(function Cover({ t, className, spin }: { t: CoverSrc; className?: string; spin?: boolean }) {
  const uid = "c" + useId().replace(/[^a-zA-Z0-9]/g, "");
  if (t.coverUrl)
    return <img src={t.coverUrl} alt={t.title} draggable={false} className={cn("h-full w-full object-cover", className)} />;
  return (
    <svg viewBox="0 0 200 200" className={cn("block h-full w-full", className)} preserveAspectRatio="xMidYMid slice" aria-label={t.title}>
      {art(t, uid, !!spin)}
    </svg>
  );
});

function art(t: CoverSrc, id: string, spin: boolean): ReactNode {
  const r = rng(t.seed + 99);
  const h = t.hue;
  const c1 = hsl(h, 88, 64);
  const c2 = hsl(h + 55, 90, 62);
  const c3 = hsl(h - 60, 82, 62);
  const dk = hsl(h, 45, 6);
  const dk2 = hsl(h + 25, 55, 14);
  const spinCls = spin ? "animate-spin-slow" : "";

  switch (t.cover) {
    case "bars": {
      const items = Array.from({ length: 56 }, (_, i) => {
        const a = (i / 56) * Math.PI * 2;
        const z = Math.sin(a);
        return { i, z, x: 100 + Math.cos(a) * 66, y: 66 + z * 16, hg: 40 + r() * 72 + (z + 1) * 10 };
      }).sort((a, b) => a.z - b.z);
      return (
        <>
          <defs>
            <linearGradient id={`${id}bg`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={dk2} />
              <stop offset="1" stopColor={dk} />
            </linearGradient>
            <linearGradient id={`${id}br`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={c2} />
              <stop offset="0.45" stopColor={c1} />
              <stop offset="1" stopColor={c1} stopOpacity="0" />
            </linearGradient>
            <radialGradient id={`${id}gl`} cx="0.5" cy="0.36" r="0.5">
              <stop offset="0" stopColor={c1} stopOpacity="0.55" />
              <stop offset="1" stopColor={c1} stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="200" height="200" fill={`url(#${id}bg)`} />
          <rect width="200" height="200" fill={`url(#${id}gl)`} />
          <ellipse cx="100" cy="66" rx="66" ry="16" fill="none" stroke={c2} strokeOpacity="0.4" />
          {items.map((b) => (
            <rect key={b.i} x={b.x - 1.6} y={b.y} width="3.2" height={b.hg} rx="1.6" fill={`url(#${id}br)`} opacity={0.28 + (0.72 * (b.z + 1)) / 2} />
          ))}
          <text x="100" y="186" textAnchor="middle" fontFamily={DISPLAY} fontWeight="700" fontSize="10" letterSpacing="3" fill="#fff" opacity="0.85">
            {t.title.toUpperCase().slice(0, 20)}
          </text>
        </>
      );
    }
    case "ring": {
      const txt = `${t.title} • `.repeat(8).toUpperCase().slice(0, 44);
      return (
        <>
          <defs>
            <radialGradient id={`${id}bg`} cx="0.5" cy="0.5" r="0.7">
              <stop offset="0" stopColor={dk2} />
              <stop offset="1" stopColor={dk} />
            </radialGradient>
            <linearGradient id={`${id}tx`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor={c1} />
              <stop offset="1" stopColor={c2} />
            </linearGradient>
            <path id={`${id}p1`} d="M100,100 m-70,0 a70,70 0 1,1 140,0 a70,70 0 1,1 -140,0" />
            <path id={`${id}p2`} d="M100,100 m-47,0 a47,47 0 1,0 94,0 a47,47 0 1,0 -94,0" />
            <filter id={`${id}bl`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="10" />
            </filter>
          </defs>
          <rect width="200" height="200" fill={`url(#${id}bg)`} />
          <circle cx="96" cy="104" r="28" fill={c1} filter={`url(#${id}bl)`} opacity="0.9" />
          <circle cx="110" cy="92" r="16" fill={c2} filter={`url(#${id}bl)`} opacity="0.85" />
          <circle cx="100" cy="100" r="86" fill="none" stroke={c1} strokeOpacity="0.35" strokeDasharray="2 5" />
          <g className={spinCls} style={{ transformOrigin: "100px 100px" }}>
            <text fontFamily={DISPLAY} fontWeight="800" fontSize="13" fill={`url(#${id}tx)`}>
              <textPath href={`#${id}p1`} textLength={436} lengthAdjust="spacingAndGlyphs">
                {txt}
              </textPath>
            </text>
          </g>
          <g className={spin ? "animate-spin-rev" : ""} style={{ transformOrigin: "100px 100px" }}>
            <text fontFamily={DISPLAY} fontWeight="600" fontSize="8.5" fill="#fff" opacity="0.75">
              <textPath href={`#${id}p2`} textLength={292} lengthAdjust="spacingAndGlyphs">
                SHARPSOUND • SHARPSOUND • SHARPSOUND •
              </textPath>
            </text>
          </g>
        </>
      );
    }
    case "waves": {
      const lines = 24;
      const amp = 7 + r() * 8;
      const ph = r() * 6;
      const fr = 0.035 + r() * 0.03;
      const paths = Array.from({ length: lines }, (_, j) => {
        const y0 = 32 + j * (136 / (lines - 1));
        const mid = 1 - Math.abs(j / (lines - 1) - 0.5) * 1.2;
        let d = "";
        for (let x = 24; x <= 176; x += 4) {
          const y = y0 + amp * mid * Math.sin(x * fr + ph + j * 0.35) * Math.sin(((x - 24) / 152) * Math.PI);
          d += `${d ? "L" : "M"}${x} ${y.toFixed(1)}`;
        }
        return d;
      });
      return (
        <>
          <defs>
            <radialGradient id={`${id}bg`} cx="0.5" cy="0.5" r="0.75">
              <stop offset="0" stopColor={dk2} />
              <stop offset="1" stopColor={dk} />
            </radialGradient>
            <linearGradient id={`${id}st`} gradientUnits="userSpaceOnUse" x1="30" y1="30" x2="170" y2="170">
              <stop offset="0" stopColor={c3} />
              <stop offset="0.5" stopColor={c1} />
              <stop offset="1" stopColor={c2} />
            </linearGradient>
            <clipPath id={`${id}cl`}>
              <circle cx="100" cy="100" r="74" />
            </clipPath>
          </defs>
          <rect width="200" height="200" fill={`url(#${id}bg)`} />
          <g clipPath={`url(#${id}cl)`}>
            {paths.map((d, i) => (
              <path key={i} d={d} fill="none" stroke={`url(#${id}st)`} strokeWidth="1.5" strokeLinecap="round" />
            ))}
          </g>
        </>
      );
    }
    case "spiral": {
      const arm = (off: number) => {
        let d = "";
        for (let a = 0; a < 100; a += 0.18) {
          const rr = 2 + a * 1.15;
          if (rr > 108) break;
          d += `${d ? "L" : "M"}${(100 + Math.cos(a + off) * rr).toFixed(1)} ${(100 + Math.sin(a + off) * rr).toFixed(1)}`;
        }
        return d;
      };
      const cols = [hsl(h, 80, 52), hsl(h + 60, 85, 50), hsl(h - 70, 80, 55)];
      return (
        <>
          <defs>
            <radialGradient id={`${id}bg`} cx="0.5" cy="0.5" r="0.7">
              <stop offset="0" stopColor={hsl(h, 70, 94)} />
              <stop offset="1" stopColor={hsl(h + 30, 60, 80)} />
            </radialGradient>
            <linearGradient id={`${id}tab`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor={hsl(h + 160, 70, 72)} />
              <stop offset="1" stopColor={hsl(h + 160, 60, 42)} />
            </linearGradient>
          </defs>
          <rect width="200" height="200" fill={`url(#${id}bg)`} />
          <g className={spinCls} style={{ transformOrigin: "100px 100px" }}>
            {cols.map((c, i) => (
              <path key={i} d={arm((i * Math.PI * 2) / 3)} fill="none" stroke={c} strokeWidth="1.6" strokeOpacity="0.85" />
            ))}
          </g>
          <g transform="rotate(-28 100 100)">
            <rect x="88" y="66" width="34" height="78" rx="15" fill={hsl(h + 160, 50, 22)} />
            <rect x="83" y="60" width="34" height="78" rx="15" fill={`url(#${id}tab)`} />
            <rect x="88" y="66" width="8" height="50" rx="4" fill="#fff" opacity="0.45" />
          </g>
        </>
      );
    }
    case "blob": {
      const cs = [c1, c2, c3, "#ffffff"];
      const blobs = cs.map((c, i) => ({ c, x: 50 + r() * 100, y: 50 + r() * 100, rr: i === 3 ? 18 + r() * 10 : 34 + r() * 26 }));
      return (
        <>
          <defs>
            <filter id={`${id}b`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="17" />
            </filter>
          </defs>
          <rect width="200" height="200" fill={dk2} />
          <g filter={`url(#${id}b)`}>
            {blobs.map((b, i) => (
              <circle key={i} cx={b.x} cy={b.y} r={b.rr} fill={b.c} opacity={i === 3 ? 0.7 : 0.95} />
            ))}
          </g>
          <text x="16" y="184" fontFamily="Manrope Variable, sans-serif" fontWeight="700" fontSize="11" fill="#fff" opacity="0.9">
            {t.title.toLowerCase().slice(0, 24)}
          </text>
        </>
      );
    }
    case "wire": {
      const P = (1 + Math.sqrt(5)) / 2;
      const V = [[-1, P, 0], [1, P, 0], [-1, -P, 0], [1, -P, 0], [0, -1, P], [0, 1, P], [0, -1, -P], [0, 1, -P], [P, 0, -1], [P, 0, 1], [-P, 0, -1], [-P, 0, 1]];
      const ax = r() * Math.PI;
      const ay = r() * Math.PI;
      const pr = V.map(([x, y, z]) => {
        const y1 = y * Math.cos(ax) - z * Math.sin(ax);
        const z1 = y * Math.sin(ax) + z * Math.cos(ax);
        const x2 = x * Math.cos(ay) + z1 * Math.sin(ay);
        const z2 = -x * Math.sin(ay) + z1 * Math.cos(ay);
        const s = 320 / (320 - z2 * 34);
        return { x: 100 + x2 * 34 * s, y: 94 + y1 * 34 * s, z: z2 };
      });
      const edges: [number, number][] = [];
      for (let i = 0; i < 12; i++)
        for (let j = i + 1; j < 12; j++) {
          const d = Math.hypot(V[i][0] - V[j][0], V[i][1] - V[j][1], V[i][2] - V[j][2]);
          if (Math.abs(d - 2) < 0.01) edges.push([i, j]);
        }
      return (
        <>
          <defs>
            <linearGradient id={`${id}bg`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={dk} />
              <stop offset="1" stopColor={dk2} />
            </linearGradient>
            <filter id={`${id}g`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" />
            </filter>
          </defs>
          <rect width="200" height="200" fill={`url(#${id}bg)`} />
          <ellipse cx="100" cy="172" rx="52" ry="8" fill={c1} opacity="0.25" filter={`url(#${id}g)`} />
          <ellipse cx="100" cy="94" rx="84" ry="20" fill="none" stroke={c2} strokeOpacity="0.35" transform="rotate(-12 100 94)" />
          <g filter={`url(#${id}g)`} opacity="0.7">
            {edges.map(([a, b], i) => (
              <line key={i} x1={pr[a].x} y1={pr[a].y} x2={pr[b].x} y2={pr[b].y} stroke={c1} strokeWidth="2" />
            ))}
          </g>
          {edges.map(([a, b], i) => {
            const z = (pr[a].z + pr[b].z) / 2;
            return <line key={i} x1={pr[a].x} y1={pr[a].y} x2={pr[b].x} y2={pr[b].y} stroke={c1} strokeWidth={0.8 + (z + 2) * 0.3} opacity={0.45 + (z + 2) * 0.14} />;
          })}
          {pr.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r={2.4 + (p.z + 2) * 0.6} fill={c2} />
          ))}
        </>
      );
    }
    case "claws": {
      const n = 7 + Math.floor(r() * 4);
      return (
        <>
          <defs>
            <linearGradient id={`${id}ch`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#ffffff" />
              <stop offset="0.35" stopColor="#8e93a0" />
              <stop offset="0.6" stopColor="#ececf4" />
              <stop offset="1" stopColor={c1} />
            </linearGradient>
            <filter id={`${id}gl`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" />
            </filter>
          </defs>
          <rect width="200" height="200" fill={hsl(h, 30, 4)} />
          <circle cx="100" cy="100" r="44" fill={c1} opacity="0.35" filter={`url(#${id}gl)`} />
          <g className={spinCls} style={{ transformOrigin: "100px 100px" }}>
            {Array.from({ length: n }, (_, i) => (
              <g key={i} transform={`translate(100 100) rotate(${(i * 360) / n})`}>
                <path d="M0 -40 C 16 -50, 30 -70, 22 -94 C 16 -76, 6 -62, -12 -50 Z" fill={`url(#${id}ch)`} />
                <path d="M-8 -47 C -4 -58, 2 -62, 7 -70 C 4 -59, 2 -54, 0 -46 Z" fill={`url(#${id}ch)`} opacity="0.75" />
              </g>
            ))}
          </g>
          <circle cx="100" cy="100" r="36" fill="none" stroke={c1} strokeOpacity="0.5" />
        </>
      );
    }
    case "iso":
    default: {
      const s = 17;
      const cubes: { x: number; y: number; acc: boolean; depth: number }[] = [];
      for (let i = 0; i < 4; i++)
        for (let j = 0; j < 4; j++) {
          const hgt = Math.floor(r() * 3.6);
          for (let k = 0; k <= hgt; k++)
            cubes.push({ x: 100 + (i - j) * s * 0.866, y: 70 + (i + j) * s * 0.5 - k * s, acc: r() < 0.12, depth: (i + j) * 100 + k * 10 + i });
        }
      const order = cubes.map((c, idx) => ({ c, idx })).sort((a, b) => a.c.depth - b.c.depth);
      const w = s * 0.866;
      const hh = s * 0.5;
      return (
        <>
          <defs>
            <linearGradient id={`${id}bg`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor={dk2} />
              <stop offset="1" stopColor={dk} />
            </linearGradient>
          </defs>
          <rect width="200" height="200" fill={`url(#${id}bg)`} />
          <g transform="translate(0 22)">
            {order.map(({ c, idx }) => {
              const hu = c.acc ? h + 150 : h;
              return (
                <g key={idx}>
                  <polygon points={`${c.x},${c.y - hh} ${c.x + w},${c.y} ${c.x},${c.y + hh} ${c.x - w},${c.y}`} fill={hsl(hu, 85, 66)} />
                  <polygon points={`${c.x - w},${c.y} ${c.x},${c.y + hh} ${c.x},${c.y + hh + s} ${c.x - w},${c.y + s}`} fill={hsl(hu, 70, 42)} />
                  <polygon points={`${c.x + w},${c.y} ${c.x},${c.y + hh} ${c.x},${c.y + hh + s} ${c.x + w},${c.y + s}`} fill={hsl(hu, 70, 27)} />
                </g>
              );
            })}
          </g>
        </>
      );
    }
  }
}
