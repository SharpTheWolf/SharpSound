import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Heart, Play } from "lucide-react";
import { useRef, useState, type ReactNode } from "react";
import { fmtTime, GENRES, type Track } from "../data/catalog";
import { useStore } from "../store";
import { cn } from "../utils/cn";
import { Cover, type CoverSrc } from "./Cover";
import { GlyphBlob } from "./GlyphBlob";
import { MiniEq } from "./Visuals";
import { useI18n } from "../lib/i18n";

export function IconBtn({
  children,
  onClick,
  title,
  className,
  active,
}: {
  children: ReactNode;
  onClick?: () => void;
  title?: string;
  className?: string;
  active?: boolean;
}) {
  const { t } = useI18n();
  return (
    <motion.button
      whileTap={{ scale: 0.88 }}
      onClick={onClick}
      title={t(title)}
      aria-label={t(title)}
      className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-full btn-soft text-ink", active && "text-acidink ring-1 ring-acid/50", className)}
    >
      {children}
    </motion.button>
  );
}

export function LikeButton({ id, big, className }: { id: string; big?: boolean; className?: string }) {
  const { t } = useI18n();
  const liked = useStore((s) => !!s.liked[id]);
  const toggle = useStore((s) => s.toggleLike);
  const [burst, setBurst] = useState(0);
  return (
    <motion.button
      whileTap={{ scale: 0.8 }}
      onClick={(e) => {
        e.stopPropagation();
        if (!liked) setBurst((b) => b + 1);
        toggle(id);
      }}
      aria-label={t(liked ? "Убрать из любимых" : "В любимые")}
      className={cn("relative grid shrink-0 place-items-center rounded-full", big ? "h-12 w-12 btn-soft" : "h-9 w-9 hover:bg-ink/5", className)}
    >
      <motion.span key={burst} initial={burst ? { scale: 0.4 } : false} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 500, damping: 12 }}>
        <Heart className={cn(big ? "h-5 w-5" : "h-[18px] w-[18px]", liked ? "fill-[#ff5c9a] text-[#ff5c9a]" : "text-ink3")} />
      </motion.span>
      {burst > 0 && (
        <span key={`b${burst}`} className="pointer-events-none absolute inset-0">
          {Array.from({ length: 6 }, (_, i) => (
            <motion.span
              key={i}
              className="absolute left-1/2 top-1/2 h-1.5 w-1.5 rounded-full"
              style={{ background: i % 2 ? "#ff5c9a" : "var(--acid)" }}
              initial={{ x: 0, y: 0, opacity: 1 }}
              animate={{ x: Math.cos((i / 6) * Math.PI * 2) * 20, y: Math.sin((i / 6) * Math.PI * 2) * 20, opacity: 0 }}
              transition={{ duration: 0.55, ease: "easeOut" }}
            />
          ))}
        </span>
      )}
    </motion.button>
  );
}

export function SimBadge({ value }: { value: number }) {
  const { t } = useI18n();
  const pct = Math.round(value * 100);
  return (
    <div className="hidden w-[86px] shrink-0 items-center gap-2 sm:flex" title={t("Похожесть по звучанию")}>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink/10">
        <motion.div className="h-full rounded-full bg-gradient-to-r from-vio to-acid" initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8 }} />
      </div>
      <span className="w-8 text-right text-xs font-bold tabular-nums text-ink2">{pct}%</span>
    </div>
  );
}

export function TrackRow({ t, queue, index, sim, className }: { t: Track; queue?: string[]; index?: number; sim?: number; className?: string }) {
  const { t: tx } = useI18n();
  const active = useStore((s) => s.currentId === t.id);
  const isPlaying = useStore((s) => s.isPlaying);
  const playTrack = useStore((s) => s.playTrack);
  const togglePlay = useStore((s) => s.togglePlay);
  const play = () => (active ? togglePlay() : playTrack(t.id, queue));
  return (
    <motion.div
      layout="position"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      onDoubleClick={play}
      className={cn("group flex items-center gap-3 rounded-[22px] p-2 pr-3 transition-colors hover:bg-ink/[0.05]", active && "bg-vio/10", className)}
    >
      {index != null && <span className="w-7 shrink-0 text-center font-display text-sm font-bold text-ink3">{index}</span>}
      <button onClick={play} className="relative h-12 w-12 shrink-0 overflow-hidden rounded-[16px] shadow-md" aria-label={tx("Играть")}>
        <Cover t={t} />
        <span className={cn("absolute inset-0 grid place-items-center bg-black/45 text-white opacity-0 transition-opacity group-hover:opacity-100", active && "opacity-100")}>
          {active ? <MiniEq on={isPlaying} /> : <Play className="h-4 w-4 fill-white" />}
        </span>
      </button>
      <div className="min-w-0 flex-1 cursor-default" onClick={play}>
        <div className={cn("truncate text-[15px] font-bold", active && "text-grad")}>{t.title}</div>
        <div className="truncate text-xs text-ink3">
          {t.artist} · {tx(GENRES[t.genre].label)}
          {t.source === "upload" && <span className="ml-1.5 rounded-full bg-acid/20 px-1.5 py-px text-[10px] font-bold text-acidink">{tx("сообщество")}</span>}
          {t.studio && <span className="ml-1.5 rounded-full bg-vio/15 px-1.5 py-px text-[10px] font-bold text-vio">{tx("Студия")}</span>}
        </div>
      </div>
      {sim != null && <SimBadge value={sim} />}
      <LikeButton id={t.id} />
      <span className="hidden w-10 shrink-0 text-right text-xs tabular-nums text-ink3 sm:block">{fmtTime(t.duration)}</span>
    </motion.div>
  );
}

/** 2.5D card: glyph-shape base + tilted cover on top + title / small artist below */
export function ShapeCard({
  cover,
  title,
  sub,
  hue,
  shape,
  active,
  playing,
  onPlay,
  className,
}: {
  cover: CoverSrc;
  title: string;
  sub: string;
  hue: number;
  shape: number;
  active: boolean;
  playing: boolean;
  onPlay: () => void;
  className?: string;
}) {
  const tilt = useRef<HTMLDivElement>(null);
  const onMove = (e: React.MouseEvent) => {
    const el = tilt.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `rotateX(${(-y * 16).toFixed(2)}deg) rotateY(${(x * 18).toFixed(2)}deg)`;
    el.style.setProperty("--mx", `${(x + 0.5) * 100}%`);
    el.style.setProperty("--my", `${(y + 0.5) * 100}%`);
  };
  const onLeave = () => {
    if (tilt.current) tilt.current.style.transform = "";
  };
  return (
    <motion.div whileTap={{ scale: 0.97 }} onClick={onPlay} className={cn("group w-[176px] shrink-0 cursor-pointer snap-start select-none sm:w-[196px]", className)}>
      <div className="relative aspect-square" style={{ perspective: 900 }} onMouseMove={onMove} onMouseLeave={onLeave}>
        <div ref={tilt} className="tilt relative h-full w-full">
          <div className="absolute -inset-[8%]" style={{ transform: "translateZ(0px)" }}>
            <GlyphBlob shape={shape} hue={hue} active={active && playing} />
          </div>
          <div
            className="absolute left-1/2 top-1/2 aspect-square w-[60%] transition-transform duration-500 group-hover:scale-[1.04]"
            style={{ transform: `translate(-50%, -54%) translateZ(48px) rotate(${active ? -2 : -6}deg)` }}
          >
            <div className="relative h-full w-full overflow-hidden rounded-[24px] shadow-[0_22px_40px_-12px_rgba(0,0,0,0.6)] ring-1 ring-white/15">
              <Cover t={cover} spin={active && playing} />
              <div className="shine pointer-events-none absolute inset-0 opacity-0 transition-opacity group-hover:opacity-100" />
              <div className={cn("absolute inset-0 grid place-items-center bg-black/35 opacity-0 transition-opacity group-hover:opacity-100", active && "opacity-100 bg-black/25")}>
                <span className="grid h-12 w-12 place-items-center rounded-full bg-white/90 text-[#120c1f] shadow-lg">
                  {active && playing ? <MiniEq on /> : <Play className="h-5 w-5 translate-x-[1px] fill-current" />}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-1 px-1 text-center">
        <div className={cn("truncate text-[15px] font-extrabold leading-tight", active && "text-grad")}>{title}</div>
        <div className="mt-0.5 truncate text-xs text-ink3">{sub}</div>
      </div>
    </motion.div>
  );
}

export function Shelf({ title, sub, children, right }: { title: string; sub?: string; children: ReactNode; right?: ReactNode }) {
  const { t } = useI18n();
  const ref = useRef<HTMLDivElement>(null);
  return (
    <section>
      <div className="mb-1 flex items-end justify-between gap-4 px-1">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight sm:text-[30px]">{t(title)}</h2>
          {sub && <p className="mt-1 text-sm text-ink3">{t(sub)}</p>}
        </div>
        <div className="flex items-center gap-2">
          {right}
          <div className="hidden gap-2 sm:flex">
            <IconBtn title="Назад" onClick={() => ref.current?.scrollBy({ left: -520, behavior: "smooth" })}>
              <ChevronLeft className="h-5 w-5" />
            </IconBtn>
            <IconBtn title="Вперёд" onClick={() => ref.current?.scrollBy({ left: 520, behavior: "smooth" })}>
              <ChevronRight className="h-5 w-5" />
            </IconBtn>
          </div>
        </div>
      </div>
      <div ref={ref} className="no-scrollbar -mx-3 flex snap-x gap-4 overflow-x-auto px-3 pb-4 pt-6 sm:gap-6">
        {children}
      </div>
    </section>
  );
}

export function PageTitle({ title, sub, accent }: { title: string; sub?: ReactNode; accent?: string }) {
  const { t } = useI18n();
  return (
    <header className="relative">
      <motion.h1
        initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-[clamp(36px,6vw,72px)] font-black leading-[0.95] tracking-[-0.035em]"
      >
        {t(title)}
        {accent && <span className="text-grad"> {t(accent)}</span>}
      </motion.h1>
      {sub && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="mt-3 max-w-2xl text-[15px] text-ink2">
          {typeof sub === "string" ? t(sub) : sub}
        </motion.p>
      )}
    </header>
  );
}
