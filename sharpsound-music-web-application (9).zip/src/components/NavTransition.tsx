import { AnimatePresence, motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { create } from "zustand";
import { roundRectPath, SandScene, type Region } from "../lib/sand";
import { cn } from "../utils/cn";

const RISE_MS = 520;
const FILL_MS = 980;
const FALL_MS = 640;
const TOTAL = RISE_MS + FILL_MS + FALL_MS;

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface NavMeta {
  id: string;
  icon: LucideIcon;
  label: string;
  compact: boolean;
}

type Phase = "rise" | "fill" | "fall";

interface NavTransitionState {
  active: boolean;
  phase: Phase;
  liftedId: string | null;
  from: Rect | null;
  slot: Rect | null;
  meta: NavMeta | null;
  region: Region | null;
  source: { x: number; y: number } | null;
  onCovered: (() => void) | null;
  el: HTMLElement | null;
  run: (el: HTMLElement, meta: NavMeta, onCovered: () => void) => void;
  advance: (phase: Phase) => void;
  finish: () => void;
}

const easeInOutQuad = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
const easeInQuad = (t: number) => t * t;

function computeRegion(): Region {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  let x0 = 0;
  let y0 = 0;
  let x1 = vw;
  let y1 = vh;
  const gap = 10;
  document.querySelectorAll<HTMLElement>("[data-nav-menu]").forEach((node) => {
    const r = node.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return;
    if (r.left <= 40 && r.top <= 40 && r.height >= vh - 90) x0 = Math.max(x0, r.right);
    else if (r.top <= 40 && r.left <= 40 && r.right >= vw - 40) y0 = Math.max(y0, r.bottom);
    else if (r.bottom >= vh - 40 && r.left <= 40 && r.right >= vw - 40) y1 = Math.min(y1, r.top);
    else if (r.right >= vw - 40) x1 = Math.min(x1, r.left);
  });
  x0 = Math.min(x0 + gap, vw - 60);
  y0 = Math.min(y0 + gap, vh - 60);
  x1 = Math.max(x1 - gap, x0 + 60);
  y1 = Math.max(y1 - gap, y0 + 60);
  return { x0, y0, x1, y1 };
}

function findSlot(): Rect | null {
  for (const n of document.querySelectorAll<HTMLElement>("[data-nav-slot-anchor]")) {
    const r = n.getBoundingClientRect();
    if (r.width > 10 && r.height > 10) return { x: r.left, y: r.top, w: r.width, h: r.height };
  }
  return null;
}

export const useNavTransition = create<NavTransitionState>((set, get) => ({
  active: false,
  phase: "rise",
  liftedId: null,
  from: null,
  slot: null,
  meta: null,
  region: null,
  source: null,
  onCovered: null,
  el: null,

  run: (el, meta, onCovered) => {
    if (get().active) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      onCovered();
      return;
    }
    const slot = findSlot();
    if (!slot) {
      onCovered();
      return;
    }
    const fromRect = el.getBoundingClientRect();
    const region = computeRegion();
    const source = {
      x: Math.max(region.x0 + 20, slot.x + slot.w * 0.8),
      y: Math.min(region.y1 - 10, slot.y + slot.h - 6),
    };
    el.style.opacity = "0";
    set({
      active: true,
      phase: "rise",
      liftedId: meta.id,
      from: { x: fromRect.left, y: fromRect.top, w: fromRect.width, h: fromRect.height },
      slot,
      meta,
      region,
      source,
      onCovered,
      el,
    });
  },

  advance: (phase) => set({ phase }),

  finish: () => {
    const st = get();
    st.el?.style.removeProperty("opacity");
    set({ active: false, phase: "rise", liftedId: null, from: null, slot: null, meta: null, region: null, source: null, onCovered: null, el: null });
  },
}));

export function navTo(el: HTMLElement, action: () => void, meta: NavMeta) {
  useNavTransition.getState().run(el, meta, action);
}

/** Placeholder that opens in the nav so the lifted button has a slot between the logo and the first item. */
export function NavPlaceholder({ compact }: { compact: boolean }) {
  const phase = useNavTransition((s) => s.phase);
  const [v, setV] = useState(0);
  const open = phase === "rise" || phase === "fill";
  const target = compact ? 52 : 50;
  useEffect(() => {
    const r = requestAnimationFrame(() => setV(open ? target : 0));
    return () => cancelAnimationFrame(r);
  }, [open, target]);
  const axis = compact ? "width" : "height";
  return (
    <div aria-hidden className="overflow-hidden" style={{ [axis]: v, transition: `${axis} ${open ? RISE_MS : FALL_MS}ms cubic-bezier(.22,1,.36,1)` }}>
      {compact ? (
        <div className="h-full w-[52px]" />
      ) : (
        <div className="flex items-center rounded-[22px] px-3 py-3.5">
          <span className="block h-[22px]" />
        </div>
      )}
    </div>
  );
}

export default function NavTransition() {
  const { active, phase, from, slot, meta, region, source } = useNavTransition();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active) return;
    const timers = [
      window.setTimeout(() => useNavTransition.getState().advance("fill"), RISE_MS),
      window.setTimeout(() => {
        const st = useNavTransition.getState();
        st.el?.style.removeProperty("opacity");
        st.onCovered?.();
      }, RISE_MS + FILL_MS - 160),
      window.setTimeout(() => useNavTransition.getState().advance("fall"), RISE_MS + FILL_MS),
      window.setTimeout(() => useNavTransition.getState().finish(), TOTAL),
    ];
    return () => timers.forEach((t) => clearTimeout(t));
  }, [active]);

  useEffect(() => {
    if (!active || !region || !source) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const resize = () => {
      const k = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.round(window.innerWidth * k));
      canvas.height = Math.max(1, Math.round(window.innerHeight * k));
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.setTransform(k, 0, 0, k, 0, 0);
    };
    resize();
    const scene = new SandScene(region, source);
    let raf = 0;
    let last = performance.now();
    const start = last;
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const el = now - start;
      const fillP = Math.max(0, Math.min(1, (el - RISE_MS) / FILL_MS));
      const fallP = Math.max(0, Math.min(1, (el - RISE_MS - FILL_MS) / FALL_MS));
      const level = easeInOutQuad(fillP);
      const fallY = easeInQuad(fallP) * (region.y1 - region.y0 + 320);
      const pouring = el < RISE_MS + FILL_MS * 0.9;
      scene.update(dt, level, pouring, fallP > 0);
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      ctx.save();
      roundRectPath(ctx, region, 30);
      ctx.clip();
      scene.draw(ctx, level, fallY);
      ctx.restore();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, region, source]);

  return createPortal(
    <AnimatePresence>
      {active && from && slot && meta && (
        <motion.div
          key="nav-transition"
          className="pointer-events-none fixed inset-0 z-[120]"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
        >
          <canvas ref={canvasRef} className="absolute inset-0" />

          {/* the lifted nav button: slides into the slot under the logo, then falls back */}
          <motion.div
            className="absolute left-0 top-0"
            style={{ width: from.w, height: from.h }}
            initial={{ x: from.x, y: from.y, rotate: 0, scale: 1 }}
            animate={
              phase === "fall"
                ? { x: from.x, y: from.y, rotate: 0, scale: 1 }
                : { x: slot.x, y: slot.y, rotate: -2, scale: 1.03 }
            }
            transition={
              phase === "fall"
                ? { duration: FALL_MS / 1000, ease: [0.55, 0, 0.85, 0.55] }
                : { duration: RISE_MS / 1000, ease: [0.22, 1, 0.36, 1] }
            }
          >
            <div
              className={cn(
                "glass-strong shadow-deep h-full w-full border-vio/50",
                meta.compact ? "flex flex-col items-center justify-center gap-0.5 rounded-[20px]" : "flex items-center justify-center gap-3 rounded-[22px] px-3 lg:justify-start",
                phase === "fill" && "grad-border"
              )}
              style={phase === "fill" ? { boxShadow: "0 0 40px -4px rgba(139,92,246,0.55), 0 18px 40px -12px rgba(109,40,217,0.5)" } : undefined}
            >
              <meta.icon className={cn("shrink-0 text-vio", meta.compact ? "h-5 w-5" : "h-[22px] w-[22px]")} />
              <span className={cn("min-w-0", meta.compact ? "max-w-full truncate text-[9px] font-bold" : "hidden min-w-0 flex-1 truncate text-[13px] font-bold leading-snug lg:inline")}>
                {meta.label}
              </span>
              {phase === "fill" && <span className="blink-dot h-1.5 w-1.5 shrink-0 rounded-full bg-acid shadow-[0_0_10px_var(--acid)]" />}
            </div>
          </motion.div>

          {/* glow where the sand pours out of the lifted button */}
          <motion.div
            className="absolute rounded-full"
            style={{ left: source ? source.x - 30 : 0, top: source ? source.y - 30 : 0, width: 60, height: 60 }}
            initial={{ opacity: 0, scale: 0.4 }}
            animate={{ opacity: phase === "fall" ? 0 : [0.2, 0.6, 0.3], scale: phase === "fall" ? 1.8 : 1 }}
            transition={{ duration: 0.9, repeat: phase === "fall" ? 0 : Infinity }}
          >
            <div className="h-full w-full rounded-full bg-[radial-gradient(circle,rgba(233,213,255,0.95),rgba(180,240,60,0.45)_45%,transparent_70%)] blur-md" />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
