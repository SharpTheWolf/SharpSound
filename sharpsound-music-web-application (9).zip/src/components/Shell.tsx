import { AnimatePresence, motion } from "framer-motion";
import { AudioLines, AudioWaveform, Download, Gamepad2, House, Languages, Library, MessagesSquare, Moon, Search, Shirt, Sun, Upload, X } from "lucide-react";
import { useEffect, useRef, useState, type MouseEvent } from "react";
import { flushSync } from "react-dom";
import { engine } from "../audio/engine";
import { useStore, type Tab } from "../store";
import { cn } from "../utils/cn";
import { ChibiHead, OUTFITS } from "./Chibi";
import { downloadPng, downloadSvg, Logo } from "./Logo";
import { NavPlaceholder, navTo, useNavTransition } from "./NavTransition";
import { Cube3D } from "./Visuals";
import { translate, useI18n, useLocale } from "../lib/i18n";

export const NAV: { id: Tab; label: string; icon: typeof Search }[] = [
  { id: "search", label: "Поиск", icon: Search },
  { id: "home", label: "Главная", icon: House },
  { id: "recognize", label: "Распознать", icon: AudioLines },
  { id: "collection", label: "Коллекция", icon: Library },
  { id: "contribute", label: "Вклад в сообщество", icon: Upload },
  { id: "community", label: "Сообщество", icon: MessagesSquare },
  { id: "studio", label: "Мини-студия", icon: AudioWaveform },
];

type VTDoc = Document & { startViewTransition?: (cb: () => void) => { ready: Promise<void> } };

export function switchTheme(e?: MouseEvent) {
  const st = useStore.getState();
  const next = st.theme === "dark" ? "light" : "dark";
  const x = e?.clientX ?? window.innerWidth / 2;
  const y = e?.clientY ?? 60;
  const apply = () => {
    useStore.getState().setTheme(next);
    useStore.getState().chibi("theme");
  };
  const d = document as VTDoc;
  if (!d.startViewTransition || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    apply();
    return;
  }
  const tr = d.startViewTransition(() => flushSync(apply));
  tr.ready
    .then(() => {
      const r = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));
      document.documentElement.animate(
        { clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${r}px at ${x}px ${y}px)`] },
        { duration: 760, easing: "cubic-bezier(.65,0,.35,1)", pseudoElement: "::view-transition-new(root)" }
      );
    })
    .catch(() => {});
}

function SummonButton({ compact }: { compact?: boolean }) {
  const { t, text, tr } = useI18n();
  const away = useStore((s) => s.chibiAway);
  const outfitId = useStore((s) => s.chibiOutfit);
  const setOutfit = useStore((s) => s.setChibiOutfit);
  const chibiOutfit = OUTFITS.find((o) => o.id === outfitId) ?? OUTFITS[0];
  const [wardrobe, setWardrobe] = useState(false);
  const onClick = () => {
    const st = useStore.getState();
    if (st.chibiAway) st.setChibiAway(false);
    else st.chibi("say", translate("Я тут! Гуляю по плееру."));
  };
  const choose = (id: string) => {
    setOutfit(id);
    setWardrobe(false);
    const fit = OUTFITS.find((o) => o.id === id) ?? OUTFITS[0];
    useStore.getState().chibi("say", translate("Новый наряд. Старый вкус.") + ` ${text(fit.name)}`);
  };

  return (
    <div className={cn("relative flex min-w-0 items-center gap-1", compact ? "w-auto" : "w-full")}>
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={onClick}
        title={t(away ? "Позвать помощника" : "Помощник рядом")}
        className={cn("group relative flex min-w-0 flex-1 items-center gap-3 rounded-[24px] p-1.5 text-left transition-colors hover:bg-ink/[0.05]", compact && "flex-none")}
      >
        <div className={cn("relative grid shrink-0 place-items-center overflow-hidden rounded-[18px] bg-gradient-to-br from-[#7c3aed]/35 to-[#b4f03c]/25 ring-1 ring-vio/30", compact ? "h-9 w-9" : "h-[50px] w-[50px]", away && "ring-2 ring-acid")}>
          <div className="translate-y-[3px] transition-transform duration-300 group-hover:-translate-y-0.5"><ChibiHead scale={compact ? 2 : 2.6} away={away} outfit={chibiOutfit} /></div>
          {away && <span className="ring-out absolute inset-0 rounded-[18px] border-2 border-acid" />}
        </div>
        {!compact && <div className="hidden min-w-0 lg:block"><div className="truncate font-display text-[13px] font-bold">{t(away ? "Позвать помощника" : "Помощник рядом")}</div><div className="flex items-center gap-1.5 text-xs text-ink3"><span className={cn("h-1.5 w-1.5 rounded-full", away ? "blink-dot bg-amber-400" : "bg-acid")} />{t(away ? "ушёл гулять" : "слушает с тобой")}</div></div>}
      </motion.button>
      <button type="button" onClick={() => setWardrobe((v) => !v)} aria-expanded={wardrobe} aria-label={tr("Выбрать скин помощника", "Choose companion skin")} title={tr("Скины компаньона", "Companion skins")} className={cn("absolute z-10 grid h-6 w-6 place-items-center rounded-full border border-vio/30 bg-panel-strong text-vio shadow-md transition-all hover:scale-110 hover:bg-vio hover:text-white", compact ? "left-[27px] top-[25px]" : "left-[39px] top-[39px]")}>
        <Shirt className="h-3 w-3" />
      </button>
      <AnimatePresence>
        {wardrobe && <motion.div initial={{ opacity: 0, y: -8, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -5 }} className="glass-strong shadow-deep absolute left-0 top-full z-[85] mt-2 w-[276px] rounded-[26px] p-4 sm:left-auto sm:right-0 md:left-full md:top-0 md:ml-3 md:mt-0">
          <div className="mb-3 flex items-center gap-2"><Gamepad2 className="h-4 w-4 text-vio" /><div><div className="font-display text-sm font-bold">{tr("Наряды", "Outfits")}</div><div className="text-[10px] text-ink3">{tr("Сменить образ", "Change the look")}</div></div></div>
          <div className="grid grid-cols-3 gap-2">{OUTFITS.map((fit) => <button key={fit.id} onClick={() => choose(fit.id)} className={cn("relative flex min-w-0 flex-col items-center gap-1.5 rounded-[16px] p-2 text-center transition-colors hover:bg-ink/5", fit.id === outfitId && "bg-vio/10 ring-1 ring-vio/40")}><span className="grid h-10 w-10 place-items-center overflow-hidden rounded-[12px] bg-gradient-to-br from-vio/25 to-acid/20"><ChibiHead scale={1.9} outfit={fit} /></span><span className="max-w-full truncate text-[10px] font-bold">{text(fit.name)}</span>{fit.id === outfitId && <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-acid" />}</button>)}</div>
          {outfitId === "gamer" && <div className="mt-3 flex items-center justify-center gap-2 rounded-full bg-vio/10 px-3 py-2 text-[10px] font-bold text-ink2"><span className="rgb-mini h-3 w-5 rounded-full" />RGB {tr("подсветка активна", "lighting active")}</div>}
        </motion.div>}
      </AnimatePresence>
    </div>
  );
}

function IconCard({ compact }: { compact?: boolean }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: globalThis.MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", close);
    return () => window.removeEventListener("mousedown", close);
  }, [open]);
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((v) => !v)} className="group flex w-full items-center gap-3 rounded-[24px] p-1.5 text-left transition-colors hover:bg-ink/[0.05]" title={t("Иконка SharpSound")}>
        <span data-nav-logo className="inline-flex shrink-0">
          <Logo size={compact ? 36 : 50} className="drop-shadow-[0_8px_18px_rgba(124,58,237,0.45)] transition-transform duration-500 group-hover:rotate-[-8deg] group-hover:scale-105" />
        </span>
        {!compact && (
          <div className="hidden lg:block">
            <div className="font-display text-[17px] font-extrabold leading-none tracking-tight">
              Sharp<span className="text-grad">Sound</span>
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-ink3">
              <Download className="h-3 w-3" /> {t("иконка приложения")}
            </div>
          </div>
        )}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, x: -12, scale: 0.96, filter: "blur(6px)" }}
            animate={{ opacity: 1, x: 0, scale: 1, filter: "blur(0px)" }}
            exit={{ opacity: 0, x: -8, scale: 0.97, filter: "blur(4px)" }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="glass-strong shadow-deep absolute left-0 top-full z-[70] mt-2 w-[290px] rounded-[30px] p-5 md:left-full md:top-0 md:ml-4 md:mt-0"
          >
            <button onClick={() => setOpen(false)} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full hover:bg-ink/10" aria-label={t("Закрыть")}>
              <X className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-4">
              <Logo size={84} className="wobble-in drop-shadow-[0_14px_28px_rgba(124,58,237,0.5)]" />
              <div>
                <div className="font-display text-base font-bold">{t("Иконка")}</div>
                <div className="text-xs text-ink3">{t("для ярлыка, exe и рабочего стола")}</div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2">
              <button onClick={downloadSvg} className="btn-soft rounded-[16px] py-2.5 text-xs font-bold">SVG</button>
              <button onClick={() => downloadPng(512)} className="btn-soft rounded-[16px] py-2.5 text-xs font-bold">PNG 512</button>
              <button onClick={() => downloadPng(1024)} className="btn-grad rounded-[16px] py-2.5 text-xs font-bold">PNG 1024</button>
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-ink3">
              {t("Файл уже лежит в проекте:")} <code className="rounded bg-ink/10 px-1 py-px text-ink2">public/sharpsound-icon.svg</code>
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ThemeToggle({ compact }: { compact?: boolean }) {
  const { t } = useI18n();
  const theme = useStore((s) => s.theme);
  return (
    <button
      onClick={(e) => switchTheme(e)}
      className={cn("relative flex h-11 items-center rounded-full btn-soft p-1", compact ? "w-[64px]" : "w-full")}
      aria-label={t("Сменить тему")}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 34 }}
        className={cn("absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-full bg-gradient-to-br from-vio to-[#c084fc] shadow-lg", theme === "dark" ? "left-1" : "left-[50%]")}
      />
      <span className={cn("relative z-10 flex flex-1 items-center justify-center gap-1.5 text-xs font-bold", theme === "dark" ? "text-white" : "text-ink3")}>
        <Moon className="h-4 w-4" />
        {!compact && <span className="hidden lg:inline">{t("Тьма")}</span>}
      </span>
      <span className={cn("relative z-10 flex flex-1 items-center justify-center gap-1.5 text-xs font-bold", theme === "light" ? "text-white" : "text-ink3")}>
        <Sun className="h-4 w-4" />
        {!compact && <span className="hidden lg:inline">{t("Свет")}</span>}
      </span>
    </button>
  );
}

function LanguageToggle({ compact }: { compact?: boolean }) {
  const { lang, tr } = useI18n();
  const setLang = useLocale((s) => s.setLang);
  const change = (next: "ru" | "en") => {
    if (next === lang) return;
    setLang(next);
    useStore.getState().chibi("language");
  };
  if (compact) return (
    <motion.button whileTap={{ scale: 0.9 }} onClick={() => change(lang === "ru" ? "en" : "ru")} className="btn-soft grid h-11 w-10 shrink-0 place-items-center rounded-full text-xs font-extrabold" title={tr("Switch to English", "Переключить на русский")} aria-label={tr("Switch to English", "Переключить на русский")}>
      <AnimatePresence mode="wait" initial={false}><motion.span key={lang} initial={{ y: 5, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -5, opacity: 0 }}>{lang.toUpperCase()}</motion.span></AnimatePresence>
    </motion.button>
  );
  return (
    <div className="flex h-10 items-center justify-center gap-0.5 rounded-full border border-line px-1 lg:gap-2 lg:px-3" aria-label={tr("Язык интерфейса", "Interface language")}>
      <Languages className="hidden h-4 w-4 shrink-0 text-ink3 lg:block" />
      <span className="hidden flex-1 text-xs text-ink3 lg:block">{tr("Язык", "Language")}</span>
      {(["ru", "en"] as const).map((l) => <button key={l} onClick={() => change(l)} aria-pressed={lang === l} className={cn("relative rounded-full px-1.5 py-1 text-[11px] font-extrabold lg:px-2", lang === l ? "text-white" : "text-ink3")}>
        {lang === l && <motion.span layoutId="language-pill" className="absolute inset-0 rounded-full bg-vio" transition={{ type: "spring", stiffness: 450, damping: 32 }} />}
        <span className="relative">{l.toUpperCase()}</span>
      </button>)}
    </div>
  );
}

export function Sidebar() {
  const { t } = useI18n();
  const tab = useStore((s) => s.tab);
  const setTab = useStore((s) => s.setTab);
  const liftedId = useNavTransition((s) => s.liftedId);
  return (
    <aside data-nav-menu className="glass-strong shadow-deep fixed bottom-4 left-4 top-4 z-50 hidden w-[92px] flex-col rounded-[34px] p-3 md:flex lg:w-[256px] lg:p-4">
      <SummonButton />
      <div className="mt-2">
        <IconCard />
      </div>
      <div className="mx-2 my-4 h-px bg-line" />
      <nav className="no-scrollbar flex min-h-0 flex-col gap-1.5 overflow-y-auto py-1">
        {liftedId && <NavPlaceholder compact={false} />}
        {NAV.map((n, i) => {
          const active = tab === n.id;
          const Icon = n.icon;
          return (
            <button
              key={n.id}
              onClick={(e) => {
                if (active) return;
                navTo(e.currentTarget, () => setTab(n.id), { id: n.id, icon: n.icon, label: t(n.label), compact: false });
              }}
              title={t(n.label)}
              aria-current={active ? "page" : undefined}
              data-nav-slot-anchor={i === 0 ? "" : undefined}
              className={cn(
                "nav-btn group relative flex items-center justify-center gap-3 rounded-[22px] px-3 py-3.5 text-[15px] font-bold transition-colors lg:justify-start",
                liftedId === n.id && "nav-collapsed",
                active ? "text-ink" : "text-ink3 hover:text-ink"
              )}
            >
              {active && (
                <motion.span
                  layoutId="navpill"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  className="absolute inset-0 rounded-[22px] bg-gradient-to-r from-vio/25 via-vio/10 to-acid/10 ring-1 ring-vio/35"
                />
              )}
              <Icon className={cn("relative h-[22px] w-[22px] shrink-0 transition-transform duration-300 group-hover:scale-110", active && "text-vio")} />
              <span className="relative hidden min-w-0 flex-1 text-[13px] leading-snug lg:inline">{t(n.label)}</span>
              {active && <span className="relative ml-auto hidden h-1.5 w-1.5 shrink-0 rounded-full bg-acid shadow-[0_0_10px_var(--acid)] lg:block" />}
            </button>
          );
        })}
      </nav>
      <div className="mt-auto space-y-2 pt-4">
        <div className="sidebar-art relative hidden h-[90px] overflow-hidden rounded-[26px] border border-line lg:block">
          <div className="grid-fine absolute inset-0 opacity-70" />
          <Cube3D size={56} className="absolute left-5 top-8" />
          <div className="absolute right-4 top-4 text-right">
            <div className="font-display text-[11px] font-bold uppercase tracking-[0.2em] text-ink3">2.5D</div>
            <div className="font-display text-sm font-bold">{t("звук в клетку")}</div>
          </div>
        </div>
        <ThemeToggle />
        <LanguageToggle />
      </div>
    </aside>
  );
}

export function MobileTop() {
  return (
    <div data-nav-menu className="glass-strong fixed left-3 right-3 top-3 z-50 flex items-center gap-2 rounded-[26px] p-1.5 pr-2 md:hidden">
      <SummonButton compact />
      <IconCard compact />
      <div className="min-w-0 flex-1 truncate font-display text-[12px] font-extrabold tracking-tight sm:text-[15px]">
        Sharp<span className="text-grad">Sound</span>
      </div>
      <LanguageToggle compact />
      <div className="ml-auto">
        <ThemeToggle compact />
      </div>
    </div>
  );
}

export function MobileNav() {
  const { t, tr } = useI18n();
  const tab = useStore((s) => s.tab);
  const setTab = useStore((s) => s.setTab);
  const liftedId = useNavTransition((s) => s.liftedId);
  return (
    <nav data-nav-menu className="glass-strong shadow-deep fixed bottom-3 left-3 right-3 z-50 flex h-[64px] items-center justify-around gap-1 rounded-[26px] px-1 md:hidden">
      {liftedId && <NavPlaceholder compact />}
      {NAV.map((n, i) => {
        const active = tab === n.id;
        const Icon = n.icon;
        return (
          <button
            key={n.id}
            onClick={(e) => { if (!active) navTo(e.currentTarget, () => setTab(n.id), { id: n.id, icon: n.icon, label: n.id === "contribute" ? tr("Вклад", "Contribute") : t(n.label), compact: true }); }}
            className={cn("nav-btn relative flex h-[52px] min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-[20px]", liftedId === n.id && "nav-collapsed")}
            aria-label={t(n.label)}
            aria-current={active ? "page" : undefined}
            data-nav-slot-anchor={i === 0 ? "" : undefined}
          >
            {active && <motion.span layoutId="mnavpill" className="absolute inset-1 rounded-[18px] bg-vio/20 ring-1 ring-vio/30" transition={{ type: "spring", stiffness: 420, damping: 34 }} />}
            <Icon className={cn("relative h-5 w-5", active ? "text-vio" : "text-ink3")} />
            <span className={cn("relative max-w-full truncate text-[9px] font-bold", active ? "text-ink" : "text-ink3")}>{n.id === "contribute" ? tr("Вклад", "Contribute") : t(n.label)}</span>
          </button>
        );
      })}
    </nav>
  );
}

export function Backdrop() {
  const floor = useRef<HTMLDivElement>(null);
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let raf = 0;
    let off = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const b = engine.bands();
      off += dt * (10 + (engine.playing ? 34 + b.level * 160 : 0));
      if (floor.current) floor.current.style.backgroundPosition = `0 ${off.toFixed(1)}px`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const onMove = (e: globalThis.MouseEvent) => {
      const el = root.current;
      if (!el) return;
      el.style.setProperty("--px", ((e.clientX / window.innerWidth - 0.5) * 2).toFixed(3));
      el.style.setProperty("--py", ((e.clientY / window.innerHeight - 0.5) * 2).toFixed(3));
    };
    window.addEventListener("mousemove", onMove);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
    };
  }, []);
  const par = (k: number) => ({ transform: `translate(calc(var(--px, 0) * ${k}px), calc(var(--py, 0) * ${k}px))`, transition: "transform .6s cubic-bezier(.22,1,.36,1)" });
  return (
    <div ref={root} className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden>
      <div className="grid-bg absolute inset-0" />
      <div className="animate-drift absolute -right-[12%] -top-[22%] h-[62vw] w-[62vw] rounded-full" style={{ background: "radial-gradient(circle, var(--glow-a), transparent 62%)" }} />
      <div className="animate-drift-2 absolute -bottom-[28%] -left-[12%] h-[56vw] w-[56vw] rounded-full" style={{ background: "radial-gradient(circle, var(--glow-b), transparent 62%)" }} />
      <div className="absolute inset-x-0 bottom-0 h-[58vh] overflow-hidden opacity-80">
        <div ref={floor} className="floor" />
      </div>
      <div className="absolute right-[6%] top-[14%] opacity-40" style={par(-18)}>
        <Cube3D size={64} className="animate-float" />
      </div>
      <div className="absolute bottom-[32%] right-[3%] h-24 w-24 rounded-full opacity-50" style={par(26)}>
        <div className="animate-float-2 h-full w-full rounded-full" style={{ background: "radial-gradient(circle at 32% 28%, #fff 0%, #c4b5fd 14%, #7c3aed 52%, #1e0b46 100%)", boxShadow: "0 30px 60px -20px rgba(124,58,237,.6)" }} />
      </div>
      <div className="absolute left-[38%] top-[6%] h-40 w-40 opacity-30" style={par(12)}>
        <div className="animate-spin-slow h-full w-full rounded-full border border-dashed border-vio" />
      </div>
      <div className="noise absolute inset-0 opacity-[0.07] mix-blend-overlay" />
    </div>
  );
}

export function Toast() {
  const msg = useStore((s) => s.toastMsg);
  const [shown, setShown] = useState<typeof msg>(null);
  useEffect(() => {
    if (!msg) return;
    setShown(msg);
    const t = setTimeout(() => setShown(null), 2800);
    return () => clearTimeout(t);
  }, [msg]);
  return (
    <div className="pointer-events-none fixed inset-x-0 top-20 z-[80] flex justify-center md:top-6">
      <AnimatePresence>
        {shown && (
          <motion.div
            key={shown.ts}
            initial={{ opacity: 0, y: -16, scale: 0.95, filter: "blur(6px)" }}
            animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -10, scale: 0.97 }}
            className="glass-strong shadow-deep rounded-full px-5 py-3 text-sm font-bold"
          >
            {shown.text}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
