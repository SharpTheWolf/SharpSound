import { memo, useEffect, useId, useMemo, useRef } from "react";
import { engine, type Bands } from "../audio/engine";
import { GLYPHS } from "../data/catalog";
import { cn } from "../utils/cn";

const ZERO: Bands = { bass: 0, mid: 0, high: 0, level: 0 };

function smooth(p: [number, number][]) {
  const n = p.length;
  let d = `M${p[0][0].toFixed(1)} ${p[0][1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const p0 = p[(i - 1 + n) % n];
    const p1 = p[i];
    const p2 = p[(i + 1) % n];
    const p3 = p[(i + 2) % n];
    d += `C${(p1[0] + (p2[0] - p0[0]) / 6).toFixed(1)} ${(p1[1] + (p2[1] - p0[1]) / 6).toFixed(1)} ${(p2[0] - (p3[0] - p1[0]) / 6).toFixed(1)} ${(
      p2[1] -
      (p3[1] - p1[1]) / 6
    ).toFixed(1)} ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return d + "Z";
}

export function blobPath(shape: number, t: number, b: Bands, amp = 1, R0 = 54) {
  const g = GLYPHS[((shape % GLYPHS.length) + GLYPHS.length) % GLYPHS.length];
  const N = 56;
  const pts: [number, number][] = [];
  const R = R0 * (1 + b.level * 0.14 * amp);
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    let r = 1;
    for (const [k, am, ph] of g) r += am * Math.sin(k * a + ph + t * 0.18 * (k % 2 ? 1 : -1));
    r += amp * (b.bass * 0.16 * Math.sin(2 * a + t * 1.7) + b.mid * 0.1 * Math.sin(5 * a - t * 2.3) + b.high * 0.06 * Math.sin(9 * a + t * 3.1));
    pts.push([100 + Math.cos(a) * R * r, 100 + Math.sin(a) * R * r * 0.94]);
  }
  return smooth(pts);
}

/** Yandex-like soft glyph with 2.5D extrusion, morphs to the music when active */
export const GlyphBlob = memo(function GlyphBlob({
  shape,
  hue,
  active = false,
  className,
  glow = true,
}: {
  shape: number;
  hue: number;
  active?: boolean;
  className?: string;
  glow?: boolean;
}) {
  const id = "g" + useId().replace(/[^a-zA-Z0-9]/g, "");
  const refs = useRef<(SVGPathElement | null)[]>([]);
  const d0 = useMemo(() => blobPath(shape, shape * 1.7, ZERO), [shape]);

  useEffect(() => {
    if (!active) {
      refs.current.forEach((p) => p?.setAttribute("d", d0));
      return;
    }
    let raf = 0;
    let t = shape * 1.7;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const b = engine.bands();
      t += dt * (0.8 + b.level * 3);
      const d = blobPath(shape, t, b, 1.6);
      refs.current.forEach((p) => p?.setAttribute("d", d));
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, shape, d0]);

  const set = (i: number) => (el: SVGPathElement | null) => {
    refs.current[i] = el;
  };

  return (
    <svg viewBox="-20 -20 240 240" className={cn("overflow-visible", !active && "animate-breathe", className)} aria-hidden>
      <defs>
        <linearGradient id={`${id}f`} x1="0.15" y1="0.05" x2="0.85" y2="0.95">
          <stop offset="0" stopColor={`hsl(${hue}, 95%, 80%)`} />
          <stop offset="0.45" stopColor={`hsl(${hue}, 85%, 62%)`} />
          <stop offset="1" stopColor={`hsl(${hue + 14}, 75%, 40%)`} />
        </linearGradient>
        <radialGradient id={`${id}h`} cx="0.36" cy="0.3" r="0.6">
          <stop offset="0" stopColor="#fff" stopOpacity="0.6" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <filter id={`${id}b`} x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="12" />
        </filter>
        <filter id={`${id}s`} x="-10%" y="-10%" width="120%" height="120%">
          <feGaussianBlur stdDeviation="0.9" />
        </filter>
      </defs>
      {glow && <path ref={set(0)} d={d0} fill={`hsl(${hue}, 90%, 58%)`} opacity="0.5" filter={`url(#${id}b)`} transform="translate(4 16)" />}
      <path ref={set(1)} d={d0} fill={`hsl(${hue}, 55%, 16%)`} transform="translate(9 12)" />
      <path ref={set(2)} d={d0} fill={`hsl(${hue}, 60%, 24%)`} transform="translate(6 8)" />
      <path ref={set(3)} d={d0} fill={`hsl(${hue}, 65%, 32%)`} transform="translate(3 4)" />
      <path ref={set(4)} d={d0} fill={`url(#${id}f)`} filter={`url(#${id}s)`} />
      <path ref={set(5)} d={d0} fill={`url(#${id}h)`} transform="translate(100 100) scale(0.8) translate(-106 -108)" />
    </svg>
  );
});
