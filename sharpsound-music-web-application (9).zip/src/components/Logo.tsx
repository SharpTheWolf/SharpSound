export const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512"><defs><linearGradient id="ssBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1e1435"/><stop offset="1" stop-color="#07060c"/></linearGradient><linearGradient id="ssG" gradientUnits="userSpaceOnUse" x1="140" y1="410" x2="380" y2="110"><stop offset="0" stop-color="#7c3aed"/><stop offset="0.5" stop-color="#b794ff"/><stop offset="1" stop-color="#c6f432"/></linearGradient><radialGradient id="ssGlow" cx="0.62" cy="0.36" r="0.6"><stop offset="0" stop-color="#b4f03c" stop-opacity="0.30"/><stop offset="0.45" stop-color="#7c3aed" stop-opacity="0.22"/><stop offset="1" stop-color="#7c3aed" stop-opacity="0"/></radialGradient><pattern id="ssGrid" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M32 0H0V32" fill="none" stroke="#ffffff" stroke-opacity="0.07" stroke-width="1.5"/></pattern><clipPath id="ssClip"><path d="M256 12C440 12 500 72 500 256S440 500 256 500 12 440 12 256 72 12 256 12Z"/></clipPath></defs><g clip-path="url(#ssClip)"><rect width="512" height="512" fill="url(#ssBg)"/><rect width="512" height="512" fill="url(#ssGrid)"/><rect width="512" height="512" fill="url(#ssGlow)"/></g><g fill="none" stroke-linecap="round"><g stroke="#1a0a3d" transform="translate(16 18)"><path d="M214 112V400M304 112V400" stroke-width="42"/><path d="M140 232L372 184M140 340L372 292" stroke-width="56"/></g><g stroke="#2e1065" transform="translate(11 12)"><path d="M214 112V400M304 112V400" stroke-width="42"/><path d="M140 232L372 184M140 340L372 292" stroke-width="56"/></g><g stroke="#4c1d95" transform="translate(5 6)"><path d="M214 112V400M304 112V400" stroke-width="42"/><path d="M140 232L372 184M140 340L372 292" stroke-width="56"/></g><g stroke="url(#ssG)"><path d="M214 112V400M304 112V400" stroke-width="42"/><path d="M140 232L372 184M140 340L372 292" stroke-width="56"/></g></g><path d="M398 88l8 21 21 8-21 8-8 21-8-21-21-8 21-8z" fill="#e2fbb0"/><path d="M256 12C440 12 500 72 500 256S440 500 256 500 12 440 12 256 72 12 256 12Z" fill="none" stroke="#ffffff" stroke-opacity="0.12" stroke-width="2"/></svg>`;

export const ICON_URL = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(ICON_SVG);

export function Logo({ size = 44, className }: { size?: number; className?: string }) {
  return <img src={ICON_URL} width={size} height={size} alt="SharpSound" draggable={false} className={className} />;
}

function trigger(blob: Blob, name: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}

export function downloadSvg() {
  trigger(new Blob([ICON_SVG], { type: "image/svg+xml" }), "sharpsound-icon.svg");
}

export async function downloadPng(size = 1024) {
  const img = new Image();
  img.src = ICON_URL;
  await img.decode();
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  c.getContext("2d")?.drawImage(img, 0, 0, size, size);
  c.toBlob((b) => b && trigger(b, `sharpsound-icon-${size}.png`), "image/png");
}
