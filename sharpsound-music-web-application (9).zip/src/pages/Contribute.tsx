import { AnimatePresence, motion } from "framer-motion";
import { Check, ImagePlus, LoaderCircle, Play, RotateCcw, ShieldCheck, TriangleAlert, Upload, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { decodeBlob, ensureLibrary, featuresFromFP, guessGenre, inspect, keyOf, matchFP, type Inspection } from "../audio/analysis";
import { engine } from "../audio/engine";
import { Cover } from "../components/Cover";
import { GlyphBlob } from "../components/GlyphBlob";
import { PageTitle, ShapeCard, TrackRow } from "../components/ui";
import { fmtTime, GENRES, GENRE_LIST, type CoverStyle, type Genre, type Track } from "../data/catalog";
import { censor } from "../lib/censor";
import { putAudio, removeAudio, saveUploads } from "../lib/db";
import { allTracks, findTrack, useStore } from "../store";
import { cn } from "../utils/cn";
import { translate, useI18n } from "../lib/i18n";

type Step = "file" | "mod" | "form" | "done";
type Status = "wait" | "run" | "ok" | "fail" | "warn";
interface CheckMessage { key: string; vars?: Record<string, string | number> }
interface CheckItem {
  id: string;
  label: string;
  status: Status;
  note?: CheckMessage;
}

const STEPS: { id: Step; label: string }[] = [
  { id: "file", label: "Файл" },
  { id: "mod", label: "Модерация" },
  { id: "form", label: "Оформление" },
  { id: "done", label: "Готово" },
];
const COVER_BY_GENRE: Record<Genre, CoverStyle> = {
  synthwave: "bars", lofi: "blob", phonk: "claws", techno: "iso", ambient: "waves", rock: "ring", trap: "claws", hyperpop: "spiral",
};
const TAGS = ["ночь", "дорога", "спорт", "учёба", "грусть", "радость", "любовь", "дождь", "танцы", "фокус"];

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
const hashStr = (s: string) => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
};
const prettyName = (n: string) => {
  const s = n.replace(/\.[a-z0-9]+$/i, "").replace(/[_]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 60);
  return s ? s[0].toUpperCase() + s.slice(1) : "";
};

async function processCover(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    const s = Math.min(img.width, img.height);
    const c = document.createElement("canvas");
    c.width = 480;
    c.height = 480;
    c.getContext("2d")?.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 480, 480);
    return c.toDataURL("image/jpeg", 0.86);
  } finally {
    URL.revokeObjectURL(url);
  }
}

function Field({ label, value, onChange, placeholder, required, max = 80, area }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; required?: boolean; max?: number; area?: boolean }) {
  const { t: tx } = useI18n();
  const c = censor(value);
  const bad = !c.ok;
  const cls = cn(
    "w-full rounded-[20px] border bg-ink/[0.04] px-4 py-3.5 text-[15px] font-semibold outline-none transition-all placeholder:font-medium placeholder:text-ink3 focus:bg-ink/[0.07]",
    bad ? "border-[#ff5c7a] ring-2 ring-[#ff5c7a]/25" : "border-line focus:border-vio/60 focus:ring-2 focus:ring-vio/20"
  );
  return (
    <label className="block">
      <div className="mb-1.5 flex justify-between px-1 text-xs font-bold text-ink2">
        <span>
          {tx(label)}
          {required && <span className="text-vio"> *</span>}
        </span>
        <span className="tabular-nums text-ink3">
          {value.length}/{max}
        </span>
      </div>
      {area ? (
        <textarea value={value} maxLength={max} onChange={(e) => onChange(e.target.value)} placeholder={tx(placeholder)} rows={3} className={cn(cls, "resize-none")} />
      ) : (
        <input value={value} maxLength={max} onChange={(e) => onChange(e.target.value)} placeholder={tx(placeholder)} className={cls} />
      )}
      <AnimatePresence>
        {bad && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden px-1 pt-1.5 text-xs font-semibold text-[#ff5c7a]">
            {tx("Цензура не пропустит: «{text}». Перефразируй без мата.", { text: c.masked })}
          </motion.div>
        )}
      </AnimatePresence>
    </label>
  );
}

export default function Contribute() {
  const { t: tx } = useI18n();
  const uploads = useStore((s) => s.uploads);
  useStore((s) => s.studioTracks);
  const [step, setStep] = useState<Step>("file");
  const [file, setFile] = useState<File | null>(null);
  const [checks, setChecks] = useState<CheckItem[]>([]);
  const [report, setReport] = useState<Inspection | null>(null);
  const [verdict, setVerdict] = useState<"pending" | "ok" | "fail">("pending");
  const [reason, setReason] = useState<CheckMessage | null>(null);
  const [drag, setDrag] = useState(false);
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [album, setAlbum] = useState("");
  const [desc, setDesc] = useState("");
  const [genre, setGenre] = useState<Genre>("lofi");
  const [guess, setGuess] = useState<Genre | null>(null);
  const [tags, setTags] = useState<string[]>([]);
  const [cover, setCover] = useState<string | null>(null);
  const [rights, setRights] = useState(false);
  const [saving, setSaving] = useState(false);
  const [published, setPublished] = useState<Track | null>(null);
  const coverInput = useRef<HTMLInputElement>(null);
  const runId = useRef(0);

  useEffect(() => () => { runId.current++; }, []);

  const anyBad = [title, artist, album, desc].some((v) => !censor(v).ok);
  const warned = useRef(false);
  useEffect(() => {
    if (anyBad && !warned.current) {
      warned.current = true;
      useStore.getState().chibi("censor");
    }
    if (!anyBad) warned.current = false;
  }, [anyBad]);

  const reset = () => {
    runId.current++;
    setStep("file");
    setFile(null);
    setChecks([]);
    setReport(null);
    setVerdict("pending");
    setReason(null);
    setTitle("");
    setArtist("");
    setAlbum("");
    setDesc("");
    setTags([]);
    setCover(null);
    setRights(false);
    setPublished(null);
  };

  const runModeration = async (f: File) => {
    const my = ++runId.current;
    setFile(f);
    setStep("mod");
    setVerdict("pending");
    setReport(null);
    setReason(null);
    setChecks([
      { id: "type", label: "Формат файла", status: "wait" },
      { id: "size", label: "Размер до 25 МБ", status: "wait" },
      { id: "decode", label: "Звук читается", status: "wait" },
      { id: "dur", label: "Длительность от 20 с до 12 мин", status: "wait" },
      { id: "level", label: "Это музыка, а не тишина или шум", status: "wait" },
      { id: "clip", label: "Нет сильного перегруза", status: "wait" },
      { id: "dup", label: "Не копия трека из библиотеки", status: "wait" },
    ]);
    const alive = () => runId.current === my;
    const upd = (id: string, status: Status, key?: string, vars?: CheckMessage["vars"]) => alive() && setChecks((cs) => cs.map((c) => (c.id === id ? { ...c, status, note: key ? { key, vars } : undefined } : c)));
    const fail = (id: string, key: string, vars?: CheckMessage["vars"]) => {
      upd(id, "fail", key, vars);
      if (!alive()) return;
      setReason({ key, vars });
      setVerdict("fail");
    };

    upd("type", "run");
    await wait(450);
    const okType = f.type.startsWith("audio/") || /\.(mp3|wav|ogg|oga|m4a|aac|flac|webm|opus)$/i.test(f.name);
    if (!okType) return fail("type", "Это не аудиофайл");
    upd("type", "ok", (f.name.split(".").pop() || f.type).toUpperCase());
    upd("size", "run");
    await wait(320);
    if (f.size > 25 * 1024 * 1024) return fail("size", "Файл {size} МБ — больше лимита", { size: (f.size / 1048576).toFixed(1) });
    upd("size", "ok", "{size} МБ", { size: (f.size / 1048576).toFixed(1) });
    upd("decode", "run");
    let buf: AudioBuffer;
    try {
      buf = await decodeBlob(f);
    } catch {
      return fail("decode", "Не удалось декодировать звук");
    }
    if (!alive()) return;
    upd("decode", "ok");
    upd("dur", "run");
    await wait(300);
    if (buf.duration < 20 || buf.duration > 720) return fail("dur", "Длительность {time} — вне диапазона", { time: fmtTime(buf.duration) });
    upd("dur", "ok", fmtTime(buf.duration));
    upd("level", "run");
    await wait(60);
    const rep = inspect(buf);
    if (!alive()) return;
    setReport(rep);
    if (rep.rms < 0.008 || rep.silent > 0.6) return fail("level", "Слишком тихо или почти тишина");
    if (rep.fp.flat > 0.62) return fail("level", "Похоже на шум, а не на музыку");
    upd("level", "ok", `${(20 * Math.log10(rep.rms)).toFixed(1)} dBFS · ${Math.round(rep.fp.bpm)} BPM`);
    upd("clip", "run");
    await wait(320);
    if (rep.clip > 0.05) return fail("clip", "Перегруз: {pct}% сэмплов", { pct: (rep.clip * 100).toFixed(1) });
    upd("clip", rep.clip > 0.01 ? "warn" : "ok", rep.clip > 0.01 ? "есть перегруз, но терпимо" : "чисто");
    upd("dup", "run");
    const lib = await ensureLibrary(allTracks());
    await wait(350);
    if (!alive()) return;
    const best = matchFP(rep.fp, lib)[0];
    if (best && best.s > 0.96) return fail("dup", "Почти копия «{title}»", { title: findTrack(best.id)?.title ?? tx("трека") });
    upd("dup", "ok", best ? "ближе всего «{title}» · {pct}%" : undefined, best ? { title: findTrack(best.id)?.title ?? "", pct: Math.round(best.s * 100) } : undefined);
    const g = guessGenre(featuresFromFP(rep.fp));
    setGuess(g);
    setGenre(g);
    setTitle(prettyName(f.name));
    setVerdict("ok");
  };

  const canPublish = verdict === "ok" && !!report && !!file && title.trim().length > 0 && artist.trim().length > 0 && rights && !anyBad && !saving;

  const publish = async () => {
    if (anyBad) {
      useStore.getState().chibi("censor");
      return;
    }
    if (!canPublish || !report || !file) return;
    setSaving(true);
    const id = "u" + Date.now().toString(36);
    const fp = report.fp;
    const t: Track = {
      id, title: title.trim(), artist: artist.trim(), album: album.trim() || "Сингл", albumId: "u-" + id, genre,
      bpm: Math.round(fp.bpm) || 100, duration: report.duration, seed: hashStr(id), hue: GENRES[genre].hue, cover: COVER_BY_GENRE[genre],
      f: featuresFromFP(fp), tags: [...tags, "сообщество"], source: "upload", coverUrl: cover ?? undefined, fp, desc: desc.trim() || undefined, createdAt: Date.now(),
    };
    try {
      await putAudio(id, file);
      const list = [...useStore.getState().uploads, t];
      await saveUploads(list);
      useStore.getState().setUploads(list);
      await wait(900);
      setPublished(t);
      setStep("done");
      useStore.getState().chibi("upload", translate("«{title}» теперь в библиотеке! Горжусь.", undefined, { title: t.title }));
    } catch {
      useStore.getState().toast(translate("Не удалось сохранить — не хватает места в хранилище"));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    const st = useStore.getState();
    const list = st.uploads.filter((u) => u.id !== id);
    if (st.currentId === id) {
      engine.stop();
      useStore.setState({ isPlaying: false, currentId: null });
    }
    await removeAudio(id);
    await saveUploads(list);
    st.setUploads(list);
    st.toast(translate("Трек удалён"));
  };

  const stepIdx = STEPS.findIndex((s) => s.id === step);
  const previewSrc = { id: "preview", title: title || tx("Твой трек"), hue: GENRES[genre].hue, cover: COVER_BY_GENRE[genre], seed: 4242, coverUrl: cover ?? undefined };

  return (
    <div className="space-y-10">
      <PageTitle
        title="Вклад в"
        accent="сообщество"
        sub="Залей трек с телефона или компьютера. Модерация проверит звук, цензура — название, и трек появится в поиске, Резонансе и распознавании."
      />

      <div className="flex items-center gap-2 sm:gap-3">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex flex-1 items-center gap-2 sm:gap-3">
            <div className={cn("flex items-center gap-2 rounded-full px-1 py-1 pr-3 transition-colors", i <= stepIdx ? "text-ink" : "text-ink3")}>
              <motion.div
                animate={{ scale: i === stepIdx ? 1.1 : 1 }}
                className={cn("grid h-9 w-9 place-items-center rounded-full font-display text-sm font-bold", i < stepIdx ? "bg-acid text-[#0b0614]" : i === stepIdx ? "btn-grad" : "btn-soft")}
              >
                {i < stepIdx ? <Check className="h-4 w-4" /> : i + 1}
              </motion.div>
              <span className="hidden text-sm font-bold sm:inline">{tx(s.label)}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div className="h-1 flex-1 overflow-hidden rounded-full bg-ink/10">
                <motion.div className="h-full bg-gradient-to-r from-vio to-acid" animate={{ width: i < stepIdx ? "100%" : "0%" }} transition={{ duration: 0.6 }} />
              </div>
            )}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === "file" && (
          <motion.label
            key="file"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16, filter: "blur(6px)" }}
            onDragOver={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDrag(false);
              const f = e.dataTransfer.files?.[0];
              if (f) void runModeration(f);
            }}
            className={cn("glass shadow-deep group relative grid min-h-[360px] cursor-pointer place-items-center overflow-hidden rounded-[44px] p-8 text-center transition-transform duration-300", drag && "scale-[1.015]")}
          >
            <input
              type="file"
              accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac,.webm,.opus"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void runModeration(f);
                e.target.value = "";
              }}
            />
            <div className="grid-fine absolute inset-0 opacity-50" />
            <svg className="pointer-events-none absolute inset-3 h-[calc(100%-24px)] w-[calc(100%-24px)] overflow-visible">
              <rect width="100%" height="100%" rx="34" fill="none" strokeOpacity="0.55" strokeWidth="2" strokeDasharray="10 10" className="dash-anim" style={{ stroke: drag ? "var(--acid)" : "var(--vio)" }} />
            </svg>
            <div className="relative">
              <div className="relative mx-auto h-40 w-40">
                <div className="absolute inset-0 transition-transform duration-700 group-hover:rotate-12 group-hover:scale-110">
                  <GlyphBlob shape={7} hue={drag ? 95 : 268} />
                </div>
                <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 2.4, repeat: Infinity }} className="absolute inset-0 grid place-items-center text-white">
                  <Upload className="h-12 w-12 drop-shadow-lg" />
                </motion.div>
              </div>
              <div className="mt-6 font-display text-2xl font-bold">{tx(drag ? "Отпускай!" : "Перетащи трек сюда")}</div>
              <p className="mt-2 text-sm text-ink3">{tx("или нажми, чтобы выбрать — с телефона тоже работает")}</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2 text-[11px] font-bold text-ink3">
                {["MP3", "WAV", "OGG", "M4A", "FLAC", "до 25 МБ"].map((x) => (
                  <span key={x} className="rounded-full bg-ink/[0.06] px-2.5 py-1">
                    {tx(x)}
                  </span>
                ))}
              </div>
            </div>
          </motion.label>
        )}

        {step === "mod" && (
          <motion.div key="mod" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} className="grid gap-6 lg:grid-cols-[1fr_1fr]">
            <div className="glass shadow-deep relative overflow-hidden rounded-[40px] p-6">
              <div className="text-xs font-bold uppercase tracking-[0.2em] text-ink3">{tx("Файл")}</div>
              <div className="mt-2 truncate font-display text-xl font-bold">{file?.name}</div>
              <div className="mt-6 flex h-36 items-center gap-[3px]">
                {(report?.wave ?? Array.from({ length: 96 }, () => 0.06)).map((v, i) => (
                  <motion.div
                    key={i}
                    className="flex-1 rounded-full bg-gradient-to-t from-vio to-acid"
                    initial={{ height: "6%" }}
                    animate={{ height: `${Math.max(6, v * 100)}%`, opacity: report ? 1 : [0.3, 0.8, 0.3] }}
                    transition={report ? { delay: i * 0.006, duration: 0.5 } : { duration: 1.2, repeat: Infinity, delay: i * 0.01 }}
                  />
                ))}
              </div>
              {report && (
                <div className="mt-6 grid grid-cols-3 gap-2 text-center">
                  {[
                    { l: "длительность", v: fmtTime(report.duration) },
                    { l: "темп", v: `${Math.round(report.fp.bpm)} BPM` },
                    { l: "тональность", v: keyOf(report.fp.chroma).name },
                  ].map((x) => (
                    <div key={x.l} className="rounded-[18px] bg-ink/[0.05] p-3">
                      <div className="font-display text-sm font-bold">{x.v}</div>
                      <div className="text-[11px] text-ink3">{tx(x.l)}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="glass shadow-deep relative overflow-hidden rounded-[40px] p-6">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-ink3">
                <ShieldCheck className="h-4 w-4" /> {tx("Автомодерация")}
              </div>
              <div className="mt-4 space-y-1.5">
                {checks.map((c, i) => (
                  <motion.div key={c.id} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} className="flex items-center gap-3 rounded-[18px] px-2 py-2">
                    <div
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-full",
                        c.status === "ok" && "bg-acid/20 text-acidink",
                        c.status === "fail" && "bg-[#ff5c7a]/20 text-[#ff5c7a]",
                        c.status === "warn" && "bg-amber-400/20 text-amber-500",
                        (c.status === "wait" || c.status === "run") && "bg-ink/[0.07] text-ink3"
                      )}
                    >
                      {c.status === "run" ? <LoaderCircle className="h-4 w-4 animate-spin" /> : c.status === "ok" ? <Check className="h-4 w-4" /> : c.status === "fail" ? <X className="h-4 w-4" /> : c.status === "warn" ? <TriangleAlert className="h-4 w-4" /> : <span className="h-1.5 w-1.5 rounded-full bg-current" />}
                    </div>
                    <div className="min-w-0">
                      <div className={cn("text-sm font-bold", c.status === "wait" && "text-ink3")}>{tx(c.label)}</div>
                      {c.note && <div className="truncate text-xs text-ink3">{tx(c.note.key, c.note.vars)}</div>}
                    </div>
                  </motion.div>
                ))}
              </div>
              <AnimatePresence mode="wait">
                {verdict === "ok" && (
                  <motion.div key="ok" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-[24px] bg-acid/15 p-4">
                    <div>
                      <div className="font-display font-bold text-acidink">{tx("Одобрено модерацией")}</div>
                      <div className="text-xs text-ink2">{tx("Похоже на {genre}. Осталось оформить.", { genre: guess ? tx(GENRES[guess].label).toLowerCase() : tx("Музыка") })}</div>
                    </div>
                    <button onClick={() => setStep("form")} className="btn-grad rounded-full px-5 py-2.5 font-display text-sm font-bold">
                      {tx("Дальше")}
                    </button>
                  </motion.div>
                )}
                {verdict === "fail" && (
                  <motion.div key="fail" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-[24px] bg-[#ff5c7a]/12 p-4">
                    <div>
                      <div className="font-display font-bold text-[#ff5c7a]">{tx("Не прошёл модерацию")}</div>
                      <div className="text-xs text-ink2">{reason && tx(reason.key, reason.vars)}</div>
                    </div>
                    <button onClick={reset} className="btn-soft flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold">
                      <RotateCcw className="h-4 w-4" /> {tx("Другой файл")}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {step === "form" && (
          <motion.div key="form" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} className="grid gap-6 lg:grid-cols-[320px_1fr]">
            <div className="glass shadow-deep relative overflow-hidden rounded-[40px] p-6">
              <div className="text-xs font-bold uppercase tracking-[0.2em] text-ink3">{tx("Обложка")}</div>
              <button onClick={() => coverInput.current?.click()} className="group relative mx-auto mt-4 block aspect-square w-full max-w-[250px]">
                <div className="absolute -inset-[6%] transition-transform duration-700 group-hover:rotate-6">
                  <GlyphBlob shape={hashStr(title) % 8} hue={GENRES[genre].hue} />
                </div>
                <div className="absolute left-1/2 top-1/2 aspect-square w-[64%] -translate-x-1/2 -translate-y-1/2 -rotate-6 overflow-hidden rounded-[28px] shadow-[0_24px_50px_-14px_rgba(0,0,0,0.65)] ring-1 ring-white/20">
                  <Cover t={previewSrc} />
                  <div className="absolute inset-0 grid place-items-center bg-black/40 text-white opacity-0 transition-opacity group-hover:opacity-100">
                    <ImagePlus className="h-8 w-8" />
                  </div>
                </div>
              </button>
              <input
                ref={coverInput}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  e.target.value = "";
                  if (!f) return;
                  try {
                    setCover(await processCover(f));
                  } catch {
                    useStore.getState().toast(translate("Не удалось открыть картинку"));
                  }
                }}
              />
              <div className="mt-4 flex justify-center gap-2">
                <button onClick={() => coverInput.current?.click()} className="btn-soft flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold">
                  <ImagePlus className="h-4 w-4" /> {tx(cover ? "Заменить" : "Своё фото")}
                </button>
                {cover && (
                  <button onClick={() => setCover(null)} className="btn-soft rounded-full px-4 py-2 text-xs font-bold">
                    {tx("Убрать")}
                  </button>
                )}
              </div>
              <p className="mt-3 text-center text-[11px] text-ink3">{tx("Без фото соберём обложку сами — в стиле жанра.")}</p>
            </div>

            <div className="glass shadow-deep space-y-5 rounded-[40px] p-6">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Название" value={title} onChange={setTitle} placeholder="Как называется трек" required />
                <Field label="Исполнитель" value={artist} onChange={setArtist} placeholder="Твой ник или имя" required max={60} />
              </div>
              <Field label="Альбом" value={album} onChange={setAlbum} placeholder="Необязательно — иначе «Сингл»" max={60} />
              <div>
                <div className="mb-2 px-1 text-xs font-bold text-ink2">{tx("Жанр")}</div>
                <div className="flex flex-wrap gap-2">
                  {GENRE_LIST.map((g) => (
                    <button
                      key={g}
                      onClick={() => setGenre(g)}
                      className={cn("relative rounded-full px-4 py-2 text-sm font-bold transition-all", genre === g ? "bg-vio text-white shadow-lg" : "btn-soft")}
                    >
                      {tx(GENRES[g].label)}
                      {guess === g && <span className="absolute -right-1 -top-2 rounded-full bg-acid px-1.5 text-[9px] font-black text-[#0b0614]">{tx("угадали")}</span>}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-2 px-1 text-xs font-bold text-ink2">{tx("Теги настроения")}</div>
                <div className="flex flex-wrap gap-2">
                  {TAGS.map((tg) => {
                    const on = tags.includes(tg);
                    return (
                      <button
                        key={tg}
                        onClick={() => setTags((a) => (on ? a.filter((x) => x !== tg) : [...a, tg].slice(0, 5)))}
                        className={cn("rounded-full px-3.5 py-1.5 text-xs font-bold transition-all", on ? "bg-acid text-[#0b0614]" : "btn-soft")}
                      >
                        #{tx(tg)}
                      </button>
                    );
                  })}
                </div>
              </div>
              <Field label="Пара слов о треке" value={desc} onChange={setDesc} placeholder="Необязательно" max={200} area />
              <label className="flex cursor-pointer items-start gap-3 rounded-[20px] bg-ink/[0.04] p-4">
                <input type="checkbox" checked={rights} onChange={(e) => setRights(e.target.checked)} className="mt-0.5 h-5 w-5 accent-[#8b5cf6]" />
                <span className="text-sm text-ink2">{tx("Это мой трек, или у меня есть права его публиковать.")}</span>
              </label>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <button onClick={reset} className="text-sm font-bold text-ink3 hover:text-ink">
                  {tx("Отменить")}
                </button>
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={publish}
                  disabled={!canPublish}
                  className={cn("flex items-center gap-2 rounded-full px-7 py-3.5 font-display text-sm font-bold transition-opacity", canPublish ? "btn-grad" : "btn-soft opacity-50")}
                >
                  {saving ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  {tx(saving ? "Публикую…" : "Опубликовать")}
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {step === "done" && published && (
          <motion.div key="done" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="glass shadow-deep relative overflow-hidden rounded-[44px] p-8 text-center sm:p-12">
            <div className="grid-fine absolute inset-0 opacity-50" />
            {Array.from({ length: 18 }, (_, i) => (
              <motion.span
                key={i}
                className="absolute left-1/2 top-1/3 h-2.5 w-2.5 rounded-[3px]"
                style={{ background: i % 3 === 0 ? "var(--acid)" : i % 3 === 1 ? "var(--vio)" : "#ff5c9a" }}
                initial={{ x: 0, y: 0, opacity: 1, rotate: 0 }}
                animate={{ x: Math.cos(i * 0.35) * (140 + (i % 5) * 30), y: Math.sin(i * 0.35) * (90 + (i % 4) * 30) + 80, opacity: 0, rotate: 360 }}
                transition={{ duration: 1.6, ease: "easeOut" }}
              />
            ))}
            <div className="relative mx-auto flex justify-center">
              <ShapeCard cover={published} title={published.title} sub={published.artist} hue={published.hue} shape={published.seed % 8} active={false} playing={false} onPlay={() => useStore.getState().playTrack(published.id)} className="w-[240px] sm:w-[240px]" />
            </div>
            <div className="relative mt-4 font-display text-3xl font-black">{tx("Опубликовано!")}</div>
            <p className="relative mt-2 text-sm text-ink2">{tx("Трек уже в поиске, в Резонансе и в базе распознавания.")}</p>
            <div className="relative mt-6 flex flex-wrap justify-center gap-3">
              <button onClick={() => useStore.getState().playTrack(published.id)} className="btn-grad flex items-center gap-2 rounded-full px-6 py-3 font-display text-sm font-bold">
                <Play className="h-4 w-4 fill-current" /> {tx("Слушать")}
              </button>
              <button onClick={reset} className="btn-soft flex items-center gap-2 rounded-full px-6 py-3 font-display text-sm font-bold">
                <Upload className="h-4 w-4" /> {tx("Загрузить ещё")}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <section>
        <div className="mb-3 flex items-end justify-between px-1">
          <h2 className="font-display text-2xl font-bold tracking-tight">{tx("Мои публикации")}</h2>
          <span className="text-xs text-ink3">{tx("хранятся на этом устройстве")}</span>
        </div>
        <div className="glass rounded-[36px] p-3">
          {uploads.length ? (
            <AnimatePresence initial={false}>
              {uploads.map((t) => (
                <motion.div key={t.id} layout exit={{ opacity: 0, x: 40 }} className="flex items-center gap-1">
                  <TrackRow t={t} queue={uploads.map((u) => u.id)} className="flex-1" />
                  <button onClick={() => void remove(t.id)} className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-ink3 hover:bg-[#ff5c7a]/15 hover:text-[#ff5c7a]" aria-label={tx("Удалить")}>
                    <X className="h-4 w-4" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          ) : (
            <div className="py-10 text-center text-sm text-ink3">{tx("Пока ничего. Первый трек — самый важный.")}</div>
          )}
        </div>
      </section>
    </div>
  );
}
