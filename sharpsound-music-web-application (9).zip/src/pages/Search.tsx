import { AnimatePresence, motion } from "framer-motion";
import { Play, Search as SearchIcon, X } from "lucide-react";
import { useDeferredValue, useMemo, useState } from "react";
import { Cover } from "../components/Cover";
import { GlyphBlob } from "../components/GlyphBlob";
import { LikeButton, PageTitle, TrackRow } from "../components/ui";
import { CircleText, MiniEq } from "../components/Visuals";
import { fmtTime, GENRES } from "../data/catalog";
import { searchTracks } from "../lib/reco";
import { allTracks, useStore } from "../store";
import { useI18n } from "../lib/i18n";

const SUGGEST = ["ксенон", "дождь", "фонк", "для учёбы", "Night Ferry", "гитара", "космос", "перегрузка", "техно"];

export default function SearchPage() {
  const { t: tx } = useI18n();
  const [q, setQ] = useState("");
  const dq = useDeferredValue(q);
  const uploads = useStore((s) => s.uploads);
  const studioTracks = useStore((s) => s.studioTracks);
  const currentId = useStore((s) => s.currentId);
  const isPlaying = useStore((s) => s.isPlaying);
  const st = useStore.getState();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const res = useMemo(() => searchTracks(allTracks(), dq), [dq, uploads, studioTracks]);
  const top = res.exact[0];
  const queueAll = [...res.exact, ...res.similar.map((s) => s.t)].map((t) => t.id);

  return (
    <div className="space-y-8">
      <PageTitle title="Поиск" accent="по-соседски" sub="Вводишь название — находим трек и всё, что звучит рядом с ним. Можно искать по настроению: «дождь», «ночь», «для учёбы»." />

      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grad-border focus-ring glass-strong relative rounded-[32px]">
        <SearchIcon className="absolute left-6 top-1/2 h-5 w-5 -translate-y-1/2 text-ink3" />
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={tx("Название, артист или настроение…")}
          className="w-full rounded-[32px] bg-transparent py-5 pl-16 pr-14 text-lg font-semibold outline-none placeholder:font-medium placeholder:text-ink3 sm:py-6 sm:text-xl"
        />
        <AnimatePresence>
          {q && (
            <motion.button
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              onClick={() => setQ("")}
              className="absolute right-4 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full btn-soft"
              aria-label={tx("Очистить")}
            >
              <X className="h-4 w-4" />
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>

      <div className="flex flex-wrap gap-2">
        {SUGGEST.map((s, i) => (
          <motion.button
            key={s}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 + i * 0.03 }}
            whileHover={{ y: -2 }}
            onClick={() => setQ(tx(s))}
            className="btn-soft rounded-full px-4 py-2 text-sm font-semibold"
          >
            {tx(s)}
          </motion.button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {!dq.trim() ? (
          <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative grid place-items-center py-10">
            <div className="relative h-64 w-64">
              <div className="absolute inset-6">
                <GlyphBlob shape={2} hue={270} />
              </div>
              <CircleText text={tx("НАЧНИ ПЕЧАТАТЬ • НАЙДЁМ ПОХОЖЕЕ • ")} className="absolute inset-0 text-ink3" size={11} />
              <SearchIcon className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 text-white drop-shadow-lg" />
            </div>
          </motion.div>
        ) : res.exact.length || res.similar.length ? (
          <motion.div key={`r-${dq}`} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-10">
            {top && (
              <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
                <div className="glass shadow-deep relative overflow-hidden rounded-[40px] p-6">
                  <div className="text-xs font-bold uppercase tracking-[0.2em] text-ink3">{tx("Лучшее совпадение")}</div>
                  <div className="relative mx-auto mt-4 aspect-square w-full max-w-[300px]" style={{ perspective: 900 }}>
                    <div className="absolute -inset-[6%]">
                      <GlyphBlob shape={top.seed % 8} hue={top.hue} active={currentId === top.id && isPlaying} />
                    </div>
                    <motion.div
                      initial={{ rotate: -12, scale: 0.8, opacity: 0 }}
                      animate={{ rotate: -5, scale: 1, opacity: 1 }}
                      transition={{ type: "spring", stiffness: 200, damping: 18 }}
                      className="absolute left-1/2 top-1/2 aspect-square w-[62%] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-[30px] shadow-[0_30px_60px_-16px_rgba(0,0,0,0.65)] ring-1 ring-white/20"
                    >
                      <Cover t={top} spin={currentId === top.id && isPlaying} />
                    </motion.div>
                  </div>
                  <div className="mt-2 text-center">
                    <div className="font-display text-2xl font-bold leading-tight">{top.title}</div>
                    <div className="mt-1 text-sm text-ink3">{top.artist}</div>
                    <div className="mt-3 flex flex-wrap justify-center gap-2 text-xs font-bold">
                      <span className="rounded-full bg-vio/15 px-3 py-1">{tx(GENRES[top.genre].label)}</span>
                      <span className="rounded-full bg-acid/15 px-3 py-1 text-acidink">{Math.round(top.bpm)} BPM</span>
                      <span className="rounded-full bg-ink/10 px-3 py-1">{fmtTime(top.duration)}</span>
                    </div>
                    <div className="mt-5 flex items-center justify-center gap-3">
                      <button
                        onClick={() => (currentId === top.id ? st.togglePlay() : st.playTrack(top.id, queueAll))}
                        className="btn-grad flex items-center gap-2 rounded-full px-6 py-3 font-display text-sm font-bold"
                      >
                        {currentId === top.id && isPlaying ? <MiniEq on /> : <Play className="h-4 w-4 fill-current" />}
                        {tx(currentId === top.id && isPlaying ? "Играет" : "Слушать")}
                      </button>
                      <LikeButton id={top.id} big />
                    </div>
                  </div>
                </div>
                <div className="min-w-0">
                  {res.exact.length > 1 && (
                    <>
                      <h3 className="mb-2 px-2 font-display text-lg font-bold">{tx("Ещё по запросу")}</h3>
                      <div className="glass mb-6 rounded-[30px] p-2">
                        {res.exact.slice(1).map((t) => (
                          <TrackRow key={t.id} t={t} queue={queueAll} />
                        ))}
                      </div>
                    </>
                  )}
                  <h3 className="mb-2 px-2 font-display text-lg font-bold">
                    {tx("Звучит похоже на")} <span className="text-grad">«{top.title}»</span>
                  </h3>
                  <div className="glass rounded-[30px] p-2">
                    {res.similar.map(({ t, s }) => (
                      <TrackRow key={t.id} t={t} sim={s} queue={queueAll} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            {!top && (
              <div>
                <h3 className="mb-1 px-2 font-display text-xl font-bold">{tx("Точного названия нет — но по настроению подходит это")}</h3>
                <p className="mb-4 px-2 text-sm text-ink3">{tx("Подобрали по тегам, жанру и звучанию")}</p>
                <div className="glass grid gap-x-4 rounded-[30px] p-2 lg:grid-cols-2">
                  {res.similar.map(({ t, s }) => (
                    <TrackRow key={t.id} t={t} sim={s} queue={queueAll} />
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div key="none" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="glass rounded-[40px] p-10 text-center">
            <div className="mx-auto h-28 w-28">
              <GlyphBlob shape={5} hue={200} />
            </div>
            <div className="mt-4 font-display text-xl font-bold">{tx("Ничего не нашлось")}</div>
            <p className="mt-1 text-sm text-ink3">{tx("Попробуй другое название или настроение — например «ночь» или «гитара».")}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
