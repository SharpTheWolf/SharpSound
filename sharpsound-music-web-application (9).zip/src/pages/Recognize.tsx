import { AnimatePresence, animate, motion, useMotionValue, useTransform } from "framer-motion";
import { LoaderCircle, Mic, Play, RotateCcw, TriangleAlert, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { analyze, decodeBlob, ensureLibrary, matchFP, mono, segment, startMic, type FP, type MicSession } from "../audio/analysis";
import { Cover } from "../components/Cover";
import { GlyphBlob } from "../components/GlyphBlob";
import { LikeButton, PageTitle, TrackRow } from "../components/ui";
import { CircleText, MiniEq } from "../components/Visuals";
import { GENRES, TRACKS, type Track } from "../data/catalog";
import { allTracks, findTrack, useStore } from "../store";
import { cn } from "../utils/cn";
import { translate, useI18n } from "../lib/i18n";

type Phase = "idle" | "listen" | "analyze" | "done" | "error";
const CIRC = 2 * Math.PI * 96;
const LISTEN_MS = 9000;

function Counter({ value }: { value: number }) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => Math.round(v));
  useEffect(() => {
    const c = animate(mv, value, { duration: 1.3, ease: [0.22, 1, 0.36, 1] });
    return () => c.stop();
  }, [value, mv]);
  return <motion.span>{rounded}</motion.span>;
}

export default function Recognize() {
  const { t: tx } = useI18n();
  const uploads = useStore((s) => s.uploads);
  const studioTracks = useStore((s) => s.studioTracks);
  const currentId = useStore((s) => s.currentId);
  const isPlaying = useStore((s) => s.isPlaying);
  const [phase, setPhase] = useState<Phase>("idle");
  const phaseRef = useRef<Phase>("idle");
  const [lib, setLib] = useState({ done: 0, total: TRACKS.length });
  const [ready, setReady] = useState(false);
  const [results, setResults] = useState<{ t: Track; s: number }[]>([]);
  const [err, setErr] = useState("");
  const libP = useRef<Promise<Map<string, FP>> | null>(null);
  const mic = useRef<MicSession | null>(null);
  const rings = useRef<(HTMLDivElement | null)[]>([]);
  const prog = useRef<SVGCircleElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const setP = (p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  };

  useEffect(() => {
    setReady(false);
    const p = ensureLibrary(allTracks(), (d, t) => setLib({ done: d, total: t }));
    libP.current = p;
    p.then(() => setReady(true)).catch(() => setReady(true));
  }, [uploads, studioTracks]);

  useEffect(() => () => mic.current?.cancel(), []);

  useEffect(() => {
    const el = prog.current;
    if (!el) return;
    if (phase === "idle" || phase === "error") el.style.strokeDashoffset = String(CIRC);
    if (phase === "analyze" || phase === "done") el.style.strokeDashoffset = "0";
    if (phase !== "listen") rings.current.forEach((r) => r && (r.style.transform = ""));
  }, [phase]);

  const finishWith = async (x: Float32Array, sr: number) => {
    setP("analyze");
    let e = 0;
    let n = 0;
    for (let i = 0; i < x.length; i += 4) {
      e += x[i] * x[i];
      n++;
    }
    const rms = Math.sqrt(e / Math.max(1, n));
    if (x.length < sr * 2 || rms < 0.003) {
      setErr("Слишком тихо — ничего не расслышал. Сделай погромче или поднеси источник ближе.");
      setP("error");
      return;
    }
    const fp = analyze(x, sr);
    const [map] = await Promise.all([libP.current ?? ensureLibrary(allTracks()), new Promise((r) => setTimeout(r, 900))]);
    const m = matchFP(fp, map)
      .map((r) => ({ t: findTrack(r.id), s: r.s }))
      .filter((r): r is { t: Track; s: number } => !!r.t)
      .slice(0, 6);
    setResults(m);
    setP("done");
    if (m[0]) useStore.getState().chibi("found", translate(m[0].s > 0.72 ? "Нашёл! Это «{title}»." : "Точно не уверен, но ближе всего «{title}».", undefined, { title: m[0].t.title }));
  };

  const startMicFlow = async () => {
    if (phaseRef.current === "listen") {
      mic.current?.cancel();
      mic.current = null;
      setP("idle");
      return;
    }
    if (phaseRef.current === "analyze") return;
    setErr("");
    setResults([]);
    try {
      mic.current = await startMic();
    } catch {
      setErr("Нет доступа к микрофону. Разреши его в браузере — или распознай файл.");
      setP("error");
      return;
    }
    if (prog.current) prog.current.style.strokeDashoffset = String(CIRC);
    setP("listen");
    const t0 = performance.now();
    const loop = () => {
      const m = mic.current;
      if (phaseRef.current !== "listen" || !m) return;
      const p = Math.min(1, (performance.now() - t0) / LISTEN_MS);
      const lv = Math.min(1, m.level() * 4);
      rings.current.forEach((el, i) => {
        if (el) el.style.transform = `scale(${(1 + i * 0.16 + lv * (0.35 + i * 0.25)).toFixed(3)})`;
      });
      if (prog.current) prog.current.style.strokeDashoffset = String(CIRC * (1 - p));
      if (p >= 1) {
        const { x, sr } = m.finish();
        mic.current = null;
        void finishWith(x, sr);
        return;
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  };

  const onFile = async (f: File) => {
    if (phaseRef.current === "listen") {
      mic.current?.cancel();
      mic.current = null;
    }
    setErr("");
    setResults([]);
    setP("analyze");
    try {
      const buf = await decodeBlob(f);
      const x = segment(mono(buf), buf.sampleRate, 10, 0.4);
      await finishWith(new Float32Array(x), buf.sampleRate);
    } catch {
      setErr("Не получилось прочитать файл. Подойдут MP3, WAV, OGG, M4A, FLAC.");
      setP("error");
    }
  };

  const best = results[0];
  const label =
    phase === "listen" ? "СЛУШАЮ • СЛУШАЮ • СЛУШАЮ • СЛУШАЮ • " : phase === "analyze" ? "СРАВНИВАЮ • ИЩУ ПОХОЖЕЕ • СРАВНИВАЮ • " : "НАЖМИ • ВКЛЮЧИ ЗВУК РЯДОМ • НАЖМИ • ";

  return (
    <div className="space-y-10">
      <PageTitle title="Распознать" accent="на слух" sub="Включи музыку рядом. SharpSound разберёт её по частотам и найдёт в библиотеке этот трек — или тот, что звучит ближе всего." />

      <section className="glass shadow-deep relative overflow-hidden rounded-[44px] px-6 py-10 sm:py-14">
        <div className="grid-fine absolute inset-0 opacity-50" />
        <div className="absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-vio/20 blur-3xl" />
        <div className="relative mx-auto grid h-[300px] w-[300px] place-items-center sm:h-[360px] sm:w-[360px]">
          {[0, 1, 2].map((i) => (
            <div key={i} className="absolute inset-[24%]">
              <div
                ref={(el) => {
                  rings.current[i] = el;
                }}
                className={cn("h-full w-full rounded-full border-2", i === 0 ? "border-vio/70" : i === 1 ? "border-acid/50" : "border-vio/30", phase === "idle" && "ring-out")}
                style={{ animationDelay: `${i * 0.8}s`, transition: "transform 90ms linear" }}
              />
            </div>
          ))}
          <CircleText text={tx(label)} className="absolute inset-0 text-ink2" size={12} reverse={phase === "analyze"} />
          <svg className="absolute inset-[15%] -rotate-90" viewBox="0 0 200 200" aria-hidden>
            <defs>
              <linearGradient id="recG" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#8b5cf6" />
                <stop offset="1" stopColor="#b4f03c" />
              </linearGradient>
            </defs>
            <circle cx="100" cy="100" r="96" fill="none" strokeWidth="3" style={{ stroke: "var(--line)" }} />
            <circle ref={prog} cx="100" cy="100" r="96" fill="none" stroke="url(#recG)" strokeWidth="5" strokeLinecap="round" strokeDasharray={CIRC} style={{ strokeDashoffset: CIRC }} />
          </svg>
          <motion.button
            onClick={startMicFlow}
            whileTap={{ scale: 0.92 }}
            whileHover={{ scale: 1.05 }}
            animate={phase === "listen" ? { scale: [1, 1.04, 1] } : { scale: 1 }}
            transition={phase === "listen" ? { duration: 1.2, repeat: Infinity } : undefined}
            className="relative grid h-[42%] w-[42%] place-items-center rounded-full shadow-[0_30px_70px_-18px_rgba(124,58,237,0.85)]"
            aria-label={tx("Слушать")}
          >
            <div className="absolute -inset-[18%]">
              <GlyphBlob shape={phase === "listen" ? 3 : 6} hue={phase === "listen" ? 95 : 272} glow={false} />
            </div>
            <span className="relative text-white drop-shadow-lg">
              {phase === "analyze" ? <LoaderCircle className="h-12 w-12 animate-spin" /> : <Mic className="h-12 w-12" />}
            </span>
          </motion.button>
        </div>

        <div className="relative mt-6 text-center">
          <AnimatePresence mode="wait">
            <motion.div key={phase + err} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
              {phase === "idle" && <div className="font-display text-lg font-bold">{tx("Нажми и дай послушать")}</div>}
              {phase === "listen" && <div className="font-display text-lg font-bold">{tx("Слушаю… держи источник поближе")}</div>}
              {phase === "analyze" && <div className="font-display text-lg font-bold">{tx("Сравниваю с библиотекой…")}</div>}
              {phase === "done" && <div className="font-display text-lg font-bold">{tx("Готово")}</div>}
              {phase === "error" && (
                <div className="mx-auto flex max-w-md items-center justify-center gap-2 font-semibold text-[#ff6b8b]">
                  <TriangleAlert className="h-5 w-5 shrink-0" /> {tx(err)}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
            <button onClick={() => fileRef.current?.click()} className="btn-soft flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold">
              <Upload className="h-4 w-4" /> {tx("Распознать файл")}
            </button>
            {(phase === "done" || phase === "error") && (
              <button onClick={startMicFlow} className="btn-soft flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold">
                <RotateCcw className="h-4 w-4" /> {tx("Ещё раз")}
              </button>
            )}
            <input
              ref={fileRef}
              type="file"
              accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac,.webm,.opus"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void onFile(f);
                e.target.value = "";
              }}
            />
          </div>
          <div className="mx-auto mt-5 max-w-xs">
            {ready ? (
              <div className="text-xs text-ink3">{tx("Библиотека готова")} · {lib.total + uploads.length} {tx("треков в памяти")}</div>
            ) : (
              <>
                <div className="mb-1.5 text-xs text-ink3">
                  {tx("Готовлю библиотеку к сравнению")} · {lib.done}/{lib.total}
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-ink/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-vio to-acid transition-[width]" style={{ width: `${(lib.done / Math.max(1, lib.total)) * 100}%` }} />
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      <AnimatePresence mode="wait">
        {phase === "done" && best && (
          <motion.div key={best.t.id + best.s} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="grid gap-6 lg:grid-cols-[minmax(0,440px)_1fr]">
            <div className="glass shadow-deep relative overflow-hidden rounded-[40px] p-6 text-center">
              <div className="text-xs font-bold uppercase tracking-[0.2em] text-ink3">{tx(best.s > 0.72 ? "Нашли!" : "Самое близкое по звучанию")}</div>
              <div className="relative mx-auto mt-4 aspect-square w-full max-w-[290px]">
                <div className="absolute -inset-[6%]">
                  <GlyphBlob shape={best.t.seed % 8} hue={best.t.hue} active={currentId === best.t.id && isPlaying} />
                </div>
                <motion.div
                  initial={{ rotate: -16, scale: 0.6, opacity: 0 }}
                  animate={{ rotate: -5, scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 180, damping: 16, delay: 0.1 }}
                  className="absolute left-1/2 top-1/2 aspect-square w-[62%] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-[30px] shadow-[0_30px_60px_-16px_rgba(0,0,0,0.65)] ring-1 ring-white/20"
                >
                  <Cover t={best.t} spin={currentId === best.t.id && isPlaying} />
                </motion.div>
              </div>
              <div className="font-display text-2xl font-bold leading-tight">{best.t.title}</div>
              <div className="mt-1 text-sm text-ink3">
                {best.t.artist} · {tx(GENRES[best.t.genre].label)}
              </div>
              <div className="mt-4 font-display text-5xl font-black">
                <span className="text-grad">
                  <Counter value={Math.round(best.s * 100)} />%
                </span>
              </div>
              <div className="text-xs text-ink3">{tx("совпадение по звучанию")}</div>
              <div className="mt-5 flex items-center justify-center gap-3">
                <button
                  onClick={() => (currentId === best.t.id ? useStore.getState().togglePlay() : useStore.getState().playTrack(best.t.id, results.map((r) => r.t.id)))}
                  className="btn-grad flex items-center gap-2 rounded-full px-6 py-3 font-display text-sm font-bold"
                >
                  {currentId === best.t.id && isPlaying ? <MiniEq on /> : <Play className="h-4 w-4 fill-current" />}
                  {tx("Слушать")}
                </button>
                <LikeButton id={best.t.id} big />
              </div>
            </div>
            <div>
              <h3 className="mb-2 px-2 font-display text-lg font-bold">{tx("Ещё похоже звучат")}</h3>
              <div className="glass rounded-[30px] p-2">
                {results.slice(1).map((r) => (
                  <TrackRow key={r.t.id} t={r.t} sim={r.s} queue={results.map((x) => x.t.id)} />
                ))}
              </div>
              <p className="mt-4 px-2 text-xs leading-relaxed text-ink3">
                {tx("Сравнение терпит небольшую погрешность: чуть другой темп, тембр или тональность — и трек всё равно найдётся среди похожих.")}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
