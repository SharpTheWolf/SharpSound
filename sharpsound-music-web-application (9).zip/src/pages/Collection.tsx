import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, ChevronUp, Clock, Eye, EyeOff, Heart, Headphones, ListMusic, Lock, Play, Plus, Repeat2, Trash2, Upload, X } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Cover } from "../components/Cover";
import { GlyphBlob } from "../components/GlyphBlob";
import { Modal } from "../components/Modal";
import { PageTitle, ShapeCard, TrackRow } from "../components/ui";
import { ALBUMS, GENRES, GENRE_LIST, type CoverStyle, type Genre, type Track } from "../data/catalog";
import { computeTaste, type Taste } from "../lib/reco";
import { allTracks, useStore } from "../store";
import { cn } from "../utils/cn";
import { useI18n } from "../lib/i18n";

type Cat = "liked" | "long" | "repeat" | "recent" | "mine";
const CATS: { id: Cat; label: string; icon: typeof Heart }[] = [
  { id: "liked", label: "Мне нравится", icon: Heart },
  { id: "long", label: "Долго слушал", icon: Headphones },
  { id: "repeat", label: "На повторе", icon: Repeat2 },
  { id: "recent", label: "Недавнее", icon: Clock },
  { id: "mine", label: "Мои загрузки", icon: Upload },
];

function tasteColor(t: Taste) {
  let x = 0;
  let y = 0;
  for (const g of GENRE_LIST) {
    const a = (GENRES[g].hue / 180) * Math.PI;
    x += Math.cos(a) * t.weights[g];
    y += Math.sin(a) * t.weights[g];
  }
  const hue = ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
  const name =
    hue >= 250 && hue < 300 ? "фиолетовый неон" : hue >= 300 && hue < 340 ? "сахарная фуксия" : hue >= 340 || hue < 15 ? "раскалённый коралл" : hue < 50 ? "тёплый янтарь" : hue < 120 ? "кислотный лайм" : hue < 170 ? "мятный холод" : hue < 210 ? "морская глубина" : "ночной индиго";
  return { hue, name };
}

const listener = (h: number) =>
  h < 6 ? "Ночной слушатель: главное звучит после полуночи." : h < 12 ? "Утренний: музыка вместо будильника." : h < 18 ? "Дневной: саундтрек к делам." : "Вечерний: музыка, чтобы выдохнуть.";

function Radar({ weights }: { weights: Record<Genre, number> }) {
  const { t: tx } = useI18n();
  const n = GENRE_LIST.length;
  const max = Math.max(0.0001, ...GENRE_LIST.map((g) => weights[g]));
  const pt = (i: number, r: number) => {
    const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
    return [100 + Math.cos(a) * r, 100 + Math.sin(a) * r];
  };
  const poly = (r: (i: number) => number) => GENRE_LIST.map((_, i) => pt(i, r(i)).map((v) => v.toFixed(1)).join(",")).join(" ");
  const data = poly((i) => 14 + 62 * (weights[GENRE_LIST[i]] / max));
  return (
    <svg viewBox="-24 -14 248 228" className="w-full max-w-[300px]">
      <defs>
        <linearGradient id="radarG" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8b5cf6" stopOpacity="0.75" />
          <stop offset="1" stopColor="#b4f03c" stopOpacity="0.55" />
        </linearGradient>
      </defs>
      {[20, 40, 60, 80].map((r) => (
        <polygon key={r} points={poly(() => r)} fill="none" strokeWidth="1" style={{ stroke: "var(--line)" }} />
      ))}
      {GENRE_LIST.map((_, i) => {
        const [x, y] = pt(i, 80);
        return <line key={i} x1="100" y1="100" x2={x} y2={y} style={{ stroke: "var(--line)" }} />;
      })}
      <motion.polygon
        initial={{ points: poly(() => 6) }}
        animate={{ points: data }}
        transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
        fill="url(#radarG)"
        stroke="#c4b5fd"
        strokeWidth="1.5"
      />
      {GENRE_LIST.map((g, i) => {
        const [x, y] = pt(i, 97);
        return (
          <text key={g} x={x} y={y + 3} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="currentColor" className="text-ink2">
            {tx(GENRES[g].label)}
          </text>
        );
      })}
    </svg>
  );
}

function Bar({ label, v }: { label: string; v: number }) {
  const { t: tx } = useI18n();
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs font-semibold text-ink2">
        <span>{tx(label)}</span>
        <span className="tabular-nums">{Math.round(v * 100)}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-ink/10">
        <motion.div className="h-full rounded-full bg-gradient-to-r from-vio to-acid" initial={{ width: 0 }} animate={{ width: `${v * 100}%` }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }} />
      </div>
    </div>
  );
}

function CharacterCard({ taste }: { taste: Taste }) {
  const { t: tx, tr } = useI18n();
  const isPlaying = useStore((s) => s.isPlaying);
  const tilt = useRef<HTMLDivElement>(null);
  const g = taste.top;
  const meta = g ? GENRES[g] : null;
  return (
    <div
      className="glass shadow-deep relative overflow-hidden rounded-[44px] p-6"
      onMouseMove={(e) => {
        const el = tilt.current;
        if (!el) return;
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = `rotateX(${(-y * 14).toFixed(2)}deg) rotateY(${(x * 16).toFixed(2)}deg)`;
      }}
      onMouseLeave={() => {
        if (tilt.current) tilt.current.style.transform = "";
      }}
    >
      <div className="grid-fine absolute inset-0 opacity-40" />
      <div className="relative text-xs font-bold uppercase tracking-[0.2em] text-ink3">{tx("Персонаж твоей музыки")}</div>
      <div className="relative mx-auto mt-4 aspect-square w-full max-w-[330px]" style={{ perspective: 1000 }}>
        <div ref={tilt} className="tilt relative h-full w-full">
          <div className="absolute -inset-[2%]" style={{ transform: "translateZ(-30px)" }}>
            <GlyphBlob shape={g ? GENRE_LIST.indexOf(g) : 2} hue={meta?.hue ?? 260} active={isPlaying} />
          </div>
          <AnimatePresence mode="wait">
            {meta ? (
              <motion.img
                key={g}
                src={meta.char.img}
                alt={tx(meta.char.name)}
                draggable={false}
                initial={{ opacity: 0, scale: 0.75, rotate: -8 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  rotate: 0,
                  borderRadius: ["42% 58% 50% 50% / 48% 42% 58% 52%", "58% 42% 46% 54% / 52% 58% 42% 48%", "42% 58% 50% 50% / 48% 42% 58% 52%"],
                }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.7, borderRadius: { duration: 9, repeat: Infinity, ease: "easeInOut" } }}
                className="absolute inset-[11%] h-[78%] w-[78%] object-cover shadow-[0_30px_60px_-18px_rgba(0,0,0,0.7)]"
                style={{ transform: "translateZ(40px)" }}
              />
            ) : (
              <motion.div key="none" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 grid place-items-center font-display text-7xl font-black text-white/90" style={{ transform: "translateZ(40px)" }}>
                ?
              </motion.div>
            )}
          </AnimatePresence>
          {meta && (
            <div className="glass-strong absolute bottom-[2%] left-1/2 -translate-x-1/2 rounded-full px-4 py-2 font-display text-sm font-bold whitespace-nowrap" style={{ transform: "translateZ(70px)" }}>
              <span style={{ color: meta.color }}>●</span> {tx(meta.label)}
            </div>
          )}
        </div>
      </div>
      <div className="relative mt-6 text-center">
        <div className="font-display text-2xl font-black">{tx(meta ? meta.char.name : "Пока загадка")}</div>
        <p className="mx-auto mt-2 max-w-sm text-sm text-ink2">{tx(meta ? meta.char.desc : "Послушай несколько треков или поставь пару лайков — и персонаж проявится.")}</p>
        {g && <div className="mt-3 text-xs text-ink3">{Math.round(taste.weights[g] * 100)}% {tx("твоего вкуса")} {tr("это", "is")} {tx(GENRES[g].label).toLowerCase()}</div>}
      </div>
    </div>
  );
}

function TastePanel({ taste }: { taste: Taste }) {
  const { t: tx } = useI18n();
  const hide = useStore((s) => s.hideTaste);
  const setHide = useStore((s) => s.setHideTaste);
  const stats = useStore((s) => s.stats);
  const hours = useStore((s) => s.hours);
  const minutes = Math.round(Object.values(stats).reduce((a, s) => a + s.secs, 0) / 60);
  const peak = hours.indexOf(Math.max(...hours));
  const hmax = Math.max(1, ...hours);
  const color = tasteColor(taste);
  return (
    <div className="glass shadow-deep relative overflow-hidden rounded-[44px] p-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-ink3">{tx("Твой вкус")}</div>
          <div className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-acidink">
            <Lock className="h-3 w-3" /> {tx("видно только тебе, хранится на устройстве")}
          </div>
        </div>
        <button onClick={() => setHide(!hide)} className="btn-soft flex items-center gap-2 rounded-full px-3.5 py-2 text-xs font-bold">
          {hide ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
          {tx(hide ? "Показать" : "Скрыть")}
        </button>
      </div>
      <div className={cn("relative mt-5 transition-[filter,opacity] duration-500", hide && "pointer-events-none select-none opacity-60 blur-xl")}>
        {taste.total === 0 ? (
          <div className="grid place-items-center py-14 text-center">
            <div className="h-24 w-24">
              <GlyphBlob shape={4} hue={150} />
            </div>
            <div className="mt-4 font-display font-bold">{tx("Вкус ещё не сформирован")}</div>
            <p className="mt-1 max-w-xs text-sm text-ink3">{tx("Включи Резонанс или любой альбом — профиль начнёт собираться сам.")}</p>
          </div>
        ) : (
          <>
            <div className="grid items-center gap-6 sm:grid-cols-2">
              <div className="grid place-items-center">
                <Radar weights={taste.weights} />
              </div>
              <div className="space-y-3.5">
                <div className="flex items-center gap-3 rounded-[22px] bg-ink/[0.05] p-3">
                  <motion.div
                    className="h-11 w-11 shrink-0 rounded-[40%_60%_55%_45%/50%_45%_55%_50%]"
                    style={{ background: `radial-gradient(circle at 30% 30%, hsl(${color.hue} 95% 80%), hsl(${color.hue} 80% 50%))` }}
                    animate={{ rotate: [0, 12, -8, 0] }}
                    transition={{ duration: 6, repeat: Infinity }}
                  />
                  <div>
                    <div className="text-xs text-ink3">{tx("Оттенок твоего звука")}</div>
                    <div className="font-display text-sm font-bold">{tx(color.name)}</div>
                  </div>
                </div>
                <Bar label="Энергия" v={taste.f.energy} />
                <Bar label="Темнота" v={taste.f.dark} />
                <Bar label="Яркость" v={taste.f.bright} />
                <Bar label="Плотность" v={taste.f.dense} />
              </div>
            </div>
            <div className="mt-6 grid grid-cols-3 gap-2">
              {[
                { l: "минут музыки", v: String(minutes) },
                { l: "средний темп", v: `${Math.round(taste.bpm)} BPM` },
                { l: "пик прослушки", v: `${peak}:00` },
              ].map((x) => (
                <div key={x.l} className="rounded-[20px] bg-ink/[0.05] p-3 text-center">
                  <div className="font-display text-lg font-bold">{x.v}</div>
                  <div className="text-[11px] text-ink3">{tx(x.l)}</div>
                </div>
              ))}
            </div>
            <div className="mt-5">
              <div className="mb-2 flex justify-between text-xs text-ink3">
                <span>{tx("Когда ты слушаешь")}</span>
                <span>{tx(listener(peak))}</span>
              </div>
              <div className="flex h-14 items-end gap-[3px]">
                {hours.map((h, i) => (
                  <motion.div
                    key={i}
                    title={`${i}:00`}
                    className={cn("flex-1 rounded-t-[4px]", i === peak ? "bg-acid" : "bg-vio/50")}
                    initial={{ height: 0 }}
                    animate={{ height: `${Math.max(6, (h / hmax) * 100)}%` }}
                    transition={{ delay: i * 0.02, duration: 0.6 }}
                  />
                ))}
              </div>
            </div>
          </>
        )}
      </div>
      {hide && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <div className="glass-strong flex items-center gap-2 rounded-full px-5 py-3 font-display text-sm font-bold">
            <Lock className="h-4 w-4" /> {tx("Вкус скрыт")}
          </div>
        </div>
      )}
    </div>
  );
}

function PlaylistsSection() {
  const { t: tx, tr } = useI18n();
  const playlists = useStore((s) => s.playlists);
  const liked = useStore((s) => s.liked);
  const uploads = useStore((s) => s.uploads);
  const studioTracks = useStore((s) => s.studioTracks);
  const st = useStore.getState();
  const [name, setName] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const all = useMemo(() => allTracks(), [uploads, studioTracks]);
  const likedTracks = all.filter((t) => liked[t.id]);
  const create = () => {
    if (st.createPlaylist(name)) setName("");
  };
  return (
    <div className="mt-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ListMusic className="h-5 w-5 text-vio" />
          <h3 className="font-display text-lg font-bold">{tx("Плейлисты")}</h3>
          <span className="text-xs text-ink3">{tx("из любимых треков")}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <input
            value={name}
            maxLength={60}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") create(); }}
            placeholder={tx("Название плейлиста…")}
            aria-label={tx("Название плейлиста…")}
            className="w-52 rounded-full border border-line bg-ink/[0.03] px-4 py-2.5 text-sm outline-none transition-colors focus:border-vio"
          />
          <button onClick={create} className="btn-soft flex items-center gap-1.5 rounded-full px-4 py-2.5 text-sm font-bold">
            <Plus className="h-4 w-4" />{tx("Создать")}
          </button>
        </div>
      </div>
      {playlists.length === 0 ? (
        <p className="text-sm text-ink3">{tr("Пока нет плейлистов. Создай первый и добавь в него треки из избранного.", "No playlists yet. Create one and add tracks from your favorites.")}</p>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {playlists.map((pl, i) => {
            const tracks = pl.trackIds.map((id) => all.find((t) => t.id === id)).filter((t): t is Track => !!t);
            const open = openId === pl.id;
            return (
              <motion.div key={pl.id} layout initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className={cn("glass relative overflow-hidden rounded-[30px] p-4", open && "md:col-span-2 xl:col-span-1")}>
                <div className="grid-fine absolute inset-0 opacity-40" />
                <button onClick={() => st.deletePlaylist(pl.id)} aria-label={tx("Удалить плейлист")} className="absolute right-3 top-3 z-10 grid h-8 w-8 place-items-center rounded-full text-ink3 transition-colors hover:bg-[#ff5c7a]/15 hover:text-[#ff5c7a]">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
                <div className="relative flex items-center gap-3">
                  {tracks[0] ? (
                    <div className="h-14 w-14 shrink-0 -rotate-3 overflow-hidden rounded-[16px] shadow-md ring-1 ring-white/15"><Cover t={tracks[0]} /></div>
                  ) : (
                    <div className="h-14 w-14 shrink-0"><GlyphBlob shape={pl.shape} hue={pl.hue} glow={false} /></div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-display text-[15px] font-bold">{pl.name}</div>
                    <div className="text-xs text-ink3">{tracks.length} {tx("треков")}</div>
                  </div>
                  <button title={tx("Слушать всё")} disabled={!tracks.length} onClick={() => st.playTrack(tracks[0].id, tracks.map((t) => t.id))} className="btn-grad grid h-10 w-10 shrink-0 place-items-center rounded-full disabled:opacity-40">
                    <Play className="h-4 w-4 fill-current" />
                  </button>
                  <button onClick={() => setOpenId(open ? null : pl.id)} aria-label={tx("Открыть плейлист")} className="btn-soft grid h-10 w-10 shrink-0 place-items-center rounded-full">
                    {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </button>
                </div>
                <AnimatePresence initial={false}>
                  {open && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }} className="relative overflow-hidden">
                      <div className="mt-3 space-y-1">
                        {tracks.length ? (
                          tracks.map((t) => (
                            <div key={t.id} className="flex items-center gap-1">
                              <TrackRow t={t} queue={tracks.map((x) => x.id)} className="flex-1" />
                              <button onClick={() => st.removeFromPlaylist(pl.id, t.id)} aria-label={tx("Убрать из плейлиста")} className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-ink3 transition-colors hover:text-[#ff5c7a]">
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ))
                        ) : (
                          <p className="px-2 py-4 text-center text-xs text-ink3">{tx("Плейлист пока пуст")}</p>
                        )}
                        <select
                          aria-label={tx("Добавить из «Мне нравится»")}
                          defaultValue=""
                          onChange={(e) => { if (e.target.value) st.addToPlaylist(pl.id, e.target.value); e.target.value = ""; }}
                          className="w-full rounded-[16px] border border-line bg-solid px-3 py-2.5 text-xs outline-none transition-colors focus:border-vio"
                        >
                          <option value="">{tx("Добавить из «Мне нравится»")}</option>
                          {likedTracks.filter((t) => !pl.trackIds.includes(t.id)).map((t) => (
                            <option key={t.id} value={t.id}>{t.title} — {t.artist}</option>
                          ))}
                        </select>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}

interface AlbumView {
  key: string;
  title: string;
  artist: string;
  hue: number;
  cover: CoverStyle;
  seed: number;
  trackIds: string[];
  user?: boolean;
}

function AlbumsSection() {
  const { t: tx } = useI18n();
  const uploads = useStore((s) => s.uploads);
  const studioTracks = useStore((s) => s.studioTracks);
  const st = useStore.getState();
  const [open, setOpen] = useState<AlbumView | null>(null);
  const albums = useMemo(() => {
    const list: AlbumView[] = ALBUMS.map((a) => ({ key: a.id, title: a.title, artist: a.artist, hue: a.hue, cover: a.cover, seed: a.seed, trackIds: a.trackIds }));
    const groups = new Map<string, Track[]>();
    [...uploads, ...studioTracks].forEach((t) => groups.set(t.album, [...(groups.get(t.album) ?? []), t]));
    groups.forEach((ts, nm) => list.push({ key: "u" + nm, title: nm, artist: ts[0].artist, hue: ts[0].hue, cover: ts[0].cover, seed: ts[0].seed, trackIds: ts.map((t) => t.id), user: true }));
    return list;
  }, [uploads, studioTracks]);
  return (
    <section>
      <h2 className="mb-1 px-1 font-display text-2xl font-bold tracking-tight sm:text-[30px]">{tx("Альбомы")}</h2>
      <p className="mb-4 px-1 text-sm text-ink3">{tx("У каждого трека есть альбом — открой, чтобы послушать его целиком")}</p>
      <div className="no-scrollbar -mx-2 flex gap-4 overflow-x-auto px-2 pb-2 pt-4 sm:gap-6">
        {albums.map((a, i) => (
          <ShapeCard
            key={a.key}
            cover={{ id: a.key, title: a.title, hue: a.hue, cover: a.cover, seed: a.seed }}
            title={a.title}
            sub={`${a.artist} · ${a.trackIds.length} ${tx("треков")}`}
            hue={a.hue}
            shape={i % 8}
            active={false}
            playing={false}
            onPlay={() => setOpen(a)}
            className="w-[168px] sm:w-[182px]"
          />
        ))}
      </div>
      <AnimatePresence>
        {open && (
          <Modal title={open.title} onClose={() => setOpen(null)} className="max-w-[720px]">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm text-ink2">
                {open.artist} · {open.trackIds.length} {tx("треков")}
                {open.user && <span className="ml-2 rounded-full bg-acid/20 px-2 py-0.5 text-[10px] font-bold text-acidink">{tx("сообщество")}</span>}
              </div>
              <button className="btn-grad flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold" onClick={() => st.playTrack(open.trackIds[0], open.trackIds)}>
                <Play className="h-4 w-4 fill-current" />{tx("Слушать весь альбом")}
              </button>
            </div>
            <div className="space-y-1">
              {open.trackIds.map((id) => {
                const t = allTracks().find((x) => x.id === id);
                return t ? <TrackRow key={id} t={t} queue={open.trackIds} /> : null;
              })}
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </section>
  );
}

export default function Collection() {
  const { t: tx, tr } = useI18n();
  const liked = useStore((s) => s.liked);
  const stats = useStore((s) => s.stats);
  const uploads = useStore((s) => s.uploads);
  const studioTracks = useStore((s) => s.studioTracks);
  const [cat, setCat] = useState<Cat>("liked");
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const all = useMemo(() => allTracks(), [uploads, studioTracks]);
  const taste = useMemo(() => computeTaste(all, stats, liked), [all, stats, liked]);
  const lists: Record<Cat, Track[]> = useMemo(
    () => ({
      liked: all.filter((t) => liked[t.id]).sort((a, b) => liked[b.id] - liked[a.id]),
      long: all.filter((t) => (stats[t.id]?.secs ?? 0) >= 20).sort((a, b) => stats[b.id].secs - stats[a.id].secs),
      repeat: all.filter((t) => (stats[t.id]?.plays ?? 0) >= 2).sort((a, b) => stats[b.id].plays - stats[a.id].plays),
      recent: all
        .filter((t) => stats[t.id]?.last)
        .sort((a, b) => stats[b.id].last - stats[a.id].last)
        .slice(0, 24),
      mine: [...uploads, ...studioTracks],
    }),
    [all, liked, stats, uploads, studioTracks]
  );
  const artists = useMemo(() => {
    const m = new Map<string, { name: string; w: number; ids: string[]; t: Track }>();
    for (const t of all) {
      const w = (stats[t.id]?.secs ?? 0) / 60 + (liked[t.id] ? 3 : 0);
      const cur = m.get(t.artist) ?? { name: t.artist, w: 0, ids: [], t };
      cur.w += w;
      cur.ids.push(t.id);
      m.set(t.artist, cur);
    }
    return [...m.values()].filter((a) => a.w > 0).sort((a, b) => b.w - a.w).slice(0, 8);
  }, [all, stats, liked]);
  const list = lists[cat];
  const st = useStore.getState();

  return (
    <div className="space-y-10">
      <PageTitle title="Коллекция" sub={<>{tr("У твоей музыки есть", "Your music has")} <span className="font-bold text-grad">{tr("характер", "character")}</span>{tr(". Вот он.", ". Here it is.")}</>} />

      <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <CharacterCard taste={taste} />
        <TastePanel taste={taste} />
      </div>

      <section>
        <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-2">
          {CATS.map((c) => {
            const Icon = c.icon;
            const active = cat === c.id;
            return (
              <button key={c.id} onClick={() => setCat(c.id)} className={cn("relative flex shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold transition-colors", active ? "text-ink" : "text-ink3 hover:text-ink")}>
                {active && <motion.span layoutId="catpill" className="absolute inset-0 rounded-full bg-vio/20 ring-1 ring-vio/40" transition={{ type: "spring", stiffness: 420, damping: 34 }} />}
                <Icon className="relative h-4 w-4" />
                <span className="relative">{tx(c.label)}</span>
                <span className="relative rounded-full bg-ink/10 px-1.5 text-[11px] tabular-nums">{lists[c.id].length}</span>
              </button>
            );
          })}
        </div>
        <div className="glass mt-3 min-h-[200px] rounded-[36px] p-3 sm:p-4">
          <AnimatePresence mode="wait">
            <motion.div key={cat} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.3 }}>
              {list.length ? (
                <div className="grid gap-x-6 lg:grid-cols-2">
                  {list.map((t) => (
                    <TrackRow key={t.id} t={t} queue={list.map((x) => x.id)} />
                  ))}
                </div>
              ) : (
                <div className="grid place-items-center py-12 text-center">
                  <div className="h-20 w-20">
                    <GlyphBlob shape={CATS.findIndex((c) => c.id === cat) + 1} hue={[330, 270, 95, 190, 150][CATS.findIndex((c) => c.id === cat)]} />
                  </div>
                  <div className="mt-3 font-display font-bold">{tx("Пока пусто")}</div>
                  <p className="mt-1 max-w-xs text-sm text-ink3">
                    {tx(cat === "liked"
                      ? "Жми на сердечко у трека — он появится здесь (а помощник обрадуется)."
                      : cat === "mine"
                        ? "Загрузи свой трек во вкладке «Вклад в сообщество»."
                        : "Послушай что-нибудь — эта полка заполнится сама.")}
                  </p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
        {cat === "liked" && <PlaylistsSection />}
      </section>

      <AlbumsSection />

      {artists.length > 0 && (
        <section>
          <h2 className="mb-4 px-1 font-display text-2xl font-bold tracking-tight">{tx("Любимые исполнители")}</h2>
          <div className="no-scrollbar -mx-2 flex gap-5 overflow-x-auto px-2 pb-2">
            {artists.map((a, i) => {
              const al = ALBUMS.find((x) => x.artist === a.name);
              return (
                <motion.button
                  key={a.name}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  whileHover={{ y: -6 }}
                  onClick={() => st.playTrack(a.ids[0], a.ids)}
                  className="group w-[132px] shrink-0 text-center"
                >
                  <div className="relative mx-auto h-[132px] w-[132px] overflow-hidden rounded-full shadow-[0_20px_40px_-16px_rgba(0,0,0,0.6)] ring-2 ring-transparent transition-all group-hover:ring-vio">
                    <Cover t={al ? { id: al.id, title: al.title, hue: al.hue, cover: al.cover, seed: al.seed } : a.t} />
                  </div>
                  <div className="mt-2 truncate text-sm font-bold">{a.name}</div>
                </motion.button>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
