import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronLeft, Layers2, Minus, Music2, Play, Plus, RefreshCw, Route, Save, Scissors,
  SlidersHorizontal, Sparkles, Trash2, Volume2, VolumeX, ArrowLeftRight, Gauge,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { compose } from "../audio/synth";
import { PageTitle, TrackRow } from "../components/ui";
import { GENRES, GENRE_LIST, type Genre, type Track } from "../data/catalog";
import {
  appendPart, autoStructure, createMeta, cycleType, fmtTime, LANE_ICON, LANE_LABEL,
  LANE_OCT, metaSeconds, movePart, removePart, resizePart, resizeTotal, SECTION_HUE, SECTION_LABEL,
  SECTION_ORDER, splitPart, totalBars, VOICES, laneGrid, type LaneId, type SectionType, type StudioMeta,
} from "../data/studio";
import { censor } from "../lib/censor";
import { translate, useI18n } from "../lib/i18n";
import { useStore } from "../store";
import { cn } from "../utils/cn";

const coverByGenre: Record<Genre, Track["cover"]> = {
  synthwave: "bars", lofi: "blob", phonk: "claws", techno: "iso",
  ambient: "waves", rock: "ring", trap: "claws", hyperpop: "spiral",
};

function newSeed() {
  try { return crypto.getRandomValues(new Uint32Array(1))[0]; }
  catch { return (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0; }
}

function bpmFor(genre: Genre) {
  const [lo, hi] = {
    synthwave: [98, 116], lofi: [72, 86], phonk: [128, 146], techno: [124, 132],
    ambient: [60, 72], rock: [118, 146], trap: [136, 150], hyperpop: [150, 164],
  }[genre];
  return Math.round((lo + hi) / 2);
}

/* ---------------- small building blocks ---------------- */

function Chip({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[16px] border border-line bg-ink/[0.04] px-3 py-2">
      <div className="text-[9px] font-bold uppercase tracking-[0.16em] text-ink3">{label}</div>
      <div className="truncate font-display text-[13px] font-bold">{value}</div>
    </div>
  );
}

/** Pixel step preview for a lane. */
function LanePreview({ seed, laneId, voice, on }: { seed: number; laneId: LaneId; voice: string; on: boolean }) {
  const cells = useMemo(() => laneGrid(seed, laneId, voice, 24), [seed, laneId, voice]);
  return (
    <div className="flex h-8 shrink-0 items-end gap-[2px]" aria-hidden>
      {cells.map((hit, i) => (
        <span
          key={i}
          className={cn("w-[3px] rounded-[1px] transition-colors", hit ? (on ? "bg-gradient-to-t from-vio to-acid" : "bg-ink/20") : "bg-ink/[0.07]")}
          style={{ height: hit && on ? `${8 + ((i * 37) % 20)}px` : "4px" }}
        />
      ))}
    </div>
  );
}

function PartBlock({
  part, index, active, onClick,
}: { part: { id: string; type: SectionType; len: number }; index: number; active: boolean; onClick: () => void }) {
  const hue = SECTION_HUE[part.type];
  const { lang } = useI18n();
  return (
    <motion.button
      layout
      initial={{ opacity: 0, scaleY: 0.72 }}
      animate={{ opacity: 1, scaleY: 1 }}
      exit={{ opacity: 0, scaleY: 0.72 }}
      transition={{ type: "spring", stiffness: 300, damping: 28 }}
      onClick={onClick}
      style={{
        flexGrow: part.len, flexBasis: 0, minWidth: 52,
        background: `linear-gradient(155deg, hsl(${hue} 78% 56% / ${active ? 0.34 : 0.18}), hsl(${hue} 72% 44% / 0.06))`,
        borderColor: active ? `hsl(${hue} 92% 64%)` : "var(--line)",
      }}
      className="relative overflow-hidden rounded-[16px] border px-2 py-2 text-left transition-colors"
    >
      <span
        className="absolute inset-0 opacity-60"
        style={{ backgroundImage: `repeating-linear-gradient(90deg, rgba(255,255,255,.13) 0 1px, transparent 1px 100%)`, backgroundSize: `${100 / part.len}% 100%` }}
      />
      <span className="absolute left-1.5 top-1 text-[9px] font-black text-ink3">{index + 1}</span>
      <span className="relative flex h-full flex-col items-center justify-center gap-0.5 text-center">
        <span className="font-display text-[10.5px] font-bold leading-tight">{SECTION_LABEL[part.type][lang]}</span>
        <span className="text-[9.5px] text-ink3">{part.len}</span>
      </span>
    </motion.button>
  );
}

/* ---------------- main page ---------------- */

export default function Studio() {
  const { t: tx, tr, lang } = useI18n();
  const studioTracks = useStore((s) => s.studioTracks);
  const currentId = useStore((s) => s.currentId);
  const isPlaying = useStore((s) => s.isPlaying);
  const add = useStore((s) => s.addStudioTrack);

  const [draftId, setDraftId] = useState<string | null>(null);
  const draft = draftId ? studioTracks.find((t) => t.id === draftId) ?? null : null;

  // compose form
  const [genre, setGenre] = useState<Genre>("synthwave");
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [album, setAlbum] = useState("");
  const [bpm, setBpm] = useState(110);
  const [seed, setSeed] = useState(newSeed);
  const [notice, setNotice] = useState("");
  const [saving, setSaving] = useState(false);

  // editor state
  const [sel, setSel] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  const base = useMemo(() => compose(seed, genre), [seed, genre]);
  const safeTitle = !title.trim() || censor(title).ok;
  const safeArtist = !artist.trim() || censor(artist).ok;
  const ready = title.trim().length >= 2 && artist.trim().length >= 2 && safeTitle && safeArtist;
  const previewTitle = title.trim() || tr("Новый трек", "Untitled track");
  const previewArtist = artist.trim() || tr("Твоё имя", "Your artist name");

  const [voiceOverrides, setVoiceOverrides] = useState<Partial<Record<LaneId, string>>>({});
  const composeMeta = useMemo(() => {
    const m = createMeta(base, bpm);
    return { ...m, lanes: m.lanes.map((l) => (voiceOverrides[l.id] ? { ...l, voice: voiceOverrides[l.id]!, on: true } : l)) };
  }, [base, bpm, voiceOverrides]);
  const composeDuration = metaSeconds(composeMeta);
  const previewId = `studio-${seed.toString(36)}`;

  const preview: Track = useMemo(
    () => ({
      id: previewId, title: previewTitle, artist: previewArtist, album: album.trim() || translate("Моя студия"),
      albumId: `studio-${album.trim() || "my"}`, genre, bpm, duration: composeDuration, seed,
      hue: GENRES[genre].hue, cover: coverByGenre[genre],
      f: { ...GENRES[genre].base, tempo: Math.max(0, Math.min(1, (bpm - 60) / 110)) },
      tags: [GENRES[genre].label, "studio"], source: "synth", studio: true, draft: composeMeta,
    }),
    [previewId, previewTitle, previewArtist, album, genre, bpm, composeDuration, seed, composeMeta]
  );

  const guard = () => {
    if (ready) return true;
    setNotice(tr("Нужно название и имя исполнителя. Мат цензура не пропустит.", "A title and artist are required. Profanity is filtered."));
    if (!safeTitle || !safeArtist) useStore.getState().chibi("censor");
    return false;
  };

  const playTrack = (t: Track) => {
    useStore.getState().setStudioPreview(t);
    useStore.getState().playTrack(t.id, [t.id]);
  };

  const saveDraft = () => {
    if (!guard()) return;
    setSaving(true);
    window.setTimeout(() => {
      const t: Track = { ...preview, title: title.trim(), artist: artist.trim() };
      add(t);
      setSaving(false);
      setDraftId(t.id);
      setSel(null);
      useStore.getState().chibi("upload", translate("«{title}» готов. Дальше — редактор дорожек!", undefined, { title: t.title }));
    }, 480);
  };

  /* ---------------- editor ---------------- */
  const meta = draft?.draft ?? null;

  const patch = (fn: (m: StudioMeta) => StudioMeta) => {
    if (!draft?.draft) return;
    const next = fn(draft.draft);
    add({ ...draft, draft: next, bpm: next.bpm, duration: metaSeconds(next) });
  };

  const setLane = (id: LaneId, patchLane: Partial<{ on: boolean; voice: string; level: number; oct: number }>) =>
    patch((m) => ({ ...m, lanes: m.lanes.map((l) => (l.id === id ? { ...l, ...patchLane } : l)) }));

  useEffect(() => {
    if (draftId && !draft) setDraftId(null);
  }, [draftId, draft]);


  if (draft && meta) {
    const playing = currentId === draft.id && isPlaying;
    const bars = totalBars(meta.parts);
    const selPart = meta.parts.find((p) => p.id === sel) ?? null;
    const off = meta.lanes.filter((l) => !l.on);

    return (
      <div className="space-y-7">
        <PageTitle
          title={draft.title}
          accent={tr("редактор", "editor")}
          sub={`${draft.artist} · ${GENRES[draft.genre].label} · ${bars} ${tr("такт.", "bars")} · ${fmtTime(metaSeconds(meta))}`}
        />

        {/* transport */}
        <div className="glass-strong sticky top-3 z-30 flex flex-wrap items-center gap-2 rounded-[26px] p-2.5 shadow-deep">
          <button onClick={() => { setDraftId(null); setNotice(""); }} className="btn-soft flex items-center gap-1.5 rounded-full px-4 py-2.5 text-xs font-bold">
            <ChevronLeft className="h-4 w-4" />{tr("Новый", "New")}
          </button>
          <button onClick={() => playTrack(draft)} className="btn-grad flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-extrabold">
            {playing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4 fill-current" />}
            {playing ? tr("Играет", "Playing") : tr("Слушать", "Listen")}
          </button>
          <button onClick={() => useStore.getState().toast(tr("Черновик сохранён", "Draft saved"))} className="btn-soft flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-extrabold">
            <Save className="h-4 w-4" />{tr("Сохранить", "Save")}
          </button>
          <div className="ml-auto flex items-center gap-3 text-[11px] font-bold text-ink3">
            <span className="flex items-center gap-1.5"><Gauge className="h-3.5 w-3.5 text-acidink" />{meta.bpm} BPM</span>
            <span className="flex items-center gap-1.5"><Layers2 className="h-3.5 w-3.5 text-acidink" />{bars}</span>
          </div>
        </div>

        {/* music road */}
        <section className="glass shadow-deep relative overflow-hidden rounded-[34px] p-4 sm:p-6">
          <div className="grid-fine absolute inset-0 opacity-40" />
          <div className="relative">
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="flex items-center gap-2 font-display text-xl font-bold"><Route className="h-5 w-5 text-vio" />{tr("Дорога музыки", "Music road")}</h2>
                <p className="mt-1 text-xs text-ink3">{tr("Каждая строка — инструмент. Каждый блок — часть трека. Нажми на блок, чтобы изменить его.", "Each row is an instrument, each block is a section. Tap a block to edit it.")}</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button onClick={() => patch((m) => ({ ...m, parts: autoStructure(bars) }))} className="btn-soft flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-bold">
                  <Sparkles className="h-4 w-4 text-acidink" />{tr("Авто-структура", "Auto arrange")}
                </button>
                <button onClick={() => patch((m) => ({ ...m, parts: appendPart(m.parts, (m.parts[m.parts.length - 1]?.type ?? "verse") as SectionType, 8) }))} className="btn-grad flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-extrabold">
                  <Plus className="h-4 w-4" />{tr("Часть +8", "Part +8")}
                </button>
              </div>
            </div>

            {/* ruler */}
            <div className="mb-1.5 flex items-end gap-3">
              <div className="hidden w-[212px] shrink-0 text-[10px] font-bold uppercase tracking-[0.16em] text-ink3 lg:block">{tr("Дорожка", "Lane")}</div>
              <div className="flex min-w-0 flex-1 gap-1.5">
                {(() => {
                  let acc = 0;
                  return meta.parts.map((p) => {
                    const start = acc;
                    acc += p.len;
                    return (
                      <div key={p.id} style={{ flexGrow: p.len, flexBasis: 0, minWidth: 52 }} className="text-[9px] font-bold tabular-nums text-ink3">
                        {start + 1}
                      </div>
                    );
                  });
                })()}
                <div className="w-[76px] shrink-0" />
              </div>
            </div>

            {/* lanes */}
            <div className="space-y-1.5">
              {meta.lanes.filter((l) => l.on).map((lane) => (
                <div key={lane.id} className="flex items-stretch gap-3">
                  <div className="hidden w-[212px] shrink-0 items-center gap-2 rounded-[16px] border border-line bg-ink/[0.03] px-3 py-2 lg:flex">
                    <span className="text-base text-vio">{LANE_ICON[lane.id]}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-bold">{LANE_LABEL[lane.id][lang]}</span>
                      <span className="block truncate text-[9.5px] text-ink3">{VOICES[lane.id].find((v) => v.id === lane.voice)?.[lang] ?? lane.voice}</span>
                    </span>
                    <LanePreview seed={meta.seed} laneId={lane.id} voice={lane.voice} on />
                  </div>
                  <div className="flex min-w-0 flex-1 gap-1.5">
                    <AnimatePresence initial={false} mode="popLayout">
                      {meta.parts.map((p, i) => (
                        <PartBlock key={p.id} part={p} index={i} active={sel === p.id} onClick={() => setSel(sel === p.id ? null : p.id)} />
                      ))}
                    </AnimatePresence>
                    <div className="flex w-[76px] shrink-0 flex-col gap-1">
                      <button
                        onClick={() => setLane(lane.id, { on: false })}
                        title={tr("Убрать дорожку", "Remove lane")}
                        aria-label={tr("Убрать дорожку", "Remove lane")}
                        className="grid h-1/2 min-h-[22px] place-items-center rounded-[12px] text-ink3 transition-colors hover:bg-[#ff5c7a]/15 hover:text-[#ff5c7a]"
                      >
                        <VolumeX className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => setLane(lane.id, { level: lane.level >= 1.15 ? 0.3 : Math.min(1.2, lane.level + 0.3) })}
                        title={tr("Громкость", "Level")}
                        aria-label={tr("Громкость", "Level")}
                        className="grid h-1/2 min-h-[22px] place-items-center rounded-[12px] text-ink3 transition-colors hover:bg-vio/15 hover:text-vio"
                      >
                        <Volume2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* add lane */}
            <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3">
              <button onClick={() => setAddOpen((v) => !v)} className="btn-soft flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold">
                <Plus className="h-4 w-4 text-vio" />{tr("Добавить музыку", "Add music")}
              </button>
              <AnimatePresence>
                {addOpen && (
                  <motion.div initial={{ opacity: 0, width: 0 }} animate={{ opacity: 1, width: "auto" }} exit={{ opacity: 0, width: 0 }} className="flex flex-wrap gap-2 overflow-hidden">
                    {off.length === 0 && <span className="self-center text-xs text-ink3">{tr("Все инструменты уже в миксе", "Every instrument is already in the mix")}</span>}
                    {off.map((l) => (
                      <motion.button key={l.id} layout exit={{ opacity: 0, scale: 0.9 }} onClick={() => { setLane(l.id, { on: true }); setAddOpen(false); }}
                        className="flex items-center gap-2 rounded-full border border-dashed border-vio/45 px-3.5 py-2 text-xs font-bold transition-colors hover:bg-vio/12">
                        <span className="text-vio">{LANE_ICON[l.id]}</span>{LANE_LABEL[l.id][lang]}
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
              <span className="ml-auto text-[11px] text-ink3">{meta.lanes.filter((l) => l.on).length}/{meta.lanes.length} {tr("дорожек", "lanes")}</span>
            </div>

            {/* part toolbar */}
            <AnimatePresence mode="wait">
              {selPart && (
                <motion.div key={selPart.id} initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
                  className="mt-4 rounded-[22px] border border-line bg-ink/[0.03] p-3">
                  <div className="mb-2.5 flex flex-wrap items-center gap-2">
                    <span className="rounded-full px-3 py-1 text-[11px] font-bold text-white" style={{ background: `hsl(${SECTION_HUE[selPart.type]} 75% 48%)` }}>
                      {SECTION_LABEL[selPart.type][lang]} · {selPart.len} {tr("такт.", "bars")}
                    </span>
                    <span className="text-[11px] text-ink3">{tr("Правки применяются ко всем дорожкам", "Edits apply to every lane")}</span>
                    <button onClick={() => setSel(null)} className="ml-auto text-xs font-bold text-ink3 hover:text-ink">{tr("Готово", "Done")}</button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => patch((m) => ({ ...m, parts: splitPart(m.parts, selPart.id) }))} disabled={selPart.len < 8} className="btn-soft flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold disabled:opacity-40"><Scissors className="h-3.5 w-3.5" />{tr("Разделить", "Split")}</button>
                    <button onClick={() => patch((m) => ({ ...m, parts: cycleType(m.parts, selPart.id) }))} className="btn-soft flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold"><RefreshCw className="h-3.5 w-3.5" />{tr("Тип", "Type")}</button>
                    <button onClick={() => patch((m) => ({ ...m, parts: movePart(m.parts, selPart.id, -1) }))} className="btn-soft flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold"><ArrowLeftRight className="h-3.5 w-3.5 scale-x-[-1]" />{tr("Раньше", "Earlier")}</button>
                    <button onClick={() => patch((m) => ({ ...m, parts: movePart(m.parts, selPart.id, 1) }))} className="btn-soft flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold"><ArrowLeftRight className="h-3.5 w-3.5" />{tr("Позже", "Later")}</button>
                    <button onClick={() => patch((m) => ({ ...m, parts: resizePart(m.parts, selPart.id, 4) }))} className="btn-soft flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold"><Plus className="h-3.5 w-3.5" />4</button>
                    <button onClick={() => patch((m) => ({ ...m, parts: resizePart(m.parts, selPart.id, -4) }))} className="btn-soft flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold"><Minus className="h-3.5 w-3.5" />4</button>
                    <button onClick={() => { patch((m) => ({ ...m, parts: removePart(m.parts, selPart.id) })); setSel(null); }} disabled={meta.parts.length <= 1}
                      className="ml-auto flex items-center gap-1.5 rounded-full bg-[#ff5c7a]/12 px-3.5 py-2 text-xs font-bold text-[#ff5c7a] disabled:opacity-40"><Trash2 className="h-3.5 w-3.5" />{tr("Удалить", "Delete")}</button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* length presets */}
            <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-3">
              <span className="text-xs font-bold text-ink2">{tr("Длина", "Length")}</span>
              {[16, 32, 48, 64, 96].map((n) => (
                <button key={n} onClick={() => patch((m) => ({ ...m, parts: resizeTotal(m.parts, n) }))}
                  className={cn("rounded-full px-3.5 py-1.5 text-xs font-bold transition-colors", bars === n ? "bg-vio text-white" : "btn-soft")}>{n}</button>
              ))}
              <span className="ml-auto font-display text-sm font-bold text-acidink">{bars} {tr("такт.", "bars")}</span>
            </div>
          </div>
        </section>

        {/* mixer: timbres */}
        <section className="glass rounded-[34px] p-4 sm:p-6">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold"><SlidersHorizontal className="h-5 w-5 text-vio" />{tr("Тембры и тоны", "Timbres and tones")}</h2>
          <p className="mt-1 text-xs text-ink3">{tr("Меняй инструмент каждой дорожки, громкость и октаву — звук пересобирается сразу.", "Swap each lane's instrument, level and octave — the sound rebuilds instantly.")}</p>
          <div className="mt-4 grid gap-3 lg:grid-cols-2">
            {meta.lanes.map((lane) => (
              <motion.div layout key={lane.id} className={cn("rounded-[24px] border p-4 transition-colors", lane.on ? "border-line bg-ink/[0.035]" : "border-dashed border-line bg-transparent opacity-70")}>
                <div className="flex items-center gap-3">
                  <span className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-[14px] text-lg", lane.on ? "bg-vio/15 text-vio" : "bg-ink/[0.06] text-ink3")}>{LANE_ICON[lane.id]}</span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-display text-sm font-bold">{LANE_LABEL[lane.id][lang]}</div>
                    <div className="text-[10px] text-ink3">{lane.on ? VOICES[lane.id].find((v) => v.id === lane.voice)?.[lang] : tr("выключено", "muted")}</div>
                  </div>
                  <button onClick={() => setLane(lane.id, { on: !lane.on })} aria-pressed={lane.on}
                    className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", lane.on ? "bg-vio" : "bg-ink/15")}>
                    <motion.span layout transition={{ type: "spring", stiffness: 520, damping: 30 }} className={cn("absolute top-1 h-4 w-4 rounded-full bg-white shadow", lane.on ? "left-6" : "left-1")} />
                  </button>
                </div>

                {lane.on && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="overflow-hidden">
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {VOICES[lane.id].map((v) => (
                        <button key={v.id} onClick={() => setLane(lane.id, { voice: v.id })}
                          className={cn("rounded-full px-3 py-1.5 text-[11px] font-bold transition-colors", lane.voice === v.id ? "bg-vio text-white shadow-[0_6px_16px_-8px_var(--vio)]" : "btn-soft text-ink2")}>
                          {v[lang]}
                        </button>
                      ))}
                    </div>
                    <div className="mt-3 flex items-center gap-3">
                      <Volume2 className="h-4 w-4 shrink-0 text-ink3" />
                      <input type="range" min={0.2} max={1.2} step={0.05} value={lane.level}
                        onChange={(e) => setLane(lane.id, { level: Number(e.target.value) })}
                        className="range w-full" style={{ ["--val" as string]: `${(lane.level / 1.2) * 100}%` }}
                        aria-label={`${LANE_LABEL[lane.id][lang]} ${tr("громкость", "level")}`} />
                      <span className="w-9 shrink-0 text-right text-[10px] font-bold tabular-nums text-ink3">{Math.round(lane.level * 100)}</span>
                    </div>
                    {LANE_OCT[lane.id] && (
                      <div className="mt-2.5 flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-ink3">{tr("Октава", "Octave")}</span>
                        {[-1, 0, 1].map((o) => (
                          <button key={o} onClick={() => setLane(lane.id, { oct: o })}
                            className={cn("rounded-full px-2.5 py-1 text-[11px] font-bold transition-colors", lane.oct === o ? "bg-acid text-[#0b0614]" : "btn-soft")}>
                            {o > 0 ? `+${o}` : o}
                          </button>
                        ))}
                      </div>
                    )}
                    <div className="mt-3 flex items-center gap-3">
                      <LanePreview seed={meta.seed} laneId={lane.id} voice={lane.voice} on={lane.on} />
                      <span className="ml-auto rounded-full bg-acid/12 px-2 py-1 text-[10px] font-black text-acidink">[{lane.id.slice(0, 2)}]</span>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
        </section>

        {/* summary */}
        <section className="glass rounded-[34px] p-4 sm:p-6">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold"><Music2 className="h-5 w-5 text-acidink" />{tr("Из чего состоит трек", "What the track is made of")}</h2>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
            <Chip label={tr("Жанр", "Genre")} value={GENRES[draft.genre].label} />
            <Chip label="BPM" value={String(meta.bpm)} />
            <Chip label={tr("Длина", "Length")} value={fmtTime(metaSeconds(meta))} />
            <Chip label={tr("Тактов", "Bars")} value={String(bars)} />
            <Chip label={tr("Частей", "Sections")} value={String(meta.parts.length)} />
            <Chip label={tr("Дорожек", "Lanes")} value={String(meta.lanes.filter((l) => l.on).length)} />
            <Chip label={tr("Исполнитель", "Artist")} value={draft.artist} />
            <Chip label={tr("Альбом", "Album")} value={draft.album} />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {SECTION_ORDER.map((type) => {
              const n = meta.parts.filter((p) => p.type === type).reduce((a, p) => a + p.len, 0);
              if (!n) return null;
              return (
                <span key={type} className="rounded-full px-3 py-1.5 text-[11px] font-bold"
                  style={{ background: `hsl(${SECTION_HUE[type]} 75% 48% / .16)`, color: `hsl(${SECTION_HUE[type]} 85% 72%)` }}>
                  {SECTION_LABEL[type][lang]} · {n}
                </span>
              );
            })}
          </div>
        </section>

        <SavedList draftId={draft.id} onEdit={(id) => { setDraftId(id); setSel(null); }} />
      </div>
    );
  }

  /* ---------------- compose view ---------------- */
  return (
    <div className="space-y-8">
      <PageTitle title="Мини-студия" accent="SharpSound" sub="Собери трек: жанр, темп и тембры. После сохранения откроется дорога музыки — с частями, дорожками и добавлением новых инструментов." />

      <section className="glass shadow-deep relative overflow-hidden rounded-[40px] p-5 sm:p-8">
        <div className="grid-fine absolute inset-0 opacity-45" />
        <div className="absolute -right-14 -top-20 h-64 w-64 rounded-full bg-vio/20 blur-3xl" />
        <div className="relative grid gap-8 xl:grid-cols-[minmax(0,1fr)_minmax(320px,0.75fr)]">
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="text-xs font-bold text-ink2">{tx("Название")}
                <input value={title} maxLength={80} onChange={(e) => { setTitle(e.target.value); setNotice(""); }} placeholder={tr("Например: Неоновый дождь", "Example: Neon rain")}
                  className={cn("mt-2 w-full rounded-[18px] border bg-ink/[0.04] px-4 py-3.5 text-sm outline-none transition-colors placeholder:text-ink3", !safeTitle ? "border-[#ff5c7a]" : "border-line focus:border-vio")} />
              </label>
              <label className="text-xs font-bold text-ink2">{tx("Исполнитель")}
                <input value={artist} maxLength={60} onChange={(e) => { setArtist(e.target.value); setNotice(""); }} placeholder={tr("Твой псевдоним", "Your artist name")}
                  className={cn("mt-2 w-full rounded-[18px] border bg-ink/[0.04] px-4 py-3.5 text-sm outline-none transition-colors placeholder:text-ink3", !safeArtist ? "border-[#ff5c7a]" : "border-line focus:border-vio")} />
              </label>
            </div>
            <label className="block text-xs font-bold text-ink2">{tx("Альбом")}
              <input value={album} maxLength={60} onChange={(e) => setAlbum(e.target.value)} placeholder={tr("Моя студия", "My Studio")}
                className="mt-2 w-full rounded-[18px] border border-line bg-ink/[0.04] px-4 py-3.5 text-sm outline-none transition-colors placeholder:text-ink3 focus:border-vio" />
            </label>

            <div>
              <div className="mb-3 text-xs font-bold text-ink2">{tx("Жанр")}</div>
              <div className="flex flex-wrap gap-2">
                {GENRE_LIST.map((g) => (
                  <motion.button key={g} whileTap={{ scale: 0.94 }} onClick={() => { setGenre(g); setBpm(bpmFor(g)); setSeed(newSeed()); }}
                    className={cn("rounded-full px-4 py-2 text-xs font-bold transition-colors", genre === g ? "bg-vio text-white shadow-[0_6px_18px_-8px_var(--vio)]" : "btn-soft text-ink2")}>
                    {tx(GENRES[g].label)}
                  </motion.button>
                ))}
              </div>
            </div>

            <div className="rounded-[22px] bg-ink/[0.04] p-4">
              <div className="mb-3 flex items-center justify-between">
                <span className="flex items-center gap-2 text-xs font-bold text-ink2"><SlidersHorizontal className="h-4 w-4 text-vio" />{tr("Темп", "Tempo")}</span>
                <span className="font-display text-sm font-bold text-acidink">{bpm} <span className="text-xs text-ink3">BPM</span></span>
              </div>
              <input type="range" min={40} max={200} value={bpm} onChange={(e) => setBpm(Number(e.target.value))} className="range w-full"
                style={{ ["--val" as string]: `${((bpm - 40) / 160) * 100}%` }} aria-label={tr("Темп", "Tempo")} />
              <div className="mt-2 flex justify-between text-[10px] text-ink3"><span>40</span><span>{tr("Медленно", "Slow")}</span><span>{tr("Быстро", "Fast")}</span><span>200</span></div>
            </div>

            <div className="rounded-[22px] bg-ink/[0.04] p-4">
              <div className="mb-3 text-xs font-bold text-ink2">{tr("Стартовые тембры", "Starting timbres")}</div>
              <div className="space-y-2">
                {(["drums", "bass", "chords", "lead"] as LaneId[]).map((id) => {
                  const lane = composeMeta.lanes.find((l) => l.id === id)!;
                  const on = lane.on;
                  return (
                    <div key={id} className={cn("flex flex-wrap items-center gap-2 rounded-[16px] px-3 py-2", on ? "bg-vio/[0.07]" : "opacity-55")}>
                      <span className="w-[92px] shrink-0 text-[11px] font-bold">{LANE_ICON[id]} {LANE_LABEL[id][lang]}</span>
                      <div className="flex min-w-0 flex-1 flex-wrap gap-1.5">
                        {VOICES[id].slice(0, 5).map((v) => (
                          <button key={v.id} onClick={() => patchComposeLane(id, v.id)}
                            className={cn("rounded-full px-2.5 py-1 text-[10.5px] font-bold transition-colors", lane.voice === v.id ? "bg-acid text-[#0b0614]" : "btn-soft")}>
                            {v[lang]}
                          </button>
                        ))}
                      </div>
                      {!on && <span className="text-[10px] text-ink3">{tr("нет в жанре", "not in this genre")}</span>}
                    </div>
                  );
                })}
              </div>
              <p className="mt-3 text-[11px] leading-relaxed text-ink3">{tr("Остальные тембры, октавы и громкости — в редакторе после сохранения.", "More timbres, octaves and levels are in the editor after you save.")}</p>
            </div>

            <div className="flex flex-wrap gap-3">
              <button onClick={() => (ready ? playTrack(preview) : guard())} className="btn-grad flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-extrabold">
                <Play className="h-4 w-4 fill-current" />{tr("Послушать", "Preview")}
              </button>
              <button onClick={saveDraft} disabled={saving || !ready} className="btn-soft flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-extrabold disabled:opacity-45">
                {saving ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}{tr("Сохранить черновик", "Save draft")}
              </button>
              <button onClick={() => { setSeed(newSeed()); setNotice(""); }} className="btn-soft grid h-12 w-12 place-items-center rounded-full" title={tr("Новый вариант", "New take")} aria-label={tr("Новый вариант", "New take")}>
                <RefreshCw className="h-4 w-4" />
              </button>
            </div>
            {!safeTitle || !safeArtist
              ? <p className="text-xs text-[#ff5c7a]">{tr("Цензура: поправь название или имя исполнителя.", "Word filter: adjust the title or artist name.")}</p>
              : notice
                ? <motion.p initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="text-xs font-semibold text-acidink">{notice}</motion.p>
                : <p className="text-xs leading-relaxed text-ink3">{tr("Трек создаётся синтезатором в браузере и сохраняется локально. Дорожки и части редактируются после сохранения.", "Tracks are synthesized in your browser and saved locally. Lanes and sections are editable after saving.")}</p>}
          </div>

          {/* preview visual */}
          <div className="relative min-h-[360px] overflow-hidden rounded-[34px] border border-vio/20 bg-[#080610]/60 sm:min-h-[460px]">
            <div className="grid-fine absolute inset-0 opacity-50" />
            <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-full border border-white/10 bg-black/25 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-white/65 backdrop-blur">
              <span className={cn("h-1.5 w-1.5 rounded-full", currentId === preview.id && isPlaying ? "blink-dot bg-acid" : "bg-vio")} />
              {currentId === preview.id && isPlaying ? tr("Играет", "Playing") : tr("Волна", "Waveform")}
            </div>

            {/* mini music road preview */}
            <div className="absolute inset-x-4 top-14 z-10 space-y-1.5">
              {composeMeta.lanes.filter((l) => l.on).map((lane) => (
                <div key={lane.id} className="flex items-center gap-2">
                  <span className="w-16 shrink-0 text-right text-[9.5px] font-bold text-white/45">{LANE_LABEL[lane.id][lang]}</span>
                  <div className="flex min-w-0 flex-1 gap-1">
                    {composeMeta.parts.map((p, i) => {
                      const hue = SECTION_HUE[p.type];
                      return (
                        <motion.div key={p.id} initial={{ scaleX: 0.5, opacity: 0 }} animate={{ scaleX: 1, opacity: 1 }} transition={{ delay: i * 0.04 }}
                          style={{ flexGrow: p.len, flexBasis: 0, background: `hsl(${hue} 75% 50% / ${lane.id === "drums" ? 0.5 : 0.34})` }}
                          className="h-4 rounded-[5px]" />
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="absolute inset-x-0 bottom-4 z-10 flex items-end justify-between gap-3 px-5 text-white">
              <div className="min-w-0">
                <div className="truncate font-display text-base font-bold">{previewTitle}</div>
                <div className="truncate text-xs text-white/55">{previewArtist} · {GENRES[genre].label} · {bpm} BPM · {fmtTime(composeDuration)}</div>
              </div>
              <div className="flex h-8 items-end gap-1">
                {Array.from({ length: 12 }, (_, n) => (
                  <motion.span key={n} className="w-1 rounded-full bg-gradient-to-t from-vio to-acid"
                    animate={currentId === preview.id && isPlaying ? { height: [6, 8 + (n % 4) * 5, 10, 7 + (n % 3) * 6] } : { height: [5 + (n % 3), 8 + (n % 4) * 3, 6 + (n % 2) * 4] }}
                    transition={{ duration: currentId === preview.id && isPlaying ? 0.48 : 1.4, repeat: Infinity, delay: n * 0.05, ease: "easeInOut" }} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <SavedList draftId={null} onEdit={(id) => { setDraftId(id); setSel(null); }} />
    </div>
  );

  function patchComposeLane(id: LaneId, voice: string) {
    setSeed((s) => s);
    setComposeVoice(id, voice);
  }

  function setComposeVoice(id: LaneId, voice: string) {
    // compose preview meta is derived, so we keep a local override through draft-less state
    setVoiceOverrides((prev) => ({ ...prev, [id]: voice }));
  }
}

function SavedList({ draftId, onEdit }: { draftId: string | null; onEdit: (id: string) => void }) {
  const { t: tx, tr } = useI18n();
  const studioTracks = useStore((s) => s.studioTracks);
  const del = useStore((s) => s.deleteStudioTrack);
  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold">{tr("Мои треки", "My tracks")}</h2>
          <p className="mt-1 text-sm text-ink3">{tr("Карандаш открывает редактор: части, дорожки, тембры", "The pencil opens the editor: sections, lanes, timbres")}</p>
        </div>
        <span className="text-xs tabular-nums text-ink3">{studioTracks.length}</span>
      </div>
      {studioTracks.length ? (
        <div className="glass rounded-[30px] p-3">
          <AnimatePresence initial={false}>
            {studioTracks.map((t) => (
              <motion.div key={t.id} layout exit={{ opacity: 0, x: 40 }} className="flex items-center gap-1">
                <TrackRow t={t} queue={studioTracks.map((x) => x.id)} className="flex-1" />
                <button onClick={() => onEdit(t.id)} title={tr("Редактировать", "Edit")} aria-label={tr("Редактировать", "Edit")}
                  className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-full transition-colors", draftId === t.id ? "bg-vio text-white" : "text-ink3 hover:bg-vio/15 hover:text-vio")}>
                  <Scissors className="h-4 w-4" />
                </button>
                <button onClick={() => del(t.id)} title={tx("Удалить")} aria-label={tx("Удалить")}
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-ink3 transition-colors hover:bg-[#ff5c7a]/15 hover:text-[#ff5c7a]">
                  <Trash2 className="h-4 w-4" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="py-8 text-center text-sm text-ink3">{tr("Здесь появятся твои треки.", "Your tracks will appear here.")}</div>
      )}
    </section>
  );
}
