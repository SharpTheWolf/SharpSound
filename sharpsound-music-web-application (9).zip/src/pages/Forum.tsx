import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight, Bell, BellOff, BookOpen, Check, ChevronDown, CircleHelp, ImagePlus, MessageCircle, MessagesSquare, Pencil, Pin, Plus, Quote, Search, Send, ShieldCheck, ThumbsUp, Trash, Upload, X } from "lucide-react";
import { useDeferredValue, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { GlyphBlob } from "../components/GlyphBlob";
import { Logo } from "../components/Logo";
import { Modal } from "../components/Modal";
import { FormatHelp } from "../components/forum/FormatHelp";
import { ForumArt } from "../components/forum/ForumArt";
import { RichEditor, type EditorHandle } from "../components/forum/RichEditor";
import { RichText, TrackEmbed } from "../components/forum/RichText";
import { ROOMS, type ForumAuthor, type Topic, type TopicDraft, type TopicKind } from "../data/forum";
import { plainBBCode } from "../lib/bbcode";
import { censor } from "../lib/censor";
import { useForum, type ForumResult } from "../lib/forumStore";
import { localText, useI18n, type Lang } from "../lib/i18n";
import { allTracks, useStore } from "../store";
import { cn } from "../utils/cn";

const ease = [0.22, 1, 0.36, 1] as const;
const hues = [270, 95, 190, 315, 28, 215];
type View = "all" | "following" | "mine" | "replied";
type Filter = "all" | TopicKind;
const nameOf = (author: ForumAuthor, lang: Lang) => author.id === "me" && author.name === "Listener" ? (lang === "ru" ? "Вы" : "You") : author.name;
const dateOf = (timestamp: number, lang: Lang) => new Intl.DateTimeFormat(lang === "ru" ? "ru-RU" : "en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(timestamp);
function ago(timestamp: number, lang: Lang) {
  const m = Math.max(0, (Date.now() - timestamp) / 60000);
  const f = new Intl.RelativeTimeFormat(lang, { numeric: "auto" });
  return m < 1 ? (lang === "ru" ? "только что" : "just now") : m < 60 ? f.format(-Math.floor(m), "minute") : m < 1440 ? f.format(-Math.floor(m / 60), "hour") : f.format(-Math.floor(m / 1440), "day");
}
function errorText(result: ForumResult, tr: (ru: string, en: string) => string, reply = false) {
  if (result.ok) return "";
  if (result.error === "short" && reply) return tr("Напиши ответ не короче 6 символов.", "Write a reply with at least 6 characters.");
  return result.error === "censor" ? tr("Убери мат из текста перед публикацией.", "Please remove profanity before posting.") : result.error === "missing" ? tr("Сообщение больше не доступно.", "This post is no longer available.") : tr("Нужно название от 4 символов и сообщение от 6 символов (или изображение).", "Add a title with at least 4 characters and a message with at least 6 characters (or an image).");
}

function Avatar({ author, size = 50 }: { author: ForumAuthor; size?: number }) {
  return <div className="relative shrink-0" style={{ width: size, height: size }}>
    {author.team ? <Logo size={size} className="drop-shadow-[0_5px_12px_rgba(124,58,237,.25)]" /> : <><GlyphBlob shape={author.shape} hue={author.hue} glow={false} className="absolute -inset-[15%] h-[130%] w-[130%]" /><span className="absolute inset-0 grid place-items-center font-display font-extrabold text-white drop-shadow-lg" style={{ fontSize: size * 0.31 }}>{author.name.slice(0, 1).toUpperCase()}</span></>}
  </div>;
}

function Vote({ id, count }: { id: string; count: number }) {
  const on = useForum((s) => !!s.votes[id]);
  const [burst, setBurst] = useState(0);
  const { tr } = useI18n();
  return <motion.button type="button" whileTap={{ scale: 0.88 }} onClick={() => { useForum.getState().toggleVote(id); if (!on) { setBurst((v) => v + 1); useStore.getState().chibi("like"); } }} aria-pressed={on} aria-label={tr("Нравится сообщение", "Like post")} className={cn("relative flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition-colors", on ? "bg-acid/15 text-acidink" : "bg-ink/5 text-ink3 hover:bg-vio/15 hover:text-ink")}>
    <ThumbsUp className={cn("h-3.5 w-3.5", on && "fill-current")} /><AnimatePresence mode="popLayout" initial={false}><motion.span key={String(count + (on ? 1 : 0))} initial={{ y: 5, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -5, opacity: 0 }} className="tabular-nums">{count + (on ? 1 : 0)}</motion.span></AnimatePresence>
    {burst > 0 && <span key={burst} className="pointer-events-none absolute left-1/2 top-1/2">{[0, 1, 2, 3, 4].map((i) => <motion.span key={i} initial={{ x: 0, y: 0, opacity: 1, scale: 0.8 }} animate={{ x: Math.cos(i * 1.25) * 27, y: Math.sin(i * 1.25) * 23, opacity: 0, scale: 0 }} transition={{ duration: 0.55 }} className="absolute h-1.5 w-1.5 rounded-[2px] bg-acid" />)}</span>}
  </motion.button>;
}

function ProfileEditor({ onClose }: { onClose: () => void }) {
  const { tr } = useI18n();
  const profile = useForum((s) => s.profile);
  const [name, setName] = useState(profile.name);
  const [style, setStyle] = useState({ hue: profile.hue, shape: profile.shape });
  const [error, setError] = useState("");
  return <Modal title={tr("Твой профиль в сообществе", "Your community profile")} onClose={onClose} className="max-w-[520px]">
    <div className="mb-5 flex justify-center"><Avatar author={{ id: "me", name: name || "Listener", ...style }} size={90} /></div>
    <label className="block text-xs font-bold text-ink2">{tr("Имя или ник", "Name or alias")}<input data-autofocus value={name} maxLength={28} onChange={(e) => { setName(e.target.value); setError(""); }} placeholder={tr("Как к тебе обращаться?", "What should we call you?")} className="mt-2 w-full rounded-[20px] border border-line bg-ink/5 px-4 py-3.5 text-sm text-ink outline-none focus:border-vio" /></label>
    <div className="mt-5 grid grid-cols-6 gap-2">{hues.map((hue, i) => <motion.button whileHover={{ y: -4 }} whileTap={{ scale: 0.9 }} key={hue} onClick={() => setStyle({ hue, shape: i })} aria-label={`${tr("Аватар", "Avatar")} ${i + 1}`} aria-pressed={style.hue === hue} className={cn("rounded-[18px] p-1.5", style.hue === hue ? "bg-vio/15 ring-1 ring-vio/50" : "hover:bg-ink/5")}><GlyphBlob shape={i} hue={hue} glow={false} /></motion.button>)}</div>
    <p className="mt-5 text-xs leading-relaxed text-ink3">{tr("Ник обновится во всех твоих темах и ответах. Это локальный профиль, регистрация пока не нужна.", "Your alias updates across your topics and replies. This is a local profile; no sign-up is needed yet.")}</p>
    {error && <p className="mt-3 text-sm text-[#ff5c7a]" role="alert">{error}</p>}
    <button onClick={() => { if (!useForum.getState().setProfile(name, style.hue, style.shape)) { setError(tr("Нужен ник до 28 символов, без мата и скобок разметки.", "Use an alias of up to 28 characters, without profanity or markup brackets.")); return; } onClose(); }} className="btn-grad ml-auto mt-5 flex items-center gap-2 rounded-full px-6 py-3 text-sm font-bold"><Check className="h-4 w-4" />{tr("Сохранить", "Save")}</button>
  </Modal>;
}

async function readImage(file: File) {
  if (!file.type.startsWith("image/") || file.size > 8 * 1048576) throw new Error("image");
  const url = URL.createObjectURL(file);
  try {
    const img = new Image(); img.src = url; await img.decode();
    const ratio = Math.min(1, 900 / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas"); canvas.width = Math.max(1, Math.round(img.width * ratio)); canvas.height = Math.max(1, Math.round(img.height * ratio));
    canvas.getContext("2d")?.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.8);
  } finally { URL.revokeObjectURL(url); }
}

function TopicComposer({ editing, onClose, onPublished }: { editing?: Topic; onClose: () => void; onPublished: (id: string) => void }) {
  const { lang, tr, text } = useI18n();
  useStore((s) => s.uploads);
  useStore((s) => s.studioTracks);
  const savedDraft = useForum((s) => s.draft);
  const [editDraft, setEditDraft] = useState<TopicDraft>(() => ({ title: editing ? text(editing.title) : "", body: editing ? text(editing.body) : "", room: editing?.room ?? "general", kind: editing?.kind ?? "discussion", image: editing?.image, trackId: editing?.trackId }));
  const draft = editing ? editDraft : savedDraft;
  const [error, setError] = useState("");
  const [imageBusy, setImageBusy] = useState(false);
  const imageInput = useRef<HTMLInputElement>(null);
  const change = (patch: Partial<TopicDraft>) => { setError(""); if (editing) setEditDraft((d) => ({ ...d, ...patch })); else useForum.getState().setDraft(patch); };
  const blocked = !censor(draft.title).ok || !censor(plainBBCode(draft.body)).ok || !!(draft.image && !censor(text(draft.image.caption)).ok);
  const valid = !blocked && draft.title.trim().length >= 4 && (plainBBCode(draft.body).length >= 6 || !!draft.image) && !imageBusy;
  const submit = () => {
    try {
      const result = editing ? useForum.getState().updateTopic(editing.id, draft) : useForum.getState().createTopic(draft);
      if (!result.ok) { setError(errorText(result, tr)); if (result.error === "censor") useStore.getState().chibi("censor"); return; }
      useStore.getState().chibi("post");
      useStore.getState().toast(tr(editing ? "Изменения сохранены" : "Обсуждение создано", editing ? "Changes saved" : "Discussion created"));
      onPublished(result.id);
    } catch { setError(tr("Не удалось сохранить. Возможно, память устройства заполнена.", "Could not save. Your device storage may be full.")); }
  };
  return <Modal title={tr(editing ? "Изменить обсуждение" : "Новое обсуждение", editing ? "Edit discussion" : "Start a discussion")} onClose={onClose}>
    <div className="mb-5 grid gap-3 sm:grid-cols-2">
      <label className="text-xs font-bold text-ink3">{tr("Раздел", "Room")}<select value={draft.room} onChange={(e) => change({ room: e.target.value as TopicDraft["room"] })} className="mt-2 w-full rounded-[16px] border border-line bg-solid px-3 py-3 text-sm text-ink outline-none focus:border-vio">{ROOMS.map((r) => <option key={r.id} value={r.id}>{text(r.label)}</option>)}</select></label>
      <label className="text-xs font-bold text-ink3">{tr("Тип публикации", "Post type")}<select value={draft.kind} onChange={(e) => change({ kind: e.target.value as TopicKind })} className="mt-2 w-full rounded-[16px] border border-line bg-solid px-3 py-3 text-sm text-ink outline-none focus:border-vio"><option value="discussion">{tr("Обсуждение", "Discussion")}</option><option value="artwork">{tr("Иллюстрация", "Artwork")}</option><option value="guide">{tr("Руководство", "Guide")}</option></select></label>
    </div>
    <input data-autofocus aria-label={tr("Название обсуждения", "Discussion title")} value={draft.title} maxLength={120} onChange={(e) => change({ title: e.target.value })} placeholder={tr("О чём поговорим?", "What shall we talk about?")} className={cn("mb-5 w-full rounded-[20px] border bg-ink/[0.03] px-4 py-4 font-display text-base font-bold outline-none focus:border-vio sm:text-lg", !censor(draft.title).ok ? "border-[#ff5c7a]" : "border-line")} />
    <RichEditor value={draft.body} onChange={(body) => change({ body })} onSubmit={submit} placeholder={tr("Начни разговор, поделись находкой или спроси совета...", "Start a conversation, share a discovery or ask for advice...")} />
    <div className="mt-4 flex flex-wrap items-center gap-3">
      <button type="button" disabled={imageBusy} onClick={() => imageInput.current?.click()} className="btn-soft flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-bold"><ImagePlus className="h-4 w-4" />{tr(imageBusy ? "Загружаю..." : "Добавить фото", imageBusy ? "Loading..." : "Add an image")}</button>
      <input ref={imageInput} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={async (e) => { const file = e.target.files?.[0]; e.target.value = ""; if (!file) return; setImageBusy(true); try { const src = await readImage(file); change({ image: { src, caption: "" }, kind: "artwork" }); } catch { setError(tr("Нужна картинка PNG, JPG или WEBP до 8 МБ.", "Choose a PNG, JPG or WEBP image under 8 MB.")); } finally { setImageBusy(false); } }} />
      <label className="min-w-0 flex-1"><select aria-label={tr("Прикрепить трек", "Attach a track")} value={draft.trackId ?? ""} onChange={(e) => change({ trackId: e.target.value || undefined })} className="w-full rounded-full border border-line bg-solid px-3 py-2.5 text-xs text-ink outline-none focus:border-vio"><option value="">{tr("Прикрепить трек из библиотеки", "Attach a library track")}</option>{allTracks().map((track) => <option key={track.id} value={track.id}>{track.title} / {track.artist}</option>)}</select></label>
    </div>
    {draft.image && <div className="relative mt-4 rounded-[24px] border border-line p-2"><img src={draft.image.src} alt={text(draft.image.caption) || tr("Прикреплённое изображение", "Attached image")} className="mx-auto max-h-56 rounded-[18px] object-contain" /><button type="button" onClick={() => change({ image: undefined })} className="glass-strong absolute right-4 top-4 grid h-8 w-8 place-items-center rounded-full" aria-label={tr("Удалить изображение", "Remove image")}><X className="h-4 w-4" /></button><input value={localText(draft.image.caption, lang)} onChange={(e) => change({ image: { src: draft.image!.src, caption: e.target.value } })} maxLength={120} placeholder={tr("Подпись к изображению (необязательно)", "Image caption (optional)")} className="mt-2 w-full rounded-[14px] bg-ink/5 px-3 py-2 text-xs outline-none" /></div>}
    {draft.trackId && <TrackEmbed id={draft.trackId} />}
    {(error || blocked) && <p className="mt-4 text-xs font-semibold text-[#ff5c7a]" role="alert">{error || tr("Цензура: убери мат из названия и текста.", "Word filter: remove profanity from the title and message.")}</p>}
    <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-5"><p className="max-w-[330px] text-[11px] leading-relaxed text-ink3">{tr(editing ? "Сохранится на этом устройстве." : "Черновик сохраняется на устройстве, даже если закрыть окно.", editing ? "Saved on this device." : "Your draft stays on this device, even if you close this window.")}</p><motion.button type="button" whileTap={{ scale: 0.96 }} onClick={submit} disabled={!valid} className="btn-grad flex items-center gap-2 rounded-full px-6 py-3 text-sm font-extrabold disabled:opacity-40"><Send className="h-4 w-4" />{tr(editing ? "Сохранить" : "Начать обсуждение", editing ? "Save changes" : "Post discussion")}</motion.button></div>
  </Modal>;
}

function Empty({ children }: { children: ReactNode }) {
  return <div className="flex flex-col items-center py-14 text-center"><div className="h-24 w-24"><GlyphBlob shape={6} hue={270} /></div><div className="mt-4 max-w-xs text-sm leading-relaxed text-ink3">{children}</div></div>;
}

export default function Forum() {
  const { lang, tr, text } = useI18n();
  const topics = useForum((s) => s.topics);
  const votes = useForum((s) => s.votes);
  const profile = useForum((s) => s.profile);
  const followed = useForum((s) => s.followed);
  const readAt = useForum((s) => s.readAt);
  const replyDrafts = useForum((s) => s.replyDrafts);
  const [selected, setSelected] = useState<string | null>(null);
  const [room, setRoom] = useState<TopicDraft["room"] | "all">("all");
  const [filter, setFilter] = useState<Filter>("all");
  const [view, setView] = useState<View>("all");
  const [query, setQuery] = useState("");
  const search = useDeferredValue(query);
  const [sort, setSort] = useState<"active" | "new" | "popular">("active");
  const [replySearch, setReplySearch] = useState("");
  const [composer, setComposer] = useState(false);
  const [editingTopic, setEditingTopic] = useState<Topic | undefined>();
  const [profileOpen, setProfileOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<{ topicId: string; replyId?: string } | null>(null);
  const [editingReply, setEditingReply] = useState<{ topicId: string; replyId: string; body: string } | null>(null);
  const [replyError, setReplyError] = useState("");
  const replyEditor = useRef<EditorHandle>(null);
  const topic = topics.find((t) => t.id === selected);
  const replyBody = selected ? replyDrafts[selected] ?? "" : "";

  useEffect(() => { const timer = setTimeout(() => useStore.getState().chibi("say", tr("Здесь можно спорить о звуке. О людях лучше не спорить.", "Argue about sound here. Not about people.")), 1400); return () => clearTimeout(timer); }, []);
  const openTopic = (id: string) => { setSelected(id); setReplySearch(""); setReplyError(""); useForum.getState().markRead(id); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const goBack = () => { setSelected(null); setReplyError(""); };
  const chooseRoom = (id: typeof room) => { setRoom(id); setView("all"); goBack(); };
  const startTopic = () => { setEditingTopic(undefined); setComposer(true); };

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase();
    return topics.filter((t) => (room === "all" || t.room === room) && (filter === "all" || t.kind === filter) && (view === "all" || view === "following" && followed.includes(t.id) || view === "mine" && t.author.id === "me" || view === "replied" && t.replies.some((r) => r.author.id === "me")) && (!q || `${text(t.title)} ${plainBBCode(text(t.body))} ${t.author.name} ${t.replies.map((r) => plainBBCode(text(r.body))).join(" ")}`.toLocaleLowerCase().includes(q))).sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || (sort === "new" ? b.createdAt - a.createdAt : sort === "popular" ? (b.votes + Number(!!votes[b.id]) + b.replies.length * 2) - (a.votes + Number(!!votes[a.id]) + a.replies.length * 2) : b.lastAt - a.lastAt));
  }, [topics, search, room, filter, view, followed, sort, votes, text]);
  const replies = topic?.replies.filter((r) => !replySearch.trim() || `${plainBBCode(text(r.body))} ${r.author.name}`.toLowerCase().includes(replySearch.trim().toLowerCase())) ?? [];

  const submitReply = () => {
    if (!topic) return;
    try {
      const result = useForum.getState().addReply(topic.id, replyBody);
      if (!result.ok) { setReplyError(errorText(result, tr, true)); if (result.error === "censor") useStore.getState().chibi("censor"); return; }
      setReplyError(""); setReplySearch(""); useForum.getState().markRead(topic.id); useStore.getState().chibi("reply");
      useStore.getState().toast(tr("Ответ опубликован", "Reply posted"));
      setTimeout(() => document.getElementById(`reply-${result.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 120);
    } catch { setReplyError(tr("Не получилось сохранить ответ. Проверь память устройства.", "Could not save your reply. Check your device storage.")); }
  };
  const quote = (author: ForumAuthor, body: string) => {
    if (!topic) return;
    const next = `${replyBody}${replyBody ? "\n" : ""}[quote=${author.name.replace(/[\[\]]/g, "")}]${body.slice(0, 3500)}[/quote]\n`;
    if (next.length > 10000) { useStore.getState().toast(tr("Черновик слишком длинный для цитаты", "The draft is too long for this quote")); return; }
    useForum.getState().setReplyDraft(topic.id, next);
    setTimeout(() => { document.getElementById("forum-reply-editor")?.scrollIntoView({ behavior: "smooth", block: "center" }); replyEditor.current?.focus(); }, 100);
  };
  const roomMeta = ROOMS.find((r) => r.id === room);
  const title = view === "following" ? tr("Мои подписки", "Following") : view === "mine" ? tr("Мои обсуждения", "My discussions") : view === "replied" ? tr("Мои ответы", "My replies") : roomMeta ? text(roomMeta.label) : tr("Все обсуждения", "All discussions");

  const sidebar = <aside className="min-w-0 space-y-5">
    <div className="glass rounded-[30px] p-5">
      <button onClick={() => setProfileOpen(true)} className="group flex w-full items-center gap-3 text-left"><Avatar author={{ id: "me", name: profile.name || "Listener", hue: profile.hue, shape: profile.shape }} size={47} /><span className="min-w-0 flex-1"><span className="block text-[10px] font-bold uppercase tracking-[.14em] text-ink3">{tr("Твой профиль", "Your profile")}</span><span className="block truncate text-sm font-extrabold">{profile.name || tr("Слушатель", "Listener")}</span></span><Pencil className="h-3.5 w-3.5 text-ink3 transition-colors group-hover:text-vio" /></button>
      <div className="mt-4 flex flex-col gap-0.5">{([{ id: "all", ru: "Все обсуждения", en: "All discussions", icon: MessagesSquare }, { id: "following", ru: "Подписки", en: "Following", icon: Bell }, { id: "mine", ru: "Мои темы", en: "My topics", icon: Pencil }, { id: "replied", ru: "Мои ответы", en: "My replies", icon: MessageCircle }] as const).map((item) => <button key={item.id} onClick={() => { setView(item.id); setRoom("all"); setFilter("all"); goBack(); }} className={cn("flex items-center gap-2.5 rounded-[16px] px-3 py-2.5 text-xs font-bold transition-colors", view === item.id && !selected ? "bg-vio/15 text-vio" : "text-ink2 hover:bg-ink/5")}><item.icon className="h-4 w-4" />{tr(item.ru, item.en)}{item.id === "following" && <span className="ml-auto text-ink3">{followed.length}</span>}</button>)}</div>
    </div>
    {topic && <div className="glass rounded-[30px] p-5"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-ink3">{tr("Обсуждение", "Discussion")}</div><button onClick={() => useForum.getState().toggleFollow(topic.id)} className={cn("flex w-full items-center justify-center gap-2 rounded-full px-4 py-3 text-xs font-extrabold", followed.includes(topic.id) ? "btn-soft text-acidink" : "btn-grad")}>{followed.includes(topic.id) ? <BellOff className="h-4 w-4" /> : <Bell className="h-4 w-4" />}{tr(followed.includes(topic.id) ? "Вы подписаны" : "Подписаться на тему", followed.includes(topic.id) ? "Following this topic" : "Follow discussion")}</button><p className="mt-3 text-[11px] leading-relaxed text-ink3">{tr("Подписка сохраняет тему в твоём списке. Письма и уведомления на сервер пока не отправляются.", "Following keeps this topic in your list. No emails or server notifications are sent yet.")}</p><div className="mt-4 border-t border-line pt-3 text-xs text-ink3">{tr("Создано", "Created")} {dateOf(topic.createdAt, lang)}</div></div>}
    <div className="px-1"><div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[.18em] text-ink3">{tr("Комнаты", "Rooms")}</div>{ROOMS.map((r) => <motion.button key={r.id} whileHover={{ x: 4 }} whileTap={{ scale: 0.97 }} onClick={() => chooseRoom(r.id)} className={cn("group flex w-full items-center gap-2 rounded-[23px] p-2 text-left", room === r.id ? "bg-vio/10" : "hover:bg-ink/[.035]")}><div className="h-11 w-11 shrink-0 transition-transform duration-500 group-hover:-rotate-6"><GlyphBlob shape={r.shape} hue={r.hue} glow={false} /></div><span className="min-w-0 flex-1"><span className="block text-[12px] font-extrabold">{text(r.label)}</span><span className="block truncate text-[10px] text-ink3">{text(r.desc)}</span></span><span className="text-[11px] tabular-nums text-ink3">{topics.filter((t) => t.room === r.id).length}</span></motion.button>)}</div>
    <div className="space-y-1 border-t border-line px-2 pt-3"><button onClick={() => { setHelpOpen(true); useStore.getState().chibi("format"); }} className="flex w-full items-center gap-2.5 rounded-[15px] p-2.5 text-xs font-bold text-ink2 hover:bg-ink/5"><BookOpen className="h-4 w-4 text-vio" />{tr("Форматирование текста", "Text formatting")}</button><button onClick={() => setRulesOpen(true)} className="flex w-full items-center gap-2.5 rounded-[15px] p-2.5 text-xs font-bold text-ink2 hover:bg-ink/5"><ShieldCheck className="h-4 w-4 text-acidink" />{tr("Правила обсуждений", "Discussion rules")}</button><button onClick={() => useStore.getState().setTab("contribute")} className="flex w-full items-center gap-2.5 rounded-[15px] p-2.5 text-xs font-bold text-ink2 hover:bg-ink/5"><Upload className="h-4 w-4 text-vio" />{tr("Вклад в сообщество", "Contribute music")}<ArrowUpRight className="ml-auto h-3 w-3" /></button></div>
    <p className="px-3 text-[10px] leading-relaxed text-ink3">{tr("Локальное пространство: начальные темы являются примерами, а твои публикации хранятся на устройстве. Для настоящего совместного форума нужен сервер.", "Local space: initial topics are examples, and your posts stay on your device. A server is needed for a shared, online forum.")}</p>
  </aside>;

  return <div className="space-y-7">
    <section className="relative min-h-[235px] pt-4 sm:min-h-[255px] sm:pt-7">
      <div className="pointer-events-none absolute -right-10 -top-20 h-[400px] w-[450px] rounded-full bg-vio/10 blur-[75px]" />
      <div className="absolute -right-8 -top-3 hidden h-[280px] w-[350px] opacity-90 sm:block lg:w-[395px]"><ForumArt /></div>
      <div className="relative z-10 max-w-[680px] sm:pointer-events-none"><div className="mb-5 flex items-center gap-2.5 text-[10px] font-extrabold uppercase tracking-[.24em] text-ink3"><span className="text-vio">SharpSound</span><span>/</span>{tr("Общий резонанс", "Shared resonance")}</div>
        <motion.h1 initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease }} className="font-display text-[clamp(34px,5.4vw,67px)] font-black leading-none tracking-[-.04em]">{tr("Сообщество", "Community")}<span className="text-acidink">.</span></motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }} className="mt-4 max-w-[400px] text-sm leading-relaxed text-ink2">{tr("Музыку слушаем вместе. Находки, вопросы и разговоры после последнего трека.", "Music brings us together. Discoveries, questions and conversations after the last track.")}</motion.p>
        <motion.button whileHover={{ y: -3 }} whileTap={{ scale: 0.96 }} onClick={startTopic} className="btn-grad pointer-events-auto mt-6 flex items-center gap-2 rounded-full px-6 py-3 text-sm font-extrabold"><Plus className="h-4 w-4" />{tr("Начать обсуждение", "Start a discussion")}</motion.button>
      </div>
    </section>

    <div className="no-scrollbar flex gap-6 overflow-x-auto border-b border-line px-1">{([{ id: "all", ru: "Всё", en: "All" }, { id: "discussion", ru: "Обсуждения", en: "Discussions" }, { id: "artwork", ru: "Иллюстрации", en: "Artwork" }, { id: "guide", ru: "Руководства", en: "Guides" }] as const).map((f) => <button key={f.id} onClick={() => { setFilter(f.id); goBack(); }} className={cn("relative shrink-0 pb-3 pt-1 text-sm font-extrabold", filter === f.id ? "text-ink" : "text-ink3 hover:text-ink")} aria-pressed={filter === f.id}>{tr(f.ru, f.en)}{filter === f.id && <motion.span layoutId="forum-type-underline" className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-gradient-to-r from-vio to-acid" transition={{ type: "spring", stiffness: 380, damping: 30 }} />}</button>)}</div>

    <div className="grid items-start gap-7 xl:grid-cols-[minmax(0,1fr)_275px]">
      <div className="min-w-0"><AnimatePresence mode="wait" initial={false}>
        {!topic ? <motion.section key="list" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.3 }}>
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-lg font-bold">{title}</h2><span className="mt-1 block text-[11px] text-ink3">{filtered.length} {tr("тем", "topics")}</span></div><label className="relative"><span className="sr-only">{tr("Сортировка обсуждений", "Sort discussions")}</span><select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="appearance-none rounded-full border border-line bg-panel py-2 pl-4 pr-8 text-xs font-bold outline-none"><option value="active">{tr("По активности", "Recent activity")}</option><option value="new">{tr("Последние", "Newest")}</option><option value="popular">{tr("Популярные", "Popular")}</option></select><ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-3 w-3 -translate-y-1/2 text-ink3" /></label></div>
          <div className="focus-ring glass mb-4 flex items-center gap-3 rounded-full px-4"><Search className="h-4 w-4 shrink-0 text-ink3" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={tr("Найти тему, автора или слова...", "Find topics, authors or words...")} aria-label={tr("Поиск обсуждений", "Search discussions")} className="min-w-0 flex-1 bg-transparent py-3.5 text-sm outline-none placeholder:text-ink3" />{query && <button aria-label={tr("Очистить поиск", "Clear search")} onClick={() => setQuery("")}><X className="h-4 w-4 text-ink3" /></button>}</div>
          <div className="glass overflow-hidden rounded-[30px] sm:rounded-[34px]">
            {filtered.length ? <AnimatePresence initial={false} mode="popLayout">{filtered.map((item, i) => {
              const r = ROOMS.find((r) => r.id === item.room)!;
              const unread = followed.includes(item.id) && item.lastAt > (readAt[item.id] ?? 0);
              return <motion.button layout="position" key={item.id} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 12 }} transition={{ duration: 0.32, delay: Math.min(i, 5) * 0.04, ease }} whileHover={{ backgroundColor: "rgba(139,92,246,.055)" }} onClick={() => openTopic(item.id)} className="forum-topic-row group flex w-full items-center gap-3 border-b border-line px-4 py-5 text-left last:border-b-0 sm:gap-4 sm:px-5">
                <div className="transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-105"><Avatar author={item.author} size={44} /></div>
                <div className="min-w-0 flex-1"><div className="mb-1.5 flex items-center gap-2 text-[10px] font-bold text-ink3">{item.pinned && <span className="flex items-center gap-1 text-acidink"><Pin className="h-2.5 w-2.5" />{tr("Закреплено", "Pinned")}</span>}<span>{text(r.label)}</span>{item.kind !== "discussion" && <span className="text-vio">/ {tr(item.kind === "artwork" ? "Иллюстрация" : "Руководство", item.kind === "artwork" ? "Artwork" : "Guide")}</span>}</div>
                  <div className="flex items-start gap-2"><h3 className="line-clamp-2 text-sm font-extrabold leading-snug transition-colors group-hover:text-vio sm:text-[15px]">{text(item.title)}</h3>{unread && <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-acid" />}</div>
                  <div className="mt-2 flex flex-wrap items-center gap-x-2 text-[11px] text-ink3"><span className={item.author.team ? "text-vio" : "text-ink2"}>{nameOf(item.author, lang)}</span><span>/</span><time dateTime={new Date(item.lastAt).toISOString()}>{ago(item.lastAt, lang)}</time></div>
                </div>
                {item.image && <img src={item.image.src} loading="lazy" alt="" className="hidden h-[58px] w-[58px] shrink-0 -rotate-3 rounded-[18px] object-cover shadow-md sm:block" />}
                <div className="flex shrink-0 flex-col items-end gap-2 text-xs text-ink3"><span className="flex items-center gap-1.5 font-bold text-ink2"><MessageCircle className="h-3.5 w-3.5" />{item.replies.length}</span><span className="flex items-center gap-1.5 text-[11px]"><ThumbsUp className="h-3 w-3" />{item.votes + Number(!!votes[item.id])}</span></div>
              </motion.button>;
            })}</AnimatePresence> : <Empty>{tr("Здесь пока тихо. Измени фильтры или начни первое обсуждение.", "It's quiet here. Change the filters or start a discussion.")}</Empty>}
          </div>
          <div className="mt-4 flex items-center gap-2 text-[11px] text-ink3"><CircleHelp className="h-3.5 w-3.5" />{tr("Начальные темы, авторы и реакции показаны как примеры.", "Initial topics, authors and reactions are examples.")}</div>
        </motion.section> : <motion.section key={topic.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.3 }}>
          <button onClick={goBack} className="mb-5 flex items-center gap-2 text-xs font-bold text-ink3 hover:text-vio"><ArrowLeft className="h-4 w-4" />{tr("К обсуждениям", "Back to discussions")}<span className="mx-1 opacity-40">/</span><span>{text(ROOMS.find((r) => r.id === topic.room)!.label)}</span></button>
          <article className="glass relative overflow-hidden rounded-[34px] p-5 sm:p-7"><div className="absolute right-0 top-0 h-44 w-44 rounded-full bg-vio/10 blur-3xl" /><div className="relative flex items-center gap-3"><Avatar author={topic.author} size={45} /><div><div className="flex items-center gap-2 text-sm font-extrabold">{nameOf(topic.author, lang)}{topic.author.team && <ShieldCheck className="h-3.5 w-3.5 text-vio" />}</div><div className="mt-0.5 text-[10px] text-ink3">{dateOf(topic.createdAt, lang)}{topic.example && <span> / {tr("пример темы", "example topic")}</span>}{topic.editedAt && <span> / {tr("изменено", "edited")}</span>}</div></div>{topic.pinned && <Pin className="ml-auto h-4 w-4 text-acidink" />}</div>
            <h2 className="relative mb-6 mt-5 font-display text-[clamp(20px,3vw,31px)] font-bold leading-snug tracking-[-.025em]">{text(topic.title)}</h2>
            <RichText value={text(topic.body)} />
            {topic.image && <figure className="mt-6"><motion.img whileHover={{ scale: 1.015, rotate: -0.5 }} transition={{ duration: 0.5 }} src={topic.image.src} alt={text(topic.image.caption) || text(topic.title)} className="mx-auto max-h-[560px] w-full rounded-[28px] object-contain shadow-deep" />{text(topic.image.caption) && <figcaption className="mt-2 text-center text-xs text-ink3">{text(topic.image.caption)}</figcaption>}</figure>}
            {topic.trackId && <div className="mt-5"><TrackEmbed id={topic.trackId} /></div>}
            <div className="relative mt-6 flex flex-wrap items-center gap-3 border-t border-line pt-4"><Vote id={topic.id} count={topic.votes} /><button onClick={() => quote(topic.author, text(topic.body))} className="flex items-center gap-1.5 text-xs font-bold text-ink3 hover:text-vio"><Quote className="h-3.5 w-3.5" />{tr("Цитировать", "Quote")}</button>{topic.author.id === "me" && <div className="ml-auto flex gap-3"><button onClick={() => { setEditingTopic(topic); setComposer(true); }} aria-label={tr("Изменить тему", "Edit topic")} className="text-ink3 hover:text-vio"><Pencil className="h-4 w-4" /></button><button onClick={() => setDeleteId({ topicId: topic.id })} aria-label={tr("Удалить тему", "Delete topic")} className="text-ink3 hover:text-[#ff5c7a]"><Trash className="h-4 w-4" /></button></div>}</div>
          </article>
          <div className="mb-3 mt-7 flex flex-wrap items-center justify-between gap-3"><h3 className="font-display text-base font-bold">{tr("Ответы", "Replies")} <span className="text-ink3">{topic.replies.length}</span></h3><div className="flex items-center gap-2 rounded-full border border-line px-3"><Search className="h-3.5 w-3.5 text-ink3" /><input value={replySearch} onChange={(e) => setReplySearch(e.target.value)} placeholder={tr("Поиск по теме", "Search this topic")} aria-label={tr("Поиск ответов", "Search replies")} className="w-36 bg-transparent py-2 text-xs outline-none placeholder:text-ink3" />{replySearch && <button onClick={() => setReplySearch("")} aria-label={tr("Очистить", "Clear")}><X className="h-3 w-3" /></button>}</div></div>
          <div className="glass overflow-hidden rounded-[30px]">{replies.length ? <AnimatePresence initial={false}>{replies.map((reply, i) => <motion.article layout="position" key={reply.id} id={`reply-${reply.id}`} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.35, delay: Math.min(i, 4) * 0.04 }} className="border-b border-line p-5 last:border-b-0 sm:p-6"><div className="mb-3 flex items-center gap-3"><Avatar author={reply.author} size={36} /><div><div className="text-xs font-extrabold">{nameOf(reply.author, lang)}</div><time className="text-[10px] text-ink3">{ago(reply.createdAt, lang)}{reply.editedAt && ` / ${tr("изменено", "edited")}`}</time></div><span className="ml-auto text-[11px] text-ink3">#{topic.replies.indexOf(reply) + 1}</span></div><div className="sm:pl-[48px]"><RichText value={text(reply.body)} /><div className="mt-4 flex items-center gap-3"><Vote id={reply.id} count={reply.votes} /><button onClick={() => quote(reply.author, text(reply.body))} className="flex items-center gap-1.5 text-[11px] font-bold text-ink3 hover:text-vio"><Quote className="h-3 w-3" />{tr("Ответить", "Reply")}</button>{reply.author.id === "me" && <div className="ml-auto flex gap-3"><button onClick={() => setEditingReply({ topicId: topic.id, replyId: reply.id, body: text(reply.body) })} aria-label={tr("Изменить ответ", "Edit reply")} className="text-ink3 hover:text-vio"><Pencil className="h-3.5 w-3.5" /></button><button onClick={() => setDeleteId({ topicId: topic.id, replyId: reply.id })} aria-label={tr("Удалить ответ", "Delete reply")} className="text-ink3 hover:text-[#ff5c7a]"><Trash className="h-3.5 w-3.5" /></button></div>}</div></div></motion.article>)}</AnimatePresence> : <Empty>{tr(replySearch ? "Таких ответов не нашлось." : "Первое слово за тобой. Начни разговор.", replySearch ? "No matching replies." : "The first word is yours. Start the conversation.")}</Empty>}</div>
          <div id="forum-reply-editor" className="mt-7"><div className="mb-3 flex items-center justify-between gap-3"><h3 className="font-display text-base font-bold">{tr("Твой ответ", "Your reply")}</h3><span className="text-[10px] text-ink3">{tr("черновик на устройстве", "draft saved on device")}</span></div><RichEditor ref={replyEditor} value={replyBody} onChange={(body) => { useForum.getState().setReplyDraft(topic.id, body); setReplyError(""); }} onSubmit={submitReply} compact /><div className="mt-4 flex items-center justify-between gap-3"><span className="text-[11px] text-ink3">{tr("Пишешь как", "Posting as")} <button onClick={() => setProfileOpen(true)} className="font-bold text-vio">{profile.name || tr("Слушатель", "Listener")}</button></span><motion.button whileTap={{ scale: 0.95 }} onClick={submitReply} disabled={plainBBCode(replyBody).length < 6 || !censor(plainBBCode(replyBody)).ok} className="btn-grad flex items-center gap-2 rounded-full px-5 py-3 text-sm font-extrabold disabled:opacity-40"><Send className="h-4 w-4" />{tr("Ответить", "Reply")}</motion.button></div>{replyError && <p className="mt-3 text-xs text-[#ff5c7a]" role="alert">{replyError}</p>}</div>
        </motion.section>}
      </AnimatePresence></div>
      {sidebar}
    </div>

    <AnimatePresence>{composer && <TopicComposer editing={editingTopic} onClose={() => setComposer(false)} onPublished={(id) => { setComposer(false); openTopic(id); }} />}</AnimatePresence>
    <AnimatePresence>{profileOpen && <ProfileEditor onClose={() => setProfileOpen(false)} />}</AnimatePresence>
    <AnimatePresence>{helpOpen && <FormatHelp onClose={() => setHelpOpen(false)} />}</AnimatePresence>
    <AnimatePresence>{rulesOpen && <Modal title={tr("Правила обсуждений", "Discussion rules")} onClose={() => setRulesOpen(false)} className="max-w-[600px]"><div className="space-y-5 text-sm leading-relaxed text-ink2">{[tr("Обсуждай музыку, а не людей. Разные вкусы не повод переходить на личности.", "Discuss music, not people. Different tastes are not a reason for personal attacks."), tr("Не публикуй чужие треки и изображения как свои. Уважай авторов.", "Don't claim someone else's tracks or artwork as your own. Respect creators."), tr("Без мата, спама, оскорблений и личной информации. Цензура проверяет название и текст.", "No profanity, spam, insults or personal information. The word filter checks titles and messages."), tr("Задавай конкретные вопросы и цитируй нужный фрагмент, а не всю ветку.", "Ask specific questions and quote the relevant part, not the entire thread.")].map((rule, i) => <div key={i} className="flex gap-4"><span className="font-display text-lg font-bold text-vio">0{i + 1}</span><p>{rule}</p></div>)}</div><button onClick={() => setRulesOpen(false)} className="btn-grad ml-auto mt-6 block rounded-full px-6 py-3 text-sm font-bold">{tr("Понятно", "Got it")}</button></Modal>}</AnimatePresence>
    <AnimatePresence>{deleteId && <Modal title={tr(deleteId.replyId ? "Удалить ответ?" : "Удалить обсуждение?", deleteId.replyId ? "Delete this reply?" : "Delete this discussion?")} onClose={() => setDeleteId(null)} className="max-w-[460px]"><p className="text-sm leading-relaxed text-ink2">{tr(deleteId.replyId ? "Ответ будет удалён с устройства. Отменить это действие нельзя." : "Тема и все ответы будут удалены с устройства. Отменить это действие нельзя.", deleteId.replyId ? "The reply will be removed from your device. This cannot be undone." : "The topic and all replies will be removed from your device. This cannot be undone.")}</p><div className="mt-6 flex justify-end gap-3"><button onClick={() => setDeleteId(null)} className="btn-soft rounded-full px-5 py-2.5 text-sm font-bold">{tr("Отменить", "Cancel")}</button><button onClick={() => { if (deleteId.replyId) useForum.getState().deleteReply(deleteId.topicId, deleteId.replyId); else { useForum.getState().deleteTopic(deleteId.topicId); goBack(); } setDeleteId(null); }} className="rounded-full bg-[#ff5c7a] px-5 py-2.5 text-sm font-extrabold text-white">{tr("Удалить", "Delete")}</button></div></Modal>}</AnimatePresence>
    <AnimatePresence>{editingReply && <Modal title={tr("Изменить ответ", "Edit reply")} onClose={() => setEditingReply(null)} className="max-w-[720px]"><RichEditor value={editingReply.body} onChange={(body) => setEditingReply((old) => old ? { ...old, body } : old)} /><button disabled={plainBBCode(editingReply.body).length < 6 || !censor(plainBBCode(editingReply.body)).ok} onClick={() => { const result = useForum.getState().editReply(editingReply.topicId, editingReply.replyId, editingReply.body); if (result.ok) setEditingReply(null); else useStore.getState().toast(errorText(result, tr)); }} className="btn-grad ml-auto mt-5 block rounded-full px-6 py-3 text-sm font-bold disabled:opacity-40">{tr("Сохранить", "Save")}</button></Modal>}</AnimatePresence>
  </div>;
}