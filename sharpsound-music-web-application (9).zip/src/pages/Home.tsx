import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { AudioLines, Pause, Play, SkipBack, SkipForward, Sparkles, ThumbsDown, Upload } from "lucide-react";
import { useMemo, useRef } from "react";
import { Cover } from "../components/Cover";
import { GlyphBlob } from "../components/GlyphBlob";
import { Logo } from "../components/Logo";
import { IconBtn, LikeButton, ShapeCard, Shelf, TrackRow } from "../components/ui";
import { CircleText, Cube3D, FlameSharp, MiniEq, PrismVis, ResonanceOrb } from "../components/Visuals";
import { ALBUMS, GENRES, MOODS, TRACKS } from "../data/catalog";
import { findTrack, useStore } from "../store";
import { cn } from "../utils/cn";
import { useI18n } from "../lib/i18n";

const ease = [0.22, 1, 0.36, 1] as const;

function Hero() {
  const { t: tx } = useI18n();
  const ref = useRef<HTMLElement>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 70, damping: 18 });
  const sy = useSpring(my, { stiffness: 70, damping: 18 });
  const x1 = useTransform(sx, (v) => v * -14);
  const y1 = useTransform(sy, (v) => v * -10);
  const x2 = useTransform(sx, (v) => v * 20);
  const y2 = useTransform(sy, (v) => v * 14);
  const x3 = useTransform(sx, (v) => v * -32);
  const y3 = useTransform(sy, (v) => v * -24);
  const x4 = useTransform(sx, (v) => v * 44);
  const y4 = useTransform(sy, (v) => v * 30);
  const startResonance = useStore((s) => s.startResonance);
  const setTab = useStore((s) => s.setTab);

  const word = (i: number) => ({
    initial: { opacity: 0, y: 70, rotateX: -70, filter: "blur(12px)" },
    animate: { opacity: 1, y: 0, rotateX: 0, filter: "blur(0px)" },
    transition: { delay: 0.15 + i * 0.12, duration: 0.9, ease },
  });

  return (
    <section
      ref={ref}
      onMouseMove={(e) => {
        const r = ref.current?.getBoundingClientRect();
        if (!r) return;
        mx.set((e.clientX - r.left) / r.width - 0.5);
        my.set((e.clientY - r.top) / r.height - 0.5);
      }}
      onMouseLeave={() => {
        mx.set(0);
        my.set(0);
      }}
      className="glass shadow-deep relative overflow-hidden rounded-[44px] p-7 sm:p-10 lg:min-h-[560px] lg:p-14"
    >
      <div className="grid-fine absolute inset-0 opacity-60" />
      <div className="absolute -left-20 -top-24 h-72 w-72 rounded-full bg-vio/25 blur-3xl" />

      <div className="relative h-[300px] sm:h-[360px] lg:absolute lg:inset-y-0 lg:right-0 lg:h-auto lg:w-[50%]">
        <motion.div style={{ x: x2, y: y2 }} className="absolute inset-0">
          <PrismVis className="h-full w-full" />
        </motion.div>
        <motion.div style={{ x: x3, y: y3 }} className="absolute left-1/2 top-[44%] w-[44%] max-w-[250px] -translate-x-1/2 -translate-y-1/2">
          <FlameSharp className="w-full" />
        </motion.div>
        <motion.div style={{ x: x4, y: y4 }} className="absolute right-[9%] top-[8%]">
          <Cube3D size={74} />
        </motion.div>
        <motion.div style={{ x: x1, y: y1 }} className="absolute bottom-[6%] left-[4%] h-28 w-28 text-ink2 sm:h-32 sm:w-32">
          <CircleText text={tx("SHARPSOUND • 2.5D • ЗВУК В КЛЕТКУ • ♯ • ")} size={12} />
          <div className="absolute inset-0 grid place-items-center">
            <Logo size={46} />
          </div>
        </motion.div>
      </div>

      <div className="relative z-10 mt-4 lg:mt-6 lg:max-w-[62%]" style={{ perspective: 900 }}>
        <h1 className="font-display text-[clamp(42px,6.6vw,116px)] font-black leading-[0.94] tracking-[-0.04em]">
          <motion.span style={{ x: x1, y: y1 }} className="block">
            <motion.span {...word(0)} className="inline-block origin-bottom">
              {tx("Звук,")}
            </motion.span>
          </motion.span>
          <motion.span style={{ x: x2, y: y2 }} className="block pl-[5%]">
            <motion.span {...word(1)} className="extrude inline-block origin-bottom -rotate-2 text-[#e4dcff] light:text-[#6d28d9]">
              {tx("заточенный")}
            </motion.span>
          </motion.span>
          <motion.span style={{ x: x3, y: y3 }} className="mt-2 flex flex-wrap items-center gap-x-[0.25em] pl-[12%]">
            <motion.span {...word(2)} className="inline-block origin-bottom -rotate-6 rounded-[0.32em] bg-acid px-[0.28em] pb-[0.06em] text-[0.82em] text-[#0b0614] shadow-[0.08em_0.1em_0_#4c1d95]">
              {tx("под")}
            </motion.span>
            <motion.span {...word(3)} className="text-grad-anim inline-block origin-bottom pb-[0.08em]">
              {tx("тебя.")}
            </motion.span>
          </motion.span>
        </h1>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8, duration: 0.6 }} className="mt-10 flex flex-wrap gap-3">
          <button onClick={() => startResonance(null)} className="btn-grad flex items-center gap-2.5 rounded-full px-6 py-3.5 font-display text-sm font-bold">
            <Play className="h-4 w-4 fill-current" /> {tx("Резонанс")}
          </button>
          <button onClick={() => setTab("recognize")} className="btn-soft flex items-center gap-2.5 rounded-full px-6 py-3.5 font-display text-sm font-bold">
            <AudioLines className="h-4 w-4" /> {tx("Найти по звуку")}
          </button>
        </motion.div>
      </div>
    </section>
  );
}

function MoodList() {
  const { t: tx } = useI18n();
  const mood = useStore((s) => s.mood);
  const mode = useStore((s) => s.mode);
  const isPlaying = useStore((s) => s.isPlaying);
  const startResonance = useStore((s) => s.startResonance);
  return (
    <div className="glass relative overflow-hidden rounded-[44px] p-5 sm:p-7">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h3 className="font-display text-xl font-bold">{tx("Настроение")}</h3>
        <span className="text-xs text-ink3">{tx("нажми, и волна перестроится")}</span>
      </div>
      <div className="relative space-y-0.5" style={{ maskImage: "linear-gradient(to bottom, #000 72%, transparent)" }}>
        {MOODS.map((m, i) => {
          const active = mode === "resonance" && mood === m.id;
          return (
            <motion.button
              key={m.id}
              onClick={() => startResonance(m.id)}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07, duration: 0.6, ease }}
              className="group flex w-full items-center gap-4 rounded-[26px] p-1.5 text-left transition-colors hover:bg-ink/[0.04]"
              style={{ paddingLeft: 6 + (i % 4) * 26 }}
            >
              <div className="h-[72px] w-[72px] shrink-0 transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110">
                <GlyphBlob shape={m.shape} hue={m.hue} active={active && isPlaying} glow={false} />
              </div>
              <div className="min-w-0">
                <div className={cn("font-display text-[15px] font-bold transition-colors", active ? "text-grad" : "group-hover:text-vio")}>{tx(m.label)}</div>
                {active ? (
                  <div className="mt-0.5 flex items-center gap-1.5 text-xs text-acidink">
                    <MiniEq on={isPlaying} /> {tx("звучит сейчас")}
                  </div>
                ) : (
                  <div className="mt-0.5 text-xs text-ink3">{m.genres.map((g) => tx(GENRES[g].label)).join(" · ")}</div>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

function ResonanceBlock() {
  const { t: tx } = useI18n();
  const currentId = useStore((s) => s.currentId);
  const isPlaying = useStore((s) => s.isPlaying);
  const mode = useStore((s) => s.mode);
  const mood = useStore((s) => s.mood);
  useStore((s) => s.uploads);
  const st = useStore.getState();
  const t = findTrack(currentId);
  const on = mode === "resonance" && !!t;
  const moodLabel = MOODS.find((m) => m.id === mood)?.label;

  return (
    <section className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
      <div className="glass shadow-deep relative flex min-h-[480px] flex-col items-center justify-center overflow-hidden rounded-[44px] p-6 sm:p-10">
        <ResonanceOrb className="absolute inset-0 h-full w-full" />
        <div className="grid-fine absolute inset-0 opacity-30" />
        <motion.h2
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease }}
          className="relative text-center font-display text-[clamp(48px,7.5vw,112px)] font-black leading-none tracking-[-0.05em] text-white drop-shadow-[0_6px_30px_rgba(0,0,0,0.35)] light:text-ink light:drop-shadow-none"
        >
          {tx("Резонанс")}
        </motion.h2>
        <p className="relative mt-2 text-center text-sm font-semibold text-white/75 light:text-ink2">
          {on ? `${tx(moodLabel ?? "по твоему вкусу")} · ${tx("подбирает помощник")}` : tx("Бесконечный поток под твой вкус")}
        </p>
        <AnimatePresence mode="wait">
          {on && t ? (
            <motion.div key="on" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="relative mt-6 flex w-full flex-col items-center">
              <AnimatePresence mode="popLayout">
                <motion.div
                  key={t.id}
                  initial={{ scale: 0.7, opacity: 0, rotate: -14 }}
                  animate={{ scale: 1, opacity: 1, rotate: -4 }}
                  exit={{ scale: 0.7, opacity: 0, rotate: 8 }}
                  transition={{ type: "spring", stiffness: 260, damping: 22 }}
                  className="h-28 w-28 overflow-hidden rounded-[28px] shadow-[0_24px_50px_-14px_rgba(0,0,0,0.7)] ring-1 ring-white/25"
                >
                  <Cover t={t} spin={isPlaying} />
                </motion.div>
              </AnimatePresence>
              <div className="mt-6 flex w-full max-w-[580px] items-center gap-2">
                <IconBtn title="Не то" onClick={() => st.dislike(t.id)} className="bg-black/25 text-white light:bg-white/60 light:text-ink">
                  <ThumbsDown className="h-4 w-4" />
                </IconBtn>
                <div className="relative flex-1 overflow-hidden rounded-full bg-black/30 px-5 py-3 text-center text-sm font-bold text-white backdrop-blur light:bg-white/60 light:text-ink">
                  <span className="block truncate">
                    {t.title} <span className="opacity-60">— {t.artist}</span>
                  </span>
                </div>
                <LikeButton id={t.id} big className="bg-black/25 light:bg-white/60" />
              </div>
              <div className="mt-5 flex items-center gap-4">
                <IconBtn title="Назад" onClick={st.prev} className="bg-black/25 text-white light:bg-white/60 light:text-ink">
                  <SkipBack className="h-4 w-4 fill-current" />
                </IconBtn>
                <motion.button whileTap={{ scale: 0.9 }} whileHover={{ scale: 1.06 }} onClick={st.togglePlay} className="btn-grad grid h-16 w-16 place-items-center rounded-full" aria-label={tx("Играть")}>
                  {isPlaying ? <Pause className="h-6 w-6 fill-current" /> : <Play className="h-6 w-6 translate-x-[2px] fill-current" />}
                </motion.button>
                <IconBtn title="Дальше" onClick={st.next} className="bg-black/25 text-white light:bg-white/60 light:text-ink">
                  <SkipForward className="h-4 w-4 fill-current" />
                </IconBtn>
              </div>
            </motion.div>
          ) : (
            <motion.button
              key="off"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => st.startResonance(mood)}
              className="btn-grad relative mt-8 flex items-center gap-3 rounded-full px-8 py-4 font-display font-bold"
            >
              <Play className="h-5 w-5 fill-current" /> {tx("Запустить")}
            </motion.button>
          )}
        </AnimatePresence>
      </div>
      <MoodList />
    </section>
  );
}

export default function Home() {
  const { t: tx } = useI18n();
  const currentId = useStore((s) => s.currentId);
  const isPlaying = useStore((s) => s.isPlaying);
  const uploads = useStore((s) => s.uploads);
  const studioTracks = useStore((s) => s.studioTracks);
  const stats = useStore((s) => s.stats);
  const st = useStore.getState();

  const picks = useMemo(() => [...TRACKS].sort((a, b) => ((a.seed * 7) % 13) - ((b.seed * 7) % 13)).slice(0, 12), []);
  const chart = useMemo(
    () => [...TRACKS, ...uploads, ...studioTracks].sort((a, b) => (stats[b.id]?.plays ?? 0) - (stats[a.id]?.plays ?? 0) || b.f.energy - a.f.energy).slice(0, 10),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [uploads, studioTracks, stats]
  );

  return (
    <div className="space-y-14">
      <Hero />
      <ResonanceBlock />

      <Shelf title="Альбомы" sub="Каждый звук здесь собирается прямо на твоём устройстве">
        {ALBUMS.map((a, i) => {
          const active = !!currentId && a.trackIds.includes(currentId);
          return (
            <ShapeCard
              key={a.id}
              cover={{ id: a.id, title: a.title, hue: a.hue, cover: a.cover, seed: a.seed }}
              title={a.title}
              sub={`${a.artist} · ${a.year}`}
              hue={a.hue}
              shape={i}
              active={active}
              playing={isPlaying}
              onPlay={() => (active ? st.togglePlay() : st.playTrack(a.trackIds[0], a.trackIds))}
            />
          );
        })}
      </Shelf>

      <Shelf title="Треки, которые цепляют" sub="Фигура под обложкой оживает, когда трек играет">
        {picks.map((t, i) => {
          const active = currentId === t.id;
          return (
            <ShapeCard
              key={t.id}
              cover={t}
              title={t.title}
              sub={t.artist}
              hue={t.hue}
              shape={(i + 3) % 8}
              active={active}
              playing={isPlaying}
              onPlay={() => (active ? st.togglePlay() : st.playTrack(t.id, picks.map((p) => p.id)))}
            />
          );
        })}
      </Shelf>

      <Shelf
        title="Из сообщества"
        sub={uploads.length ? "Треки, прошедшие модерацию" : "Здесь появятся треки слушателей"}
        right={
          <button onClick={() => st.setTab("contribute")} className="btn-soft hidden items-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold sm:flex">
            <Upload className="h-4 w-4" /> {tx("Залить свой")}
          </button>
        }
      >
        {[...uploads, ...studioTracks].map((t, i) => {
          const active = currentId === t.id;
          return (
            <ShapeCard
              key={t.id}
              cover={t}
              title={t.title}
              sub={t.artist}
              hue={t.hue}
              shape={(i + 5) % 8}
              active={active}
              playing={isPlaying}
              onPlay={() => (active ? st.togglePlay() : st.playTrack(t.id, [...uploads, ...studioTracks].map((u) => u.id)))}
            />
          );
        })}
        <motion.button
          whileHover={{ y: -6 }}
          onClick={() => st.setTab("contribute")}
          className="group relative grid aspect-[4/5] w-[196px] shrink-0 snap-start place-items-center overflow-hidden rounded-[34px] border-2 border-dashed border-vio/40 p-5 text-center"
        >
          <div className="grid-fine absolute inset-0 opacity-60" />
          <div className="relative">
            <Cube3D size={70} className="mx-auto" />
            <div className="mt-8 font-display text-[15px] font-bold">{tx("Твой трек тут")}</div>
            <div className="mt-1 text-xs text-ink3">{tx("с телефона или ПК")}</div>
          </div>
        </motion.button>
      </Shelf>

      <section>
        <div className="mb-4 flex items-end justify-between px-1">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight sm:text-[30px]">{tx("Чарт недели")}</h2>
            <p className="mt-1 text-sm text-ink3">{tx("Растёт от твоих прослушиваний")}</p>
          </div>
          <Sparkles className="h-6 w-6 text-acidink" />
        </div>
        <div className="glass grid gap-x-6 rounded-[36px] p-3 sm:p-4 lg:grid-cols-2">
          {chart.map((t, i) => (
            <TrackRow key={t.id} t={t} index={i + 1} queue={chart.map((c) => c.id)} />
          ))}
        </div>
      </section>
    </div>
  );
}
