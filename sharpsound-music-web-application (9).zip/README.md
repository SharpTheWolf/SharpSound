# SharpSound

A React, Vite and Tailwind music app with Russian and English interfaces,
dark/light themes, procedural audio and a pixel companion.

## Community Sections

- `src/pages/Contribute.tsx`: music uploads, local audio moderation and release details.
- `src/pages/Forum.tsx`: rooms, topic search, replies, quotes, reactions, following,
  editable profiles, artwork attachments and persistent drafts.
- `src/components/forum/`: editor, formatting guide, safe markup renderer and 2.5D artwork.
- `src/lib/bbcode.ts`: limited BBCode parser. User HTML is rendered as text, never executed.
- `src/lib/forumStore.ts`: persisted discussion data and write validation.

The initial forum topics, authors and reaction counts are examples. New topics
and replies work locally and persist on this device. There is no shared server,
authentication, real-time messaging or remote moderation service yet.

## Language and Companion

The RU/EN switch is in the desktop sidebar and mobile header. The preference is
saved independently from the music library. The interface, sample discussions
and companion lines are localized; user content and original track names stay
unchanged.

`src/data/companionLines.ts` contains more than 100 bilingual lines, including
genre-specific responses. The companion reads, claps, stretches, drinks tea,
plays air guitar, headbangs and spins, in addition to its original actions. The
wardrobe includes a gamer hoodie with animated RGB headphones.

## Mini Studio

`src/pages/Studio.tsx` generates procedural instrumental tracks using the same
offline Web Audio synthesizer as the catalog. Rename each demo, set its genre and
tempo, preview it, then save it to the local library. Studio tracks appear in
search, recognition, playlists and album lists. Audio is generated live in the
app rather than exported as an audio file.

## Storage and Privacy

Music blobs use IndexedDB. Preferences, listening history, forum content and
drafts use local storage. YouTube embeds only load after an explicit click and
require internet access. Microphone recognition requires a secure browser
context, localhost or suitable desktop webview permissions.

## Desktop Packaging

The existing Vite single-file plugin inlines scripts, styles and fonts into
`dist/index.html`. Keep the generated `dist/characters/` image directory beside
the HTML when packaging in Electron or Tauri. The downloadable app icon is
`public/sharpsound-icon.svg`. Desktop executable packaging is not configured.